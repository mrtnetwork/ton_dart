import 'package:blockchain_utils/exception/exceptions.dart';

abstract class TonDartPluginException extends BlockchainUtilsException {}
