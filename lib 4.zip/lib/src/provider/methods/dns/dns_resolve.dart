import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/dns_record.dart';

/// DnsResolve invokes dnsResolve operation.
///
/// DNS resolve for domain name.
///
class TonApiDnsResolve
    extends TonApiRequestParam<DnsRecord, Map<String, dynamic>> {
  final String domainName;
  TonApiDnsResolve(this.domainName);
  @override
  String get method => TonApiMethods.dnsresolve.url;

  @override
  List<String> get pathParameters => [domainName];

  @override
  DnsRecord onResonse(Map<String, dynamic> json) {
    return DnsRecord.fromJson(json);
  }
}
