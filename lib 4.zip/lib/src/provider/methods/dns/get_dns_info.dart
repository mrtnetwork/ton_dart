import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/domain_info.dart';

/// GetDnsInfo invokes getDnsInfo operation.
///
/// Get full information about domain name.
///
class TonApiGetDnsInfo
    extends TonApiRequestParam<DomainInfo, Map<String, dynamic>> {
  /// domain name with .ton or .t.me
  final String domainName;
  TonApiGetDnsInfo(this.domainName);
  @override
  String get method => TonApiMethods.getdnsinfo.url;

  @override
  List<String> get pathParameters => [domainName];

  @override
  DomainInfo onResonse(Map<String, dynamic> json) {
    return DomainInfo.fromJson(json);
  }
}
