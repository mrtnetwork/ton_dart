import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/blockchain_block_shards.dart';

/// GetBlockchainMasterchainShards invokes getBlockchainMasterchainShards operation.
///
/// Get blockchain block shards.
///
class TonApiGetBlockchainMasterchainShards
    extends TonApiRequestParam<BlockchainBlockShards, Map<String, dynamic>> {
  final int masterchainSeqno;
  TonApiGetBlockchainMasterchainShards(this.masterchainSeqno);
  @override
  String get method => TonApiMethods.getblockchainmasterchainshards.url;

  @override
  List<String> get pathParameters => [masterchainSeqno.toString()];

  @override
  BlockchainBlockShards onResonse(Map<String, dynamic> json) {
    return BlockchainBlockShards.fromJson(json);
  }
}
