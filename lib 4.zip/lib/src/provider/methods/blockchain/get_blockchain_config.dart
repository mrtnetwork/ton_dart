import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/blockchain_config.dart';

/// GetBlockchainConfig invokes getBlockchainConfig operation.
///
/// Get blockchain config.
///
class TonApiGetBlockchainConfig
    extends TonApiRequestParam<BlockchainConfig, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.getblockchainconfig.url;

  @override
  BlockchainConfig onResonse(Map<String, dynamic> json) {
    return BlockchainConfig.fromJson(json);
  }
}
