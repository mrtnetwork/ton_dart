import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/transaction.dart';

/// GetBlockchainTransaction invokes getBlockchainTransaction operation.
///
/// Get transaction data.
///
class TonApiGetBlockchainTransaction
    extends TonApiRequestParam<Transaction, Map<String, dynamic>> {
  final String transactionId;
  TonApiGetBlockchainTransaction(this.transactionId);
  @override
  String get method => TonApiMethods.getblockchaintransaction.url;

  @override
  List<String> get pathParameters => [transactionId];

  @override
  Transaction onResonse(Map<String, dynamic> json) {
    return Transaction.fromJson(json);
  }
}
