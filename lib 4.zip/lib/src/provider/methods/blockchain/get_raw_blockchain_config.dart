import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/raw_blockchain_config.dart';

/// GetRawBlockchainConfig invokes getRawBlockchainConfig operation.
///
/// Get raw blockchain config.
///
class TonApiGetRawBlockchainConfig
    extends TonApiRequestParam<RawBlockchainConfig, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.getrawblockchainconfig.url;

  @override
  RawBlockchainConfig onResonse(Map<String, dynamic> json) {
    return RawBlockchainConfig.fromJson(json);
  }
}
