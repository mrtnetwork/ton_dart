import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/subscribtions.dart';

/// GetAccountSubscriptions invokes getAccountSubscriptions operation.
///
/// Get all subscriptions by wallet address.
///
class TonApiGetAccountSubscriptions
    extends TonApiRequestParam<Subscriptions, Map<String, dynamic>> {
  final String accountId;
  TonApiGetAccountSubscriptions(this.accountId);
  @override
  String get method => TonApiMethods.getaccountsubscriptions.url;

  @override
  List<String> get pathParameters => [accountId];

  @override
  Subscriptions onResonse(Map<String, dynamic> json) {
    return Subscriptions.fromJson(json);
  }
}
