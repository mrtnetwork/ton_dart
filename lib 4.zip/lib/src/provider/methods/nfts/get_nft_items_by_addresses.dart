import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/nft_items.dart';

/// GetNftItemsByAddresses invokes getNftItemsByAddresses operation.
///
/// Get NFT items by their addresses.
///
class TonApiGetNftItemsByAddresses
    extends TonApiPostRequestParam<NftItems, Map<String, dynamic>> {
  final List<String> accountIds;
  TonApiGetNftItemsByAddresses(this.accountIds);
  @override
  Object get body => {"account_ids": accountIds};

  @override
  String get method => TonApiMethods.getnftitemsbyaddresses.url;

  @override
  NftItems onResonse(Map<String, dynamic> json) {
    return NftItems.fromJson(json);
  }
}
