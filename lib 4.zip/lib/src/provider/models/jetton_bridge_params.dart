import 'package:blockchain_utils/numbers/numbers.dart';

import 'jetton_bridge_prices.dart';
import 'oracle.dart';

class JettonBridgeParams {
  final String bridgeAddress;
  final String oraclesAddress;
  final int stateFlags;
  final BigInt? burnBridgeFee;
  final List<Oracle> oracles;
  final String? externalChainAddress;
  final JettonBridgePrices? prices;

  const JettonBridgeParams({
    required this.bridgeAddress,
    required this.oraclesAddress,
    required this.stateFlags,
    this.burnBridgeFee,
    required this.oracles,
    this.externalChainAddress,
    this.prices,
  });

  factory JettonBridgeParams.fromJson(Map<String, dynamic> json) {
    return JettonBridgeParams(
      bridgeAddress: json['bridge_address'],
      oraclesAddress: json['oracles_address'],
      stateFlags: json['state_flags'],
      burnBridgeFee: BigintUtils.tryParse(json['burn_bridge_fee']),
      oracles: List<Oracle>.from(
          (json['oracles'] as List).map((x) => Oracle.fromJson(x))),
      externalChainAddress: json['external_chain_address'],
      prices: json['prices'] != null
          ? JettonBridgePrices.fromJson(json['prices'])
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'bridge_address': bridgeAddress,
      'oracles_address': oraclesAddress,
      'state_flags': stateFlags,
      'burn_bridge_fee': burnBridgeFee?.toString(),
      'oracles': List<dynamic>.from(oracles.map((x) => x.toJson())),
      'external_chain_address': externalChainAddress,
      'prices': prices?.toJson(),
    };
  }
}
