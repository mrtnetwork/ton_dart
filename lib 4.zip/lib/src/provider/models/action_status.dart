class ActionStatus {
  final String _value;

  const ActionStatus._(this._value);

  static const ActionStatus ok = ActionStatus._("ok");
  static const ActionStatus failed = ActionStatus._("failed");

  static const List<ActionStatus> values = [
    ok,
    failed,
  ];

  String get value => _value;

  static ActionStatus fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No ActionStatus found with the provided name: $name"),
    );
  }
}
