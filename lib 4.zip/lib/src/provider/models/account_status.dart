class AccountStatus {
  final String _value;

  const AccountStatus._(this._value);

  static const AccountStatus nonexist = AccountStatus._("nonexist");
  static const AccountStatus uninit = AccountStatus._("uninit");
  static const AccountStatus active = AccountStatus._("active");
  static const AccountStatus frozen = AccountStatus._("frozen");

  static const List<AccountStatus> values = [
    nonexist,
    uninit,
    active,
    frozen,
  ];

  String get value => _value;

  static AccountStatus fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No AccountStatus found with the provided name: $name"),
    );
  }
}
