class AccountInfoByStateInit {
  final String publicKey;
  final String address;

  AccountInfoByStateInit({
    required this.publicKey,
    required this.address,
  });

  factory AccountInfoByStateInit.fromJson(Map<String, dynamic> json) {
    return AccountInfoByStateInit(
      publicKey: json['public_key'],
      address: json['address'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'public_key': publicKey, 'address': address};
  }
}
