class InitStateRaw {
  final int workchain;
  final String rootHash;
  final String fileHash;

  const InitStateRaw({
    required this.workchain,
    required this.rootHash,
    required this.fileHash,
  });

  factory InitStateRaw.fromJson(Map<String, dynamic> json) {
    return InitStateRaw(
        workchain: json['workchain'],
        rootHash: json['root_hash'],
        fileHash: json['file_hash']);
  }

  Map<String, dynamic> toJson() {
    return {
      'workchain': workchain,
      'root_hash': rootHash,
      'file_hash': fileHash,
    };
  }
}
