import 'account_address.dart';

class UnSubscriptionAction {
  final AccountAddress subscriber;
  final String subscription;
  final AccountAddress beneficiary;

  const UnSubscriptionAction(
      {required this.subscriber,
      required this.subscription,
      required this.beneficiary});

  factory UnSubscriptionAction.fromJson(Map<String, dynamic> json) {
    return UnSubscriptionAction(
        subscriber: AccountAddress.fromJson(json['subscriber']),
        subscription: json['subscription'],
        beneficiary: AccountAddress.fromJson(json['beneficiary']));
  }

  Map<String, dynamic> toJson() {
    return {
      'subscriber': subscriber.toJson(),
      'subscription': subscription,
      'beneficiary': beneficiary.toJson()
    };
  }
}
