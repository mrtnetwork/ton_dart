import 'account_address.dart';
import 'jetton_preview.dart';

class JettonMintAction {
  final AccountAddress recipient;
  final String recipientsWallet;
  final String amount;
  final JettonPreview jetton;

  const JettonMintAction(
      {required this.recipient,
      required this.recipientsWallet,
      required this.amount,
      required this.jetton});

  factory JettonMintAction.fromJson(Map<String, dynamic> json) {
    return JettonMintAction(
        recipient: AccountAddress.fromJson(json['recipient']),
        recipientsWallet: json['recipients_wallet'],
        amount: json['amount'],
        jetton: JettonPreview.fromJson(json['jetton']));
  }

  Map<String, dynamic> toJson() {
    return {
      'recipient': recipient.toJson(),
      'recipients_wallet': recipientsWallet,
      'amount': amount,
      'jetton': jetton.toJson(),
    };
  }
}
