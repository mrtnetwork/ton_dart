import 'oracle.dart';

class OracleBridgeParams {
  final String bridgeAddr;
  final String oracleMultisigAddress;
  final String externalChainAddress;
  final List<Oracle> oracles;

  const OracleBridgeParams(
      {required this.bridgeAddr,
      required this.oracleMultisigAddress,
      required this.externalChainAddress,
      required this.oracles});

  factory OracleBridgeParams.fromJson(Map<String, dynamic> json) {
    return OracleBridgeParams(
      bridgeAddr: json['bridge_addr'],
      oracleMultisigAddress: json['oracle_multisig_address'],
      externalChainAddress: json['external_chain_address'],
      oracles: List<Oracle>.from(
          (json['oracles'] as List).map((x) => Oracle.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'bridge_addr': bridgeAddr,
      'oracle_multisig_address': oracleMultisigAddress,
      'external_chain_address': externalChainAddress,
      'oracles': List<dynamic>.from(oracles.map((x) => x.toJson()))
    };
  }
}
