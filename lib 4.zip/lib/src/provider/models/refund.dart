import 'refund_type.dart';

class Refund {
  final RefundType type;
  final String origin;

  const Refund({required this.type, required this.origin});

  factory Refund.fromJson(Map<String, dynamic> json) {
    return Refund(
        type: RefundType.fromName(json['type']), origin: json['origin']);
  }

  Map<String, dynamic> toJson() => {'type': type.value, 'origin': origin};
}
