import 'package:blockchain_utils/numbers/numbers.dart';

import 'block_currency_collection_other_item.dart';

class BlockCurrencyCollection {
  final BigInt grams;
  final List<BlockCurrencyCollectionOtherItem> other;

  const BlockCurrencyCollection({
    required this.grams,
    required this.other,
  });

  factory BlockCurrencyCollection.fromJson(Map<String, dynamic> json) {
    return BlockCurrencyCollection(
        grams: BigintUtils.parse(json['grams']),
        other: (json['other'] as List<dynamic>)
            .map((item) => BlockCurrencyCollectionOtherItem.fromJson(item))
            .toList());
  }

  Map<String, dynamic> toJson() {
    return {
      'grams': grams,
      'other': other.map((item) => item.toJson()).toList()
    };
  }
}
