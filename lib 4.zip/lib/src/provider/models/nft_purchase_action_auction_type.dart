class NftPurchaseActionAuctionType {
  final String _value;

  const NftPurchaseActionAuctionType._(this._value);

  static const NftPurchaseActionAuctionType dnsTon =
      NftPurchaseActionAuctionType._("DNS.ton");
  static const NftPurchaseActionAuctionType dnsTg =
      NftPurchaseActionAuctionType._("DNS.tg");
  static const NftPurchaseActionAuctionType numberTg =
      NftPurchaseActionAuctionType._("NUMBER.tg");
  static const NftPurchaseActionAuctionType getgems =
      NftPurchaseActionAuctionType._("getgems");

  static const List<NftPurchaseActionAuctionType> values = [
    dnsTon,
    dnsTg,
    numberTg,
    getgems,
  ];

  String get value => _value;

  static NftPurchaseActionAuctionType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No NftPurchaseActionAuctionType found with the provided name: $name"),
    );
  }
}
