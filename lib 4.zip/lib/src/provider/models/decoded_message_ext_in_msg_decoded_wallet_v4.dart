import 'package:blockchain_utils/numbers/numbers.dart';

import 'decoded_raw_message.dart';

class DecodedMessageExtInMsgDecodedWalletV4 {
  final BigInt subwalletId;
  final BigInt validUntil;
  final BigInt seqno;
  final int op;
  final List<DecodedRawMessage> rawMessages;

  const DecodedMessageExtInMsgDecodedWalletV4(
      {required this.subwalletId,
      required this.validUntil,
      required this.seqno,
      required this.op,
      required this.rawMessages});

  factory DecodedMessageExtInMsgDecodedWalletV4.fromJson(
      Map<String, dynamic> json) {
    return DecodedMessageExtInMsgDecodedWalletV4(
      subwalletId: BigintUtils.parse(json['subwallet_id']),
      validUntil: BigintUtils.parse(json['valid_until']),
      seqno: BigintUtils.parse(json['seqno']),
      op: json['op'],
      rawMessages: (json['raw_messages'] as List<dynamic>)
          .map((item) => DecodedRawMessage.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'subwallet_id': subwalletId.toString(),
      'valid_until': validUntil.toString(),
      'seqno': seqno.toString(),
      'op': op,
      'raw_messages': rawMessages.map((item) => item.toJson()).toList(),
    };
  }
}
