import 'account_address.dart';
import 'jetton_preview.dart';

class JettonQuantity {
  final String quantity;
  final AccountAddress walletAddress;
  final JettonPreview jetton;

  const JettonQuantity(
      {required this.quantity,
      required this.walletAddress,
      required this.jetton});

  factory JettonQuantity.fromJson(Map<String, dynamic> json) {
    return JettonQuantity(
      quantity: json['quantity'],
      walletAddress: AccountAddress.fromJson(json['wallet_address']),
      jetton: JettonPreview.fromJson(json['jetton']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'quantity': quantity,
      'wallet_address': walletAddress.toJson(),
      'jetton': jetton.toJson()
    };
  }
}
