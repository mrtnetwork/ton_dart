class Seqno {
  final int seqno;

  const Seqno({
    required this.seqno,
  });

  factory Seqno.fromJson(Map<String, dynamic> json) {
    return Seqno(seqno: json['seqno']);
  }

  Map<String, dynamic> toJson() {
    return {
      'seqno': seqno,
    };
  }
}
