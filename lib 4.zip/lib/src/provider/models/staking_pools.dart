import 'package:ton_dart/src/provider/models/pool_impiementation.dart';

import 'pool_info.dart';

class StakingPoolsResponse {
  final List<PoolInfo> pools;
  final Map<String, PoolImplementation> implementations;

  const StakingPoolsResponse({
    required this.pools,
    required this.implementations,
  });

  factory StakingPoolsResponse.fromJson(Map<String, dynamic> json) {
    return StakingPoolsResponse(
      pools: (json['pools'] as List<dynamic>)
          .map((pool) => PoolInfo.fromJson(pool))
          .toList(),
      implementations: (json["implementations"] as Map)
          .map<String, PoolImplementation>((key, value) => MapEntry(
              key, PoolImplementation.fromJson((value as Map).cast()))),
    );
  }

  Map<String, dynamic> toJson() => {
        'pools': pools.map((pool) => pool.toJson()).toList(),
        'implementations':
            implementations.map((key, value) => MapEntry(key, value.toJson())),
      };
}
