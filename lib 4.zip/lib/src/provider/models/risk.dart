import 'package:blockchain_utils/numbers/numbers.dart';

import 'jetton_quantity.dart';
import 'nft_item.dart';

class Risk {
  final bool transferAllRemainingBalance;
  final BigInt ton;
  final List<JettonQuantity> jettons;
  final List<NftItem> nfts;

  const Risk(
      {required this.transferAllRemainingBalance,
      required this.ton,
      required this.jettons,
      required this.nfts});

  factory Risk.fromJson(Map<String, dynamic> json) {
    return Risk(
        transferAllRemainingBalance: json['transfer_all_remaining_balance'],
        ton: BigintUtils.parse(json['ton']),
        jettons: List<JettonQuantity>.from(
            (json['jettons'] as List).map((x) => JettonQuantity.fromJson(x))),
        nfts: List<NftItem>.from(
            (json['nfts'] as List).map((x) => NftItem.fromJson(x))));
  }

  Map<String, dynamic> toJson() {
    return {
      'transfer_all_remaining_balance': transferAllRemainingBalance,
      'ton': ton.toString(),
      'jettons': jettons.map((x) => x.toJson()).toList(),
      'nfts': nfts.map((x) => x.toJson()).toList(),
    };
  }
}
