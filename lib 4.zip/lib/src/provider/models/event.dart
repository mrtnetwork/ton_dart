import 'package:blockchain_utils/numbers/numbers.dart';

import 'action.dart';
import 'value_flow.dart';

class Event {
  final String eventID;
  final BigInt timestamp;
  final List<Action> actions;
  final List<ValueFlow> valueFlow;
  final bool isScam;
  final BigInt lt;
  final bool inProgress;

  const Event(
      {required this.eventID,
      required this.timestamp,
      required this.actions,
      required this.valueFlow,
      required this.isScam,
      required this.lt,
      required this.inProgress});

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      eventID: json['event_id'],
      timestamp: BigintUtils.parse(json['timestamp']),
      actions: List<Action>.from(
          (json['actions'] as List).map((x) => Action.fromJson(x))),
      valueFlow: List<ValueFlow>.from(
          (json['value_flow'] as List).map((x) => ValueFlow.fromJson(x))),
      isScam: json['is_scam'],
      lt: BigintUtils.parse(json['lt']),
      inProgress: json['in_progress'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': eventID,
      'timestamp': timestamp.toString(),
      'actions': actions.map((x) => x.toJson()).toList(),
      'value_flow': valueFlow.map((x) => x.toJson()).toList(),
      'is_scam': isScam,
      'lt': lt.toString(),
      'in_progress': inProgress,
    };
  }
}
