import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'refund.dart';

class SmartContractAction {
  final AccountAddress executor;
  final AccountAddress contract;
  final BigInt tonAttached;
  final String operation;
  final String? payload;
  final Refund? refund;

  const SmartContractAction({
    required this.executor,
    required this.contract,
    required this.tonAttached,
    required this.operation,
    this.payload,
    this.refund,
  });

  factory SmartContractAction.fromJson(Map<String, dynamic> json) {
    return SmartContractAction(
      executor: AccountAddress.fromJson(json['executor']),
      contract: AccountAddress.fromJson(json['contract']),
      tonAttached: BigintUtils.parse(json['ton_attached']),
      operation: json['operation'],
      payload: json['payload'],
      refund: json['refund'] != null ? Refund.fromJson(json['refund']) : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'executor': executor.toJson(),
      'contract': contract.toJson(),
      'ton_attached': tonAttached.toString(),
      'operation': operation,
      'payload': payload,
      'refund': refund?.toJson(),
    };
  }
}
