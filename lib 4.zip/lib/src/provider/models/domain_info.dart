import 'package:blockchain_utils/numbers/numbers.dart';

import 'nft_item.dart';

class DomainInfo {
  final String name;
  final BigInt? expiringAt;
  final NftItem? item;

  const DomainInfo({
    required this.name,
    required this.expiringAt,
    required this.item,
  });

  factory DomainInfo.fromJson(Map<String, dynamic> json) {
    return DomainInfo(
        name: json['name'],
        expiringAt: BigintUtils.tryParse(json['expiring_at']),
        item: json['item'] != null ? NftItem.fromJson(json['item']) : null);
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'expiring_at': expiringAt?.toString(),
      'item': item?.toJson()
    };
  }
}
