import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'account_status.dart';
import 'action_phase.dart';
import 'bounce_phase_type.dart';
import 'compute_phase.dart';
import 'credit_phase.dart';
import 'message.dart';
import 'storage_phase.dart';
import 'transaction_type.dart';

class Transaction {
  final String hash;
  final BigInt lt;
  final AccountAddress account;
  final bool success;
  final BigInt utime;
  final AccountStatus origStatus;
  final AccountStatus endStatus;
  final BigInt totalFees;
  final BigInt endBalance;
  final TransactionType transactionType;
  final String stateUpdateOld;
  final String stateUpdateNew;
  final Message? inMsg;
  final List<Message> outMsgs;
  final String block;
  final String? prevTransHash;
  final BigInt? prevTransLt;
  final ComputePhase? computePhase;
  final StoragePhase? storagePhase;
  final CreditPhase? creditPhase;
  final ActionPhase? actionPhase;
  final BouncePhaseType? bouncePhase;
  final bool aborted;
  final bool destroyed;

  const Transaction({
    required this.hash,
    required this.lt,
    required this.account,
    required this.success,
    required this.utime,
    required this.origStatus,
    required this.endStatus,
    required this.totalFees,
    required this.endBalance,
    required this.transactionType,
    required this.stateUpdateOld,
    required this.stateUpdateNew,
    this.inMsg,
    required this.outMsgs,
    required this.block,
    this.prevTransHash,
    this.prevTransLt,
    this.computePhase,
    this.storagePhase,
    this.creditPhase,
    this.actionPhase,
    this.bouncePhase,
    required this.aborted,
    required this.destroyed,
  });

  factory Transaction.fromJson(Map<String, dynamic> json) {
    return Transaction(
      hash: json['hash'],
      lt: BigintUtils.parse(json['lt']),
      account: AccountAddress.fromJson(json['account']),
      success: json['success'],
      utime: BigintUtils.parse(json['utime']),
      origStatus: AccountStatus.fromName(json['orig_status']),
      endStatus: AccountStatus.fromName(json['end_status']),
      totalFees: BigintUtils.parse(json['total_fees']),
      endBalance: BigintUtils.parse(json['end_balance']),
      transactionType: TransactionType.fromName(json['transaction_type']),
      stateUpdateOld: json['state_update_old'],
      stateUpdateNew: json['state_update_new'],
      inMsg: json['in_msg'] != null ? Message.fromJson(json['in_msg']) : null,
      outMsgs: List<Message>.from(
          (json['out_msgs'] as List).map((msg) => Message.fromJson(msg))),
      block: json['block'],
      prevTransHash: json['prev_trans_hash'],
      prevTransLt: BigintUtils.tryParse(json['prev_trans_lt']),
      computePhase: json['compute_phase'] != null
          ? ComputePhase.fromJson(json['compute_phase'])
          : null,
      storagePhase: json['storage_phase'] != null
          ? StoragePhase.fromJson(json['storage_phase'])
          : null,
      creditPhase: json['credit_phase'] != null
          ? CreditPhase.fromJson(json['credit_phase'])
          : null,
      actionPhase: json['action_phase'] != null
          ? ActionPhase.fromJson(json['action_phase'])
          : null,
      bouncePhase: json['bounce_phase'] != null
          ? BouncePhaseType.fromName(json['bounce_phase'])
          : null,
      aborted: json['aborted'],
      destroyed: json['destroyed'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'hash': hash,
      'lt': lt.toString(),
      'account': account.toJson(),
      'success': success,
      'utime': utime.toString(),
      'orig_status': origStatus.value,
      'end_status': endStatus.value,
      'total_fees': totalFees.toString(),
      'end_balance': endBalance.toString(),
      'transaction_type': transactionType.value,
      'state_update_old': stateUpdateOld,
      'state_update_new': stateUpdateNew,
      'in_msg': inMsg?.toJson(),
      'out_msgs': outMsgs.map((msg) => msg.toJson()).toList(),
      'block': block,
      'prev_trans_hash': prevTransHash,
      'prev_trans_lt': prevTransLt?.toString(),
      'compute_phase': computePhase?.toJson(),
      'storage_phase': storagePhase?.toJson(),
      'credit_phase': creditPhase?.toJson(),
      'action_phase': actionPhase?.toJson(),
      'bounce_phase': bouncePhase?.value,
      'aborted': aborted,
      'destroyed': destroyed,
    };
  }
}
