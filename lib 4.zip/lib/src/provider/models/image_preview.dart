class ImagePreview {
  final String resolution;
  final String url;

  const ImagePreview({
    required this.resolution,
    required this.url,
  });

  factory ImagePreview.fromJson(Map<String, dynamic> json) {
    return ImagePreview(resolution: json['resolution'], url: json['url']);
  }

  Map<String, dynamic> toJson() {
    return {'resolution': resolution, 'url': url};
  }
}
