import 'package:blockchain_utils/numbers/numbers.dart';

class ValidatorsSetListItem {
  final String publicKey;
  final BigInt weight;
  final String? adnlAddr;

  const ValidatorsSetListItem(
      {required this.publicKey, required this.weight, this.adnlAddr});

  factory ValidatorsSetListItem.fromJson(Map<String, dynamic> json) {
    return ValidatorsSetListItem(
        publicKey: json['public_key'],
        weight: BigintUtils.parse(json['weight']),
        adnlAddr: json['adnl_addr']);
  }
  Map<String, dynamic> toJson() => {
        'public_key': publicKey,
        'weight': weight.toString(),
        'adnl_addr': adnlAddr
      };
}
