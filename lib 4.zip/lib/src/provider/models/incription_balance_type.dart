class InscriptionType {
  final String _value;

  const InscriptionType._(this._value);

  static const InscriptionType ton20 = InscriptionType._("ton20");
  static const InscriptionType gram20 = InscriptionType._("gram20");

  static const List<InscriptionType> values = [
    ton20,
    gram20,
  ];

  String get value => _value;

  static InscriptionType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No InscriptionType found with the provided name: $name"),
    );
  }
}
