class Oracle {
  final String address;
  final String secpPubkey;

  Oracle({
    required this.address,
    required this.secpPubkey,
  });

  factory Oracle.fromJson(Map<String, dynamic> json) {
    return Oracle(
      address: json['address'],
      secpPubkey: json['secp_pubkey'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'secp_pubkey': secpPubkey,
    };
  }
}
