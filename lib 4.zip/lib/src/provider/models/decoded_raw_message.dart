import 'decoded_raw_message_message.dart';

class DecodedRawMessage {
  final DecodedRawMessageMessage message;
  final int mode;

  const DecodedRawMessage({required this.message, required this.mode});

  factory DecodedRawMessage.fromJson(Map<String, dynamic> json) {
    return DecodedRawMessage(
        message: DecodedRawMessageMessage.fromJson(json['message']),
        mode: json['mode']);
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message.toJson(),
      'mode': mode,
    };
  }
}
