import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';

class DomainBid {
  final bool success;
  final BigInt value;
  final BigInt txTime;
  final String txHash;
  final AccountAddress bidder;

  const DomainBid(
      {required this.success,
      required this.value,
      required this.txTime,
      required this.txHash,
      required this.bidder});

  factory DomainBid.fromJson(Map<String, dynamic> json) {
    return DomainBid(
      success: json['success'],
      value: BigintUtils.parse(json['value']),
      txTime: BigintUtils.parse(json['txTime']),
      txHash: json['txHash'],
      bidder: AccountAddress.fromJson(json['bidder']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'value': value.toString(),
      'txTime': txTime.toString(),
      'txHash': txHash,
      'bidder': bidder.toJson()
    };
  }
}
