class JettonSwapActionDex {
  final String _value;

  const JettonSwapActionDex._(this._value);

  static const JettonSwapActionDex stonfi = JettonSwapActionDex._("stonfi");
  static const JettonSwapActionDex dedust = JettonSwapActionDex._("dedust");
  static const JettonSwapActionDex megatonfi =
      JettonSwapActionDex._("megatonfi");

  static const List<JettonSwapActionDex> values = [
    stonfi,
    dedust,
    megatonfi,
  ];

  String get value => _value;

  static JettonSwapActionDex fromName(String? name) {
    return values.firstWhere(
      (element) => element._value == name,
      orElse: () => throw Exception(
          "No JettonSwapActionDex found with the provided name: $name"),
    );
  }
}
