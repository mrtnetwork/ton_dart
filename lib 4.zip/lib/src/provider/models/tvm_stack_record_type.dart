class TvmStackRecordType {
  final String _value;

  const TvmStackRecordType._(this._value);

  static const TvmStackRecordType cell = TvmStackRecordType._("cell");
  static const TvmStackRecordType num = TvmStackRecordType._("num");
  static const TvmStackRecordType nan = TvmStackRecordType._("nan");
  static const TvmStackRecordType nullType = TvmStackRecordType._("null");
  static const TvmStackRecordType tuple = TvmStackRecordType._("tuple");

  static const List<TvmStackRecordType> values = [
    cell,
    num,
    nan,
    nullType,
    tuple,
  ];

  String get value => _value;

  static TvmStackRecordType fromName(String? name) {
    return values.firstWhere(
      (element) => element._value == name,
      orElse: () => throw Exception(
          "No TvmStackRecordType found with the provided name: $name"),
    );
  }
}
