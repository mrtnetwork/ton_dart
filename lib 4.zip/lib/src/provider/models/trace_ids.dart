import 'trace_id.dart';

class TraceIDs {
  final List<TraceID> traces;

  const TraceIDs({required this.traces});

  factory TraceIDs.fromJson(Map<String, dynamic> json) {
    return TraceIDs(
        traces: (json['traces'] as List<dynamic>)
            .map((e) => TraceID.fromJson(e as Map<String, dynamic>))
            .toList());
  }

  Map<String, dynamic> toJson() {
    return {'traces': traces.map((e) => e.toJson()).toList()};
  }
}
