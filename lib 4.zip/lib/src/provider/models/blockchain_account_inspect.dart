import 'blockchain_account_inspect_methods_item.dart';

class BlockchainAccountInspect {
  final String code;
  final String codeHash;
  final List<BlockchainAccountInspectMethodsItem> methods;
  final String? compiler;

  const BlockchainAccountInspect({
    required this.code,
    required this.codeHash,
    required this.methods,
    required this.compiler,
  });

  factory BlockchainAccountInspect.fromJson(Map<String, dynamic> json) {
    return BlockchainAccountInspect(
      code: json['code'],
      codeHash: json['code_hash'],
      methods: List<BlockchainAccountInspectMethodsItem>.from(json['methods']
          .map((x) => BlockchainAccountInspectMethodsItem.fromJson(x))),
      compiler: json['compiler'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'code': code,
      'code_hash': codeHash,
      'methods': methods.map((x) => x.toJson()).toList(),
      'compiler': compiler,
    };
  }
}
