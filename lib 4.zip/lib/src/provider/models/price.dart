class Price {
  final String value;
  final String tokenName;

  const Price({
    required this.value,
    required this.tokenName,
  });

  factory Price.fromJson(Map<String, dynamic> json) {
    return Price(
      value: json['value'],
      tokenName: json['token_name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'value': value, 'token_name': tokenName};
  }
}
