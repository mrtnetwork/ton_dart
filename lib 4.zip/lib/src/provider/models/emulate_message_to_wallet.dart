// type EmulateMessageToWalletReq struct {
// 	Boc string `json:"boc"`
// 	// Additional per account configuration.
// 	Params []EmulateMessageToWalletReqParamsItem `json:"params"`
// }
// type EmulateMessageToWalletReqParamsItem struct {
// 	Address string   `json:"address"`
// 	Balance OptInt64 `json:"balance"`
// }

import 'package:ton_dart/src/serialization/serialization.dart';

class EmulateMessageToWalletReqParamsItem with JsonSerialization {
  final String address;
  final int? balance;
  const EmulateMessageToWalletReqParamsItem(
      {required this.address, this.balance});

  @override
  Map<String, dynamic> toJson() {
    return {"address": address, "balance": balance};
  }
}

class EmulateMessageToWalletReq with JsonSerialization {
  final String boc;
  final List<EmulateMessageToWalletReqParamsItem> params;
  const EmulateMessageToWalletReq({required this.boc, required this.params});
  @override
  Map<String, dynamic> toJson() {
    return {"boc": boc, "params": params.map((e) => e.toJson()).toList()};
  }
}
