import 'nft_item.dart';

class NftItems {
  final List<NftItem> nftItems;

  const NftItems({required this.nftItems});

  factory NftItems.fromJson(Map<String, dynamic> json) {
    return NftItems(
      nftItems: (json['nft_items'] as List)
          .map((item) => NftItem.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'nft_items': nftItems.map((item) => item.toJson()).toList(),
    };
  }
}
