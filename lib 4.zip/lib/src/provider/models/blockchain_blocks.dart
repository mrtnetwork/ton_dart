import 'blockchain_block.dart';

class BlockchainBlocks {
  final List<BlockchainBlock> blocks;

  const BlockchainBlocks({required this.blocks});

  factory BlockchainBlocks.fromJson(Map<String, dynamic> json) {
    return BlockchainBlocks(
      blocks: (json['blocks'] as List<dynamic>)
          .map((item) => BlockchainBlock.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'blocks': blocks.map((block) => block.toJson()).toList(),
    };
  }
}
