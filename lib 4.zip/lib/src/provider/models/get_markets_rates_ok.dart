import 'market_ton_rates.dart';

class GetMarketsRatesOK {
  final List<MarketTonRates> markets;

  const GetMarketsRatesOK({required this.markets});

  factory GetMarketsRatesOK.fromJson(Map<String, dynamic> json) {
    return GetMarketsRatesOK(
        markets: (json['markets'] as List)
            .map((i) => MarketTonRates.fromJson(i))
            .toList());
  }

  Map<String, dynamic> toJson() {
    return {"markets": markets.map((v) => v.toJson()).toList()};
  }
}
