class RawBlockchainConfig {
  final Map<String, String> config;

  const RawBlockchainConfig({required this.config});

  factory RawBlockchainConfig.fromJson(Map<String, dynamic> json) {
    return RawBlockchainConfig(
      config: (json['config'] as Map).cast(),
    );
  }

  Map<String, dynamic> toJson() {
    return {'config': config};
  }
}
