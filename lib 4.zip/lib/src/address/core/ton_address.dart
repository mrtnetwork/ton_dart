abstract class TonBaseAddress {}
