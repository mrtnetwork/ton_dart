import 'package:ton_dart/src/boc/boc.dart';

mixin JsonSerialization {
  Map<String, dynamic> toJson();

  @override
  String toString() {
    return "$runtimeType${toJson()}";
  }
}

abstract class TonSerialization with JsonSerialization {
  void store(Builder builder);
  const TonSerialization();
}
