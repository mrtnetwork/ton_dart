import 'package:ton_dart/src/exception/exception.dart';

class DictException extends TonDartPluginException {
  DictException(this.message, {this.details});
  @override
  final String message;
  final Map<String, dynamic>? details;
  @override
  String toString() {
    return "DictException($message)";
  }
}
