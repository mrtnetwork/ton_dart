import 'package:ton_dart/src/provider/core/core.dart';

/// A mixin defining the service provider contract for interacting with the Tron network.
mixin TonApiServiceProvider {
  /// The base URL of the Tron network endpoint.
  String get url;

  /// Makes an HTTP POST request to the Tron network with the specified [params].
  ///
  /// The optional [timeout] parameter sets the maximum duration for the request.
  Future<dynamic> post(TonApiRequestDetails params, [Duration? timeout]);

  /// Makes an HTTP GET request to the Tron network with the specified [params].
  ///
  /// The optional [timeout] parameter sets the maximum duration for the request.
  Future<dynamic> get(TonApiRequestDetails params, [Duration? timeout]);
}
