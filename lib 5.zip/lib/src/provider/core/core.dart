import 'package:blockchain_utils/exception/exception.dart';

enum HTTPRequestType { post, put, get }

/// An abstract class representing request parameters for blockfrost API calls.
abstract class TonApiRequestParams {
  /// method for the request.
  abstract final String method;
  const TonApiRequestParams();
}

/// An abstract class representing request parameters for blockfrost (ADA) API calls.
abstract class TonApiRequestParam<RESULT, RESPONSE>
    implements TonApiRequestParams {
  /// Converts the response result to the specified type [RESULT].
  RESULT onResonse(RESPONSE json) {
    return json as RESULT;
  }

  /// list of path parameters variable
  final List<String> pathParameters = [];

  final Map<String, dynamic> queryParameters = {};

  final Map<String, String?> header = {};

  static final RegExp _pathParamRegex = RegExp(r'\{([^}]+)\}');

  static List<String> extractParams(String url) {
    Iterable<Match> matches = _pathParamRegex.allMatches(url);
    List<String> params = [];
    for (Match match in matches) {
      params.add(match.group(0)!);
    }
    return List<String>.unmodifiable(params);
  }

  /// Converts the request parameters to [TonApiRequestDetails] with a unique identifier.
  TonApiRequestDetails toRequest(int v) {
    final pathParams = extractParams(method);
    if (pathParams.length != pathParameters.length) {
      throw MessageException("Invalid Path Parameters.", details: {
        "pathParams": pathParameters,
        "ExceptedPathParametersLength": pathParams.length
      });
    }
    String params = method;
    for (int i = 0; i < pathParams.length; i++) {
      params = params.replaceFirst(pathParams[i], pathParameters[i]);
    }
    if (queryParameters.isNotEmpty) {
      final Map<String, dynamic> queries =
          Map<String, dynamic>.from(queryParameters)
            ..removeWhere((key, value) => value == null);
      if (queries.isNotEmpty) {
        params = Uri(path: params, queryParameters: queries).toString();
      }
    }

    return TonApiRequestDetails(id: v, pathParams: params);
  }
}

/// An abstract class representing post request parameters for blockfrost (ADA) API calls.
abstract class TonApiPostRequestParam<RESULT, RESPONSE>
    extends TonApiRequestParam<RESULT, RESPONSE> {
  abstract final Object? body;

  HTTPRequestType get requestType => HTTPRequestType.post;

  @override
  TonApiRequestDetails toRequest(int v) {
    final request = super.toRequest(v);
    return request.copyWith(
        body: body,
        header: Map<String, String>.fromEntries(header.entries
            .where((element) => element.value != null)
            .map((e) => MapEntry<String, String>(e.key, e.value!))),
        requestType: HTTPRequestType.post);
  }
}

/// Represents the details of a blockfrost request.
class TonApiRequestDetails {
  /// Constructs a new [TonApiRequestDetails] instance with the specified parameters.
  const TonApiRequestDetails(
      {required this.id,
      required this.pathParams,
      this.header = const {},
      this.requestType = HTTPRequestType.get,
      this.body});

  TonApiRequestDetails copyWith({
    int? id,
    String? pathParams,
    HTTPRequestType? requestType,
    Map<String, String>? header,
    Object? body,
  }) {
    return TonApiRequestDetails(
      id: id ?? this.id,
      pathParams: pathParams ?? this.pathParams,
      requestType: requestType ?? this.requestType,
      header: header ?? this.header,
      body: body ?? this.body,
    );
  }

  /// Unique identifier for the request.
  final int id;

  /// URL path parameters
  final String pathParams;

  final HTTPRequestType requestType;

  final Map<String, String> header;

  final Object? body;

  /// Generates the complete request URL by combining the base URI and method-specific URI.
  String url(String uri) {
    String url = uri;
    if (url.endsWith("/")) {
      url = url.substring(0, url.length - 1);
    }

    return "$url$pathParams";
  }
}
