import 'dart:async';

import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/service/service.dart';

/// Facilitates communication with the blockfrost by making requests using a provided [TonApiProvider].
class TonApiProvider {
  /// The underlying blockfrost service provider used for network communication.
  final TonApiServiceProvider rpc;

  /// Constructs a new [TonApiProvider] instance with the specified [rpc] service provider.
  TonApiProvider(this.rpc);

  int _id = 0;

  static void _findError(dynamic val, TonApiRequestDetails request) {
    if (val is Map) {
      if (val.containsKey("error")) {
        final String error = val["error"];
        final int statusCode =
            int.tryParse(val["status_code"].toString()) ?? -1;
        throw RPCError(
            message: error,
            errorCode: statusCode,
            data: error,
            request: {
              "path": request.pathParams,
              "method": request.requestType.name,
              if (request.body != null) "body": request.body,
              "id": request.id
            });
      }
    }
  }

  /// Sends a request to the blockfrost network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  /// Whatever is received will be returned
  Future<dynamic> requestDynamic(TonApiRequestParam request,
      [Duration? timeout]) async {
    final id = ++_id;
    final params = request.toRequest(id);
    final data = params.requestType == HTTPRequestType.post
        ? await rpc.post(params, timeout)
        : await rpc.get(params, timeout);
    print("result $data");
    _findError(data, params);
    return data;
  }

  /// Sends a request to the blockfrost network using the specified [request] parameter.
  ///
  /// The [timeout] parameter, if provided, sets the maximum duration for the request.
  Future<T> request<T, E>(TonApiRequestParam<T, E> request,
      [Duration? timeout]) async {
    final data = await requestDynamic(request, timeout);
    final Object result;
    if (E == List<Map<String, dynamic>>) {
      result = (data as List).map((e) => Map<String, dynamic>.from(e)).toList();
    } else {
      result = data;
    }
    return request.onResonse(result as E);
  }
}
