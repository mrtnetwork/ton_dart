import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';
import 'incription_balance_type.dart';

class InscriptionMintAction  with JsonSerialization {
  final AccountAddress recipient;
  final String amount;
  final InscriptionType type;
  final String ticker;
  final int decimals;

  const InscriptionMintAction({
    required this.recipient,
    required this.amount,
    required this.type,
    required this.ticker,
    required this.decimals,
  });

  factory InscriptionMintAction.fromJson(Map<String, dynamic> json) {
    return InscriptionMintAction(
      recipient: AccountAddress.fromJson(json['recipient']),
      amount: json['amount'],
      type: InscriptionType.fromName(json['type']),
      ticker: json['ticker'],
      decimals: json['decimals'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'recipient': recipient.toJson(),
      'amount': amount,
      'type': type.value,
      'ticker': ticker,
      'decimals': decimals
    };
  }
}