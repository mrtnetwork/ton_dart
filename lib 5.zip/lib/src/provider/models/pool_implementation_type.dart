class PoolImplementationType {
  final String _value;

  const PoolImplementationType._(this._value);

  static const PoolImplementationType whales =
      PoolImplementationType._("whales");
  static const PoolImplementationType tf = PoolImplementationType._("tf");
  static const PoolImplementationType liquidTF =
      PoolImplementationType._("liquidTF");

  static const List<PoolImplementationType> values = [
    whales,
    tf,
    liquidTF,
  ];

  String get value => _value;

  static PoolImplementationType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No PoolImplementationType found with the provided name: $name"),
    );
  }
}
