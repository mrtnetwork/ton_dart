import 'package:ton_dart/src/serialization/serialization.dart';
import 'refund_type.dart';

class Refund  with JsonSerialization {
  final RefundType type;
  final String origin;

  const Refund({required this.type, required this.origin});

  factory Refund.fromJson(Map<String, dynamic> json) {
    return Refund(
        type: RefundType.fromName(json['type']), origin: json['origin']);
  }

@override
  Map<String, dynamic> toJson() => {'type': type.value, 'origin': origin};
}