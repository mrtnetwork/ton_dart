import 'package:ton_dart/src/serialization/serialization.dart';
class EncryptedComment  with JsonSerialization {
  final String encryptionType;
  final String cipherText;

  const EncryptedComment({
    required this.encryptionType,
    required this.cipherText,
  });

  factory EncryptedComment.fromJson(Map<String, dynamic> json) {
    return EncryptedComment(
        encryptionType: json['encryption_type'],
        cipherText: json['cipher_text']);
  }

@override
  Map<String, dynamic> toJson() =>
      {'encryption_type': encryptionType, 'cipher_text': cipherText};
}