import 'package:ton_dart/src/serialization/serialization.dart';
import 'nft_collection.dart';

class NftCollections  with JsonSerialization {
  final List<NftCollection> nftCollections;

  const NftCollections({required this.nftCollections});

  factory NftCollections.fromJson(Map<String, dynamic> json) {
    return NftCollections(
      nftCollections: List<NftCollection>.from(
          json['nft_collections'].map((x) => NftCollection.fromJson(x))),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {'nft_collections': nftCollections.map((x) => x.toJson()).toList()};
  }
}