import 'package:ton_dart/src/serialization/serialization.dart';

class EmulateMessageToWalletReqParamsItem with JsonSerialization {
  final String address;
  final int? balance;
  const EmulateMessageToWalletReqParamsItem(
      {required this.address, this.balance});

  @override
  @override
  Map<String, dynamic> toJson() {
    return {"address": address, "balance": balance};
  }
}

class EmulateMessageToWalletReq with JsonSerialization {
  final String boc;
  final List<EmulateMessageToWalletReqParamsItem> params;
  const EmulateMessageToWalletReq({required this.boc, required this.params});
  @override
  @override
  Map<String, dynamic> toJson() {
    return {"boc": boc, "params": params.map((e) => e.toJson()).toList()};
  }
}
