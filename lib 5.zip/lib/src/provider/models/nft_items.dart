import 'package:ton_dart/src/serialization/serialization.dart';
import 'nft_item.dart';

class NftItems  with JsonSerialization {
  final List<NftItem> nftItems;

  const NftItems({required this.nftItems});

  factory NftItems.fromJson(Map<String, dynamic> json) {
    return NftItems(
      nftItems: (json['nft_items'] as List)
          .map((item) => NftItem.fromJson(item))
          .toList(),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'nft_items': nftItems.map((item) => item.toJson()).toList(),
    };
  }
}