import 'package:ton_dart/src/serialization/serialization.dart';
import 'account.dart';

class Accounts with JsonSerialization {
  final List<Account> accounts;

  const Accounts({required this.accounts});

  factory Accounts.fromJson(Map<String, dynamic> json) {
    return Accounts(
        accounts: List<Account>.from((json['accounts'] as List)
            .map((account) => Account.fromJson(account))));
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() =>
      {'accounts': accounts.map((account) => account.toJson()).toList()};
}
