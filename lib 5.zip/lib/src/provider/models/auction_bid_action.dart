import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';
import 'auction_bid_action_auction_type.dart';
import 'nft_item.dart';
import 'price.dart';

class AuctionBidAction  with JsonSerialization {
  final AuctionBidActionAuctionType auctionType;
  final Price amount;
  final NftItem? nft;
  final AccountAddress bidder;
  final AccountAddress auction;

  const AuctionBidAction(
      {required this.auctionType,
      required this.amount,
      this.nft,
      required this.bidder,
      required this.auction});

  factory AuctionBidAction.fromJson(Map<String, dynamic> json) {
    return AuctionBidAction(
      auctionType: AuctionBidActionAuctionType.fromName(json['auction_type']),
      amount: Price.fromJson(json['amount']),
      nft: json['nft'] != null ? NftItem.fromJson(json['nft']) : null,
      bidder: AccountAddress.fromJson(json['bidder']),
      auction: AccountAddress.fromJson(json['auction']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'auction_type': auctionType,
      'amount': amount.toJson(),
      'bidder': bidder.toJson(),
      'auction': auction.toJson(),
      'nft': nft?.toJson()
    };
  }
}