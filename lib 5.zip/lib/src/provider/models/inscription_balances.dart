import 'package:ton_dart/src/serialization/serialization.dart';
import 'inscription_balance.dart';

class InscriptionBalances  with JsonSerialization {
  final List<InscriptionBalance> inscriptions;

  const InscriptionBalances({required this.inscriptions});

  factory InscriptionBalances.fromJson(Map<String, dynamic> json) {
    return InscriptionBalances(
        inscriptions: List<InscriptionBalance>.from(
            (json['inscriptions'] as List)
                .map((x) => InscriptionBalance.fromJson(x))));
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'inscriptions':
          inscriptions.map((inscription) => inscription.toJson()).toList(),
    };
  }
}