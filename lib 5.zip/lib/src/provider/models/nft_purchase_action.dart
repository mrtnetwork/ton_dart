import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';
import 'nft_item.dart';
import 'nft_purchase_action_auction_type.dart';
import 'price.dart';

class NftPurchaseAction  with JsonSerialization {
  final NftPurchaseActionAuctionType auctionType;
  final Price amount;
  final NftItem nft;
  final AccountAddress seller;
  final AccountAddress buyer;

  const NftPurchaseAction({
    required this.auctionType,
    required this.amount,
    required this.nft,
    required this.seller,
    required this.buyer,
  });

  factory NftPurchaseAction.fromJson(Map<String, dynamic> json) {
    return NftPurchaseAction(
      auctionType: NftPurchaseActionAuctionType.fromName(json['auction_type']),
      amount: Price.fromJson(json['amount']),
      nft: NftItem.fromJson(json['nft']),
      seller: AccountAddress.fromJson(json['seller']),
      buyer: AccountAddress.fromJson(json['buyer']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'auction_type': auctionType.value,
      'amount': amount.toJson(),
      'nft': nft.toJson(),
      'seller': seller.toJson(),
      'buyer': buyer.toJson(),
    };
  }
}