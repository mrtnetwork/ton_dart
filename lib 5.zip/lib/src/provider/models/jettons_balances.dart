import 'package:ton_dart/src/serialization/serialization.dart';
import 'jetton_balance.dart';

class JettonsBalances  with JsonSerialization {
  final List<JettonBalance> balances;

  const JettonsBalances({required this.balances});

  factory JettonsBalances.fromJson(Map<String, dynamic> json) {
    return JettonsBalances(
        balances: (json['balances'] as List)
            .map((balanceJson) => JettonBalance.fromJson(balanceJson))
            .toList());
  }

@override
  Map<String, dynamic> toJson() {
    return {'balances': balances.map((balance) => balance.toJson()).toList()};
  }
}