import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

class CreditPhase  with JsonSerialization {
  final BigInt feesCollected;
  final BigInt credit;

  const CreditPhase({required this.feesCollected, required this.credit});

  factory CreditPhase.fromJson(Map<String, dynamic> json) {
    return CreditPhase(
      feesCollected: BigintUtils.parse(json['fees_collected']),
      credit: BigintUtils.parse(json['credit']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'fees_collected': feesCollected.toString(),
      'credit': credit.toString()
    };
  }
}