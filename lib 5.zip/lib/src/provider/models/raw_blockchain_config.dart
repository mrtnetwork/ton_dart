import 'package:ton_dart/src/serialization/serialization.dart';

class RawBlockchainConfig with JsonSerialization {
  final Map<String, String> config;

  const RawBlockchainConfig({required this.config});

  factory RawBlockchainConfig.fromJson(Map<String, dynamic> json) {
    return RawBlockchainConfig(
      config: (json['config'] as Map).cast(),
    );
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {'config': config};
  }
}
