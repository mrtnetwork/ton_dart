import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_event.dart';
import 'risk.dart';
import 'trace.dart';

class MessageConsequences  with JsonSerialization {
  final Trace trace;
  final Risk risk;
  final AccountEvent event;

  const MessageConsequences({
    required this.trace,
    required this.risk,
    required this.event,
  });

  factory MessageConsequences.fromJson(Map<String, dynamic> json) {
    return MessageConsequences(
      trace: Trace.fromJson(json['trace']),
      risk: Risk.fromJson(json['risk']),
      event: AccountEvent.fromJson(json['event']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'trace': trace.toJson(),
      'risk': risk.toJson(),
      'event': event.toJson()
    };
  }
}