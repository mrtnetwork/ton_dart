class MessageMsgType {
  final String _value;

  const MessageMsgType._(this._value);

  static const MessageMsgType intMsg = MessageMsgType._("int_msg");
  static const MessageMsgType extInMsg = MessageMsgType._("ext_in_msg");
  static const MessageMsgType extOutMsg = MessageMsgType._("ext_out_msg");

  static const List<MessageMsgType> values = [intMsg, extInMsg, extOutMsg];

  String get value => _value;

  static MessageMsgType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No MessageMsgType found with the provided name: $name"),
    );
  }
}
