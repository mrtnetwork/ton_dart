import 'package:ton_dart/src/serialization/serialization.dart';
import 'domain_bid.dart';

class DomainBids  with JsonSerialization {
  final List<DomainBid> data;

  const DomainBids({
    required this.data,
  });

  factory DomainBids.fromJson(Map<String, dynamic> json) {
    return DomainBids(
        data: (json['data'] as List<dynamic>)
            .map((item) => DomainBid.fromJson(item))
            .toList());
  }

@override
  Map<String, dynamic> toJson() {
    return {'data': data.map((bid) => bid.toJson()).toList()};
  }
}