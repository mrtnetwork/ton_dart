import 'package:ton_dart/src/serialization/serialization.dart';
import 'blockchain_shards_shards_item.dart';

class BlockchainBlockShards  with JsonSerialization {
  final List<BlockchainBlockShardsShardsItem> shards;

  const BlockchainBlockShards({required this.shards});

  factory BlockchainBlockShards.fromJson(Map<String, dynamic> json) {
    return BlockchainBlockShards(
      shards: (json['shards'] as List<dynamic>)
          .map((item) => BlockchainBlockShardsShardsItem.fromJson(item))
          .toList(),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'shards': shards.map((shard) => shard.toJson()).toList(),
    };
  }
}