import 'package:ton_dart/src/serialization/serialization.dart';

class ApyHistory with JsonSerialization {
  final double apy;
  final int time;

  ApyHistory({
    required this.apy,
    required this.time,
  });

  factory ApyHistory.fromJson(Map<String, dynamic> json) {
    return ApyHistory(
      apy: json['apy'],
      time: json['time'],
    );
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      'apy': apy,
      'time': time,
    };
  }
}
