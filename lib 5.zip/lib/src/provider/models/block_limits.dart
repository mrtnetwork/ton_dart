import 'package:ton_dart/src/serialization/serialization.dart';
import 'block_param_limits.dart';

class BlockLimits  with JsonSerialization {
  final BlockParamLimits bytes;
  final BlockParamLimits gas;
  final BlockParamLimits ltDelta;

  const BlockLimits({
    required this.bytes,
    required this.gas,
    required this.ltDelta,
  });

  factory BlockLimits.fromJson(Map<String, dynamic> json) {
    return BlockLimits(
      bytes: BlockParamLimits.fromJson(json['bytes']),
      gas: BlockParamLimits.fromJson(json['gas']),
      ltDelta: BlockParamLimits.fromJson(json['lt_delta']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'bytes': bytes.toJson(),
      'gas': gas.toJson(),
      'lt_delta': ltDelta.toJson(),
    };
  }
}