import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

class BlockCurrencyCollectionOtherItem  with JsonSerialization {
  final BigInt id;
  final String value;

  const BlockCurrencyCollectionOtherItem(
      {required this.id, required this.value});

  factory BlockCurrencyCollectionOtherItem.fromJson(Map<String, dynamic> json) {
    return BlockCurrencyCollectionOtherItem(
      id: BigintUtils.parse(json['id']),
      value: json['value'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'id': id.toString(),
      'value': value,
    };
  }
}