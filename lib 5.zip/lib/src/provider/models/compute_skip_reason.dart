import 'package:blockchain_utils/exception/exceptions.dart';

class ComputeSkipReason {
  final String _value;

  const ComputeSkipReason._(this._value);

  static const ComputeSkipReason cskipNoState =
      ComputeSkipReason._("cskip_no_state");
  static const ComputeSkipReason cskipBadState =
      ComputeSkipReason._("cskip_bad_state");
  static const ComputeSkipReason cskipNoGas =
      ComputeSkipReason._("cskip_no_gas");

  static const List<ComputeSkipReason> values = [
    cskipNoState,
    cskipBadState,
    cskipNoGas
  ];

  String get value => _value;

  static ComputeSkipReason fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw MessageException(
          "No ComputeSkipReason find with provided name.",
          details: {"name": name}),
    );
  }
}
