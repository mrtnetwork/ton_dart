import 'package:ton_dart/src/serialization/serialization.dart';
class BlockRaw  with JsonSerialization {
  final int workchain;
  final String shard;
  final int seqno;
  final String rootHash;
  final String fileHash;

  const BlockRaw({
    required this.workchain,
    required this.shard,
    required this.seqno,
    required this.rootHash,
    required this.fileHash,
  });

  factory BlockRaw.fromJson(Map<String, dynamic> json) {
    return BlockRaw(
      workchain: json['workchain'],
      shard: json['shard'],
      seqno: json['seqno'],
      rootHash: json['root_hash'],
      fileHash: json['file_hash'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'workchain': workchain,
      'shard': shard,
      'seqno': seqno,
      'root_hash': rootHash,
      'file_hash': fileHash
    };
  }
}