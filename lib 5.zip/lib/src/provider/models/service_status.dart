import 'package:ton_dart/src/serialization/serialization.dart';

class ServiceStatus with JsonSerialization {
  final bool restOnline;
  final int indexingLatency;

  const ServiceStatus(
      {required this.restOnline, required this.indexingLatency});

  factory ServiceStatus.fromJson(Map<String, dynamic> json) {
    return ServiceStatus(
      restOnline: json['rest_online'],
      indexingLatency: json['indexing_latency'],
    );
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {'rest_online': restOnline, 'indexing_latency': indexingLatency};
  }
}
