import 'package:ton_dart/src/serialization/serialization.dart';
import 'action_simple_preview.dart';
import 'action_status.dart';
import 'action_type.dart';
import 'auction_bid_action.dart';
import 'contract_deploy_action.dart';
import 'deposit_stake_action.dart';
import 'domain_renew_action.dart';
import 'elections_deposit_stake_action.dart';
import 'elections_recover_stake_action.dart';
import 'inscription_mint_action.dart';
import 'inscription_transfer_action.dart';
import 'jetton_burn_action.dart';
import 'jetton_mint_action.dart';
import 'jetton_swap_action.dart';
import 'jetton_transfer_action.dart';
import 'nft_item_transfer_action.dart';
import 'nft_purchase_action.dart';
import 'smart_contract_action.dart';
import 'subscription_action.dart';
import 'ton_transfer_action.dart';
import 'unsubscription_action.dart';
import 'withdraw_stake_action.dart';
import 'withdraw_stake_request_action.dart';

class Action  with JsonSerialization {
  final ActionType type;
  final ActionStatus status;
  final TonTransferAction? tonTransfer;
  final ContractDeployAction? contractDeploy;
  final JettonTransferAction? jettonTransfer;
  final JettonBurnAction? jettonBurn;
  final JettonMintAction? jettonMint;
  final NftItemTransferAction? nftItemTransfer;
  final SubscriptionAction? subscribe;
  final UnSubscriptionAction? unSubscribe;
  final AuctionBidAction? auctionBid;
  final NftPurchaseAction? nftPurchase;
  final DepositStakeAction? depositStake;
  final WithdrawStakeAction? withdrawStake;
  final WithdrawStakeRequestAction? withdrawStakeRequest;
  final ElectionsDepositStakeAction? electionsDepositStake;
  final ElectionsRecoverStakeAction? electionsRecoverStake;
  final JettonSwapAction? jettonSwap;
  final SmartContractAction? smartContractExec;
  final DomainRenewAction? domainRenew;
  final InscriptionTransferAction? inscriptionTransfer;
  final InscriptionMintAction? inscriptionMint;
  final ActionSimplePreview simplePreview;
  final List<String> baseTransactions;

  Action({
    required this.type,
    required this.status,
    this.tonTransfer,
    this.contractDeploy,
    this.jettonTransfer,
    this.jettonBurn,
    this.jettonMint,
    this.nftItemTransfer,
    this.subscribe,
    this.unSubscribe,
    this.auctionBid,
    this.nftPurchase,
    this.depositStake,
    this.withdrawStake,
    this.withdrawStakeRequest,
    this.electionsDepositStake,
    this.electionsRecoverStake,
    this.jettonSwap,
    this.smartContractExec,
    this.domainRenew,
    this.inscriptionTransfer,
    this.inscriptionMint,
    required this.simplePreview,
    required this.baseTransactions,
  });

  factory Action.fromJson(Map<String, dynamic> json) {
    return Action(
      type: ActionType.fromName(json['type']),
      status: ActionStatus.fromName(json['status']),
      tonTransfer: json['TonTransfer'] != null
          ? TonTransferAction.fromJson(json['TonTransfer'])
          : null,
      contractDeploy: json['ContractDeploy'] != null
          ? ContractDeployAction.fromJson(json['ContractDeploy'])
          : null,
      jettonTransfer: json['JettonTransfer'] != null
          ? JettonTransferAction.fromJson(json['JettonTransfer'])
          : null,
      jettonBurn: json['JettonBurn'] != null
          ? JettonBurnAction.fromJson(json['JettonBurn'])
          : null,
      jettonMint: json['JettonMint'] != null
          ? JettonMintAction.fromJson(json['JettonMint'])
          : null,
      nftItemTransfer: json['NftItemTransfer'] != null
          ? NftItemTransferAction.fromJson(json['NftItemTransfer'])
          : null,
      subscribe: json['Subscribe'] != null
          ? SubscriptionAction.fromJson(json['Subscribe'])
          : null,
      unSubscribe: json['UnSubscribe'] != null
          ? UnSubscriptionAction.fromJson(json['UnSubscribe'])
          : null,
      auctionBid: json['AuctionBid'] != null
          ? AuctionBidAction.fromJson(json['AuctionBid'])
          : null,
      nftPurchase: json['NftPurchase'] != null
          ? NftPurchaseAction.fromJson(json['NftPurchase'])
          : null,
      depositStake: json['DepositStake'] != null
          ? DepositStakeAction.fromJson(json['DepositStake'])
          : null,
      withdrawStake: json['WithdrawStake'] != null
          ? WithdrawStakeAction.fromJson(json['WithdrawStake'])
          : null,
      withdrawStakeRequest: json['WithdrawStakeRequest'] != null
          ? WithdrawStakeRequestAction.fromJson(json['WithdrawStakeRequest'])
          : null,
      electionsDepositStake: json['ElectionsDepositStake'] != null
          ? ElectionsDepositStakeAction.fromJson(json['ElectionsDepositStake'])
          : null,
      electionsRecoverStake: json['ElectionsRecoverStake'] != null
          ? ElectionsRecoverStakeAction.fromJson(json['ElectionsRecoverStake'])
          : null,
      jettonSwap: json['JettonSwap'] != null
          ? JettonSwapAction.fromJson(json['JettonSwap'])
          : null,
      smartContractExec: json['SmartContractExec'] != null
          ? SmartContractAction.fromJson(json['SmartContractExec'])
          : null,
      domainRenew: json['DomainRenew'] != null
          ? DomainRenewAction.fromJson(json['DomainRenew'])
          : null,
      inscriptionTransfer: json['InscriptionTransfer'] != null
          ? InscriptionTransferAction.fromJson(json['InscriptionTransfer'])
          : null,
      inscriptionMint: json['InscriptionMint'] != null
          ? InscriptionMintAction.fromJson(json['InscriptionMint'])
          : null,
      simplePreview: ActionSimplePreview.fromJson(json['simple_preview']),
      baseTransactions: List<String>.from(json['base_transactions']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'type': type.value,
      'status': status.value,
      'TonTransfer': tonTransfer?.toJson(),
      'ContractDeploy': contractDeploy?.toJson(),
      'JettonTransfer': jettonTransfer?.toJson(),
      'JettonBurn': jettonBurn?.toJson(),
      'JettonMint': jettonMint?.toJson(),
      'NftItemTransfer': nftItemTransfer?.toJson(),
      'Subscribe': subscribe?.toJson(),
      'UnSubscribe': unSubscribe?.toJson(),
      'AuctionBid': auctionBid?.toJson(),
      'NftPurchase': nftPurchase?.toJson(),
      'DepositStake': depositStake?.toJson(),
      'WithdrawStake': withdrawStake?.toJson(),
      'WithdrawStakeRequest': withdrawStakeRequest?.toJson(),
      'ElectionsDepositStake': electionsDepositStake?.toJson(),
      'ElectionsRecoverStake': electionsRecoverStake?.toJson(),
      'JettonSwap': jettonSwap?.toJson(),
      'SmartContractExec': smartContractExec?.toJson(),
      'DomainRenew': domainRenew?.toJson(),
      'InscriptionTransfer': inscriptionTransfer?.toJson(),
      'InscriptionMint': inscriptionMint?.toJson(),
      'simple_preview': simplePreview.toJson(),
      'base_transactions': baseTransactions,
    };
  }
}