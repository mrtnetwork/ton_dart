import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

class BlockchainAccountInspectMethodsItem  with JsonSerialization {
  final BigInt id;
  final String method;

  const BlockchainAccountInspectMethodsItem(
      {required this.id, required this.method});

  factory BlockchainAccountInspectMethodsItem.fromJson(
      Map<String, dynamic> json) {
    return BlockchainAccountInspectMethodsItem(
        id: BigintUtils.parse(json['id']), method: json['method']);
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'id': id.toString(),
      'method': method,
    };
  }
}