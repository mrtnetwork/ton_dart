import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';

class ElectionsRecoverStakeAction  with JsonSerialization {
  final BigInt amount;
  final AccountAddress staker;

  const ElectionsRecoverStakeAction(
      {required this.amount, required this.staker});

  factory ElectionsRecoverStakeAction.fromJson(Map<String, dynamic> json) {
    return ElectionsRecoverStakeAction(
      amount: BigintUtils.parse(json['amount']),
      staker: AccountAddress.fromJson(json['staker']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'amount': amount.toString(),
      'staker': staker.toJson(),
    };
  }
}