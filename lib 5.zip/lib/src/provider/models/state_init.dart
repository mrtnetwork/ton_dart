import 'package:ton_dart/src/serialization/serialization.dart';
class StateInit  with JsonSerialization {
  final String boc;

  const StateInit({required this.boc});

  factory StateInit.fromJson(Map<String, dynamic> json) {
    return StateInit(boc: json['boc']);
  }

@override
  Map<String, dynamic> toJson() {
    return {'boc': boc};
  }
}