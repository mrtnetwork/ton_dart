import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';
import 'jetton_metadata.dart';
import 'jetton_verification_type.dart';

class JettonInfo  with JsonSerialization {
  final bool mintable;
  final String totalSupply;
  final AccountAddress? admin;
  final JettonMetadata metadata;
  final JettonVerificationType verification;
  final int holdersCount;

  const JettonInfo({
    required this.mintable,
    required this.totalSupply,
    this.admin,
    required this.metadata,
    required this.verification,
    required this.holdersCount,
  });

  factory JettonInfo.fromJson(Map<String, dynamic> json) {
    return JettonInfo(
        mintable: json['mintable'],
        totalSupply: json['total_supply'],
        admin: json['admin'] != null
            ? AccountAddress.fromJson(json['admin'])
            : null,
        metadata: JettonMetadata.fromJson(json['metadata']),
        verification: JettonVerificationType.fromName(json['verification']),
        holdersCount: json['holders_count']);
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'mintable': mintable,
      'total_supply': totalSupply,
      'metadata': metadata.toJson(),
      'verification': verification.value,
      'holders_count': holdersCount,
      'admin': admin?.toJson()
    };
  }
}