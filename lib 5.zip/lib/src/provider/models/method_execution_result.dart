import 'package:ton_dart/src/serialization/serialization.dart';
import 'tvm_stack_record.dart';

class MethodExecutionResult  with JsonSerialization {
  final bool success;
  final int exitCode;
  final List<TvmStackRecord> stack;
  final String decoded;

  const MethodExecutionResult({
    required this.success,
    required this.exitCode,
    required this.stack,
    required this.decoded,
  });

  factory MethodExecutionResult.fromJson(Map<String, dynamic> json) {
    return MethodExecutionResult(
        success: json['success'],
        exitCode: json['exit_code'],
        stack: List<TvmStackRecord>.from(
            (json['stack'] as List).map((x) => TvmStackRecord.fromJson(x))),
        decoded: json['decoded']);
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'success': success,
      'exit_code': exitCode,
      'stack': stack.map((x) => x.toJson()).toList(),
      'decoded': decoded,
    };
  }
}