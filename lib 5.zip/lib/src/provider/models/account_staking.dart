import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_staking_info.dart';

class AccountStaking with JsonSerialization {
  final List<AccountStakingInfo> pools;

  AccountStaking({
    required this.pools,
  });

  factory AccountStaking.fromJson(Map<String, dynamic> json) {
    return AccountStaking(
      pools: List<AccountStakingInfo>.from(
          json['pools'].map((x) => AccountStakingInfo.fromJson(x))),
    );
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      'pools': pools.map((x) => x.toJson()).toList(),
    };
  }
}
