import 'package:ton_dart/src/serialization/serialization.dart';
class Seqno  with JsonSerialization {
  final int seqno;

  const Seqno({
    required this.seqno,
  });

  factory Seqno.fromJson(Map<String, dynamic> json) {
    return Seqno(seqno: json['seqno']);
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'seqno': seqno,
    };
  }
}