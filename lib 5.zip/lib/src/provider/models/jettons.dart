import 'package:ton_dart/src/serialization/serialization.dart';
import 'jetton_info.dart';

class Jettons  with JsonSerialization {
  final List<JettonInfo> nftItems;

  const Jettons({required this.nftItems});

  factory Jettons.fromJson(Map<String, dynamic> json) {
    return Jettons(
        nftItems: (json['jettons'] as List)
            .map((item) => JettonInfo.fromJson(item))
            .toList());
  }

@override
  Map<String, dynamic> toJson() {
    return {'jettons': nftItems.map((item) => item.toJson()).toList()};
  }
}