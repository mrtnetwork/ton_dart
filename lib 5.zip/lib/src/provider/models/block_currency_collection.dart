import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'block_currency_collection_other_item.dart';

class BlockCurrencyCollection  with JsonSerialization {
  final BigInt grams;
  final List<BlockCurrencyCollectionOtherItem> other;

  const BlockCurrencyCollection({
    required this.grams,
    required this.other,
  });

  factory BlockCurrencyCollection.fromJson(Map<String, dynamic> json) {
    return BlockCurrencyCollection(
        grams: BigintUtils.parse(json['grams']),
        other: (json['other'] as List<dynamic>)
            .map((item) => BlockCurrencyCollectionOtherItem.fromJson(item))
            .toList());
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'grams': grams,
      'other': other.map((item) => item.toJson()).toList()
    };
  }
}