import 'package:ton_dart/src/serialization/serialization.dart';
import 'wallet_dns.dart';

class DnsRecord  with JsonSerialization {
  final WalletDNS? wallet;
  final String? nextResolver;
  final List<String> sites;
  final String? storage;

  const DnsRecord({
    required this.wallet,
    required this.nextResolver,
    required this.sites,
    required this.storage,
  });

  factory DnsRecord.fromJson(Map<String, dynamic> json) {
    return DnsRecord(
      wallet:
          json['wallet'] == null ? null : WalletDNS.fromJson(json['wallet']),
      nextResolver: json['next_resolver'],
      sites: List<String>.from(json['sites']),
      storage: json['storage'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'wallet': wallet?.toJson(),
      'next_resolver': nextResolver,
      'sites': sites,
      'storage': storage
    };
  }
}