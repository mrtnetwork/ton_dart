import 'package:ton_dart/src/serialization/serialization.dart';
class ImagePreview  with JsonSerialization {
  final String resolution;
  final String url;

  const ImagePreview({
    required this.resolution,
    required this.url,
  });

  factory ImagePreview.fromJson(Map<String, dynamic> json) {
    return ImagePreview(resolution: json['resolution'], url: json['url']);
  }

@override
  Map<String, dynamic> toJson() {
    return {'resolution': resolution, 'url': url};
  }
}