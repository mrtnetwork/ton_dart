import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/blockchain_utils.dart';

import 'jetton_holders_addresses_item.dart';

class JettonHolders with JsonSerialization {
  final List<JettonHoldersAddressesItem> addresses;
  final BigInt total;

  const JettonHolders({
    required this.addresses,
    required this.total,
  });

  factory JettonHolders.fromJson(Map<String, dynamic> json) {
    return JettonHolders(
        addresses: List<JettonHoldersAddressesItem>.from(
            (json['addresses'] as List)
                .map((x) => JettonHoldersAddressesItem.fromJson(x))),
        total: BigintUtils.parse(json['total']));
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      'addresses': addresses.map((x) => x.toJson()).toList(),
      'total': total.toString(),
    };
  }
}
