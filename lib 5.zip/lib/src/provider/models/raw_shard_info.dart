import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:ton_dart/src/provider/models/block_raw.dart';

class RawShardInfoResponse with JsonSerialization {
  final BlockRaw id;
  final BlockRaw shardblk;
  final String shardProof;
  final String shardDescr;
  const RawShardInfoResponse({
    required this.id,
    required this.shardblk,
    required this.shardProof,
    required this.shardDescr,
  });
  factory RawShardInfoResponse.fromJson(Map<String, dynamic> json) {
    return RawShardInfoResponse(
      id: BlockRaw.fromJson(json["id"]),
      shardblk: BlockRaw.fromJson(json["shardblk"]),
      shardProof: json["shard_proof"],
      shardDescr: json["shard_descr"],
    );
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      "id": id.toJson(),
      "shardblk": shardblk.toJson(),
      "shard_proof": shardProof,
      "shard_descr": shardDescr
    };
  }
}
