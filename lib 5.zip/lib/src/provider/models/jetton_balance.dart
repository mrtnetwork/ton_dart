import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';
import 'jetton_balance_lock.dart';
import 'jetton_preview.dart';
import 'token_rates.dart';

class JettonBalance  with JsonSerialization {
  final String balance;
  final TokenRates? price;
  final AccountAddress walletAddress;
  final JettonPreview jetton;
  final JettonBalanceLock? lock;

  const JettonBalance(
      {required this.balance,
      required this.walletAddress,
      required this.jetton,
      this.price,
      this.lock});

  factory JettonBalance.fromJson(Map<String, dynamic> json) {
    return JettonBalance(
      balance: json['balance'],
      price: json['price'] != null ? TokenRates.fromJson(json['price']) : null,
      walletAddress: AccountAddress.fromJson(json['wallet_address']),
      jetton: JettonPreview.fromJson(json['jetton']),
      lock: json['lock'] != null
          ? JettonBalanceLock.fromJson(json['lock'])
          : null,
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'balance': balance,
      'price': price?.toJson(),
      'wallet_address': walletAddress.toJson(),
      'jetton': jetton.toJson(),
      'lock': lock?.toJson(),
    };
  }
}