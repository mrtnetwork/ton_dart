import 'package:ton_dart/src/serialization/serialization.dart';
import 'block_currency_collection.dart';

class BlockValueFlow  with JsonSerialization {
  final BlockCurrencyCollection fromPrevBlk;
  final BlockCurrencyCollection toNextBlk;
  final BlockCurrencyCollection imported;
  final BlockCurrencyCollection exported;
  final BlockCurrencyCollection feesCollected;
  final BlockCurrencyCollection? burned;
  final BlockCurrencyCollection feesImported;
  final BlockCurrencyCollection recovered;
  final BlockCurrencyCollection created;
  final BlockCurrencyCollection minted;

  const BlockValueFlow({
    required this.fromPrevBlk,
    required this.toNextBlk,
    required this.imported,
    required this.exported,
    required this.feesCollected,
    this.burned,
    required this.feesImported,
    required this.recovered,
    required this.created,
    required this.minted,
  });

  factory BlockValueFlow.fromJson(Map<String, dynamic> json) {
    return BlockValueFlow(
      fromPrevBlk: BlockCurrencyCollection.fromJson(json['from_prev_blk']),
      toNextBlk: BlockCurrencyCollection.fromJson(json['to_next_blk']),
      imported: BlockCurrencyCollection.fromJson(json['imported']),
      exported: BlockCurrencyCollection.fromJson(json['exported']),
      feesCollected: BlockCurrencyCollection.fromJson(json['fees_collected']),
      burned: json['burned'] != null
          ? BlockCurrencyCollection.fromJson(json['burned'])
          : null,
      feesImported: BlockCurrencyCollection.fromJson(json['fees_imported']),
      recovered: BlockCurrencyCollection.fromJson(json['recovered']),
      created: BlockCurrencyCollection.fromJson(json['created']),
      minted: BlockCurrencyCollection.fromJson(json['minted']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'from_prev_blk': fromPrevBlk.toJson(),
      'to_next_blk': toNextBlk.toJson(),
      'imported': imported.toJson(),
      'exported': exported.toJson(),
      'fees_collected': feesCollected.toJson(),
      'burned': burned?.toJson(),
      'fees_imported': feesImported.toJson(),
      'recovered': recovered.toJson(),
      'created': created.toJson(),
      'minted': minted.toJson(),
    };
  }
}