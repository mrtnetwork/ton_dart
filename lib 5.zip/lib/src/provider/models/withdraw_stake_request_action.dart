import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'pool_implementation_type.dart';

class WithdrawStakeRequestAction  with JsonSerialization {
  final BigInt? amount;
  final AccountAddress staker;
  final AccountAddress pool;
  final PoolImplementationType implementation;

  const WithdrawStakeRequestAction(
      {required this.amount,
      required this.staker,
      required this.pool,
      required this.implementation});

  factory WithdrawStakeRequestAction.fromJson(Map<String, dynamic> json) {
    return WithdrawStakeRequestAction(
        amount: BigintUtils.tryParse(json['amount']),
        staker: AccountAddress.fromJson(json['staker']),
        pool: AccountAddress.fromJson(json['pool']),
        implementation:
            PoolImplementationType.fromName(json['implementation']));
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'amount': amount?.toString(),
      'staker': staker.toJson(),
      'pool': pool.toJson(),
      'implementation': implementation.value
    };
  }
}