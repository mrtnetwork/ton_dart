import 'package:ton_dart/src/serialization/serialization.dart';
class Price  with JsonSerialization {
  final String value;
  final String tokenName;

  const Price({
    required this.value,
    required this.tokenName,
  });

  factory Price.fromJson(Map<String, dynamic> json) {
    return Price(
      value: json['value'],
      tokenName: json['token_name'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {'value': value, 'token_name': tokenName};
  }
}