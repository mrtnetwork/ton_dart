import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';

class DomainRenewAction  with JsonSerialization {
  final String domain;
  final String contractAddress;
  final AccountAddress renewer;

  const DomainRenewAction(
      {required this.domain,
      required this.contractAddress,
      required this.renewer});

  factory DomainRenewAction.fromJson(Map<String, dynamic> json) {
    return DomainRenewAction(
      domain: json['domain'],
      contractAddress: json['contract_address'],
      renewer: AccountAddress.fromJson(json["renewer"]),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'domain': domain,
      'contract_address': contractAddress,
      'renewer': renewer.toJson()
    };
  }
}