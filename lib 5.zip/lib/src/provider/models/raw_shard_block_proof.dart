import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:ton_dart/src/provider/models/block_raw.dart';

class RawhardBlockProofLinksItem with JsonSerialization {
  final BlockRaw id;
  final String proof;
  const RawhardBlockProofLinksItem({required this.id, required this.proof});
  factory RawhardBlockProofLinksItem.fromJson(Map<String, dynamic> json) {
    return RawhardBlockProofLinksItem(
        id: BlockRaw.fromJson(json["id"]), proof: json["proof"]);
  }

  @override
  @override
  Map<String, dynamic> toJson() {
    return {"id": id.toJson(), "proof": proof};
  }
}

class RawShardBlockProofResponse with JsonSerialization {
  final BlockRaw masterchainId;
  final List<RawhardBlockProofLinksItem> links;

  const RawShardBlockProofResponse(
      {required this.masterchainId, required this.links});
  factory RawShardBlockProofResponse.fromJson(Map<String, dynamic> json) {
    return RawShardBlockProofResponse(
      masterchainId: BlockRaw.fromJson(json["masterchain_id"]),
      links: (json["links"] as List)
          .map((e) => RawhardBlockProofLinksItem.fromJson(e))
          .toList(),
    );
  }

  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      "masterchain_id": masterchainId,
      "links": links.map((e) => e.toJson()).toList()
    };
  }
}
