import 'package:ton_dart/src/serialization/serialization.dart';
import 'block_raw.dart';

class RawBlockchainBlockHeaderResponse with JsonSerialization {
  final BlockRaw id;
  final int mode;
  final String headerProof;

  const RawBlockchainBlockHeaderResponse(
      {required this.id, required this.mode, required this.headerProof});
  factory RawBlockchainBlockHeaderResponse.fromJson(Map<String, dynamic> json) {
    return RawBlockchainBlockHeaderResponse(
        id: BlockRaw.fromJson(json["id"]),
        headerProof: json["header_proof"],
        mode: json["mode"]);
  }

  @override
  @override
  Map<String, dynamic> toJson() {
    return {"id": id.toJson(), "header_proof": headerProof, "mode": mode};
  }
}
