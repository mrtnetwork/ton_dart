import 'package:ton_dart/src/serialization/serialization.dart';
import 'trace_id.dart';

class TraceIDs with JsonSerialization {
  final List<TraceID> traces;

  const TraceIDs({required this.traces});

  factory TraceIDs.fromJson(Map<String, dynamic> json) {
    return TraceIDs(
        traces: (json['traces'] as List<dynamic>)
            .map((e) => TraceID.fromJson(e as Map<String, dynamic>))
            .toList());
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {'traces': traces.map((e) => e.toJson()).toList()};
  }
}
