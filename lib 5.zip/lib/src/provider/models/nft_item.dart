import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'image_preview.dart';
import 'nft_approved_by_item.dart';
import 'nft_item_collection.dart';
import 'sale.dart';
import 'trust_type.dart';

class NftItem  with JsonSerialization {
  final String address;
  final BigInt index;
  final AccountAddress? owner;
  final NftItemCollection? collection;
  final bool verified;
  final Map<String, String> metadata;
  final Sale? sale;
  final List<ImagePreview> previews;
  final String? dns;
  final List<NftApprovedByItem> approvedBy;
  final bool? includeCnft;
  final TrustType trust;

  NftItem({
    required this.address,
    required this.index,
    this.owner,
    this.collection,
    required this.verified,
    required this.metadata,
    this.sale,
    required this.previews,
    this.dns,
    required this.approvedBy,
    this.includeCnft,
    required this.trust,
  });

  factory NftItem.fromJson(Map<String, dynamic> json) {
    return NftItem(
      address: json['address'],
      index: BigintUtils.parse(json['index']),
      owner:
          json['owner'] != null ? AccountAddress.fromJson(json['owner']) : null,
      collection: json['collection'] != null
          ? NftItemCollection.fromJson(json['collection'])
          : null,
      verified: json['verified'],
      metadata: (json['metadata'] as Map).cast(),
      sale: json['sale'] != null ? Sale.fromJson(json['sale']) : null,
      previews: (json['previews'] as List)
          .map((preview) => ImagePreview.fromJson(preview))
          .toList(),
      dns: json['dns'],
      approvedBy: (json['approved_by'] as List)
          .map((item) => NftApprovedByItem.fromName(item))
          .toList(),
      includeCnft: json['include_cnft'],
      trust: TrustType.values
          .firstWhere((e) => e.toString() == 'TrustType.${json['trust']}'),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'index': index.toString(),
      'verified': verified,
      'metadata': metadata,
      'previews': previews.map((preview) => preview.toJson()).toList(),
      'approved_by': approvedBy.map((item) => item.value).toList(),
      'trust': trust.value,
      'owner': owner?.toJson(),
      'collection': collection?.toJson(),
      'sale': sale?.toJson(),
      'dns': dns,
      'include_cnft': includeCnft
    };
  }
}