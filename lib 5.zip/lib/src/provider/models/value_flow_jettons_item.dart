import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'jetton_preview.dart';

class ValueFlowJettonsItem  with JsonSerialization {
  final AccountAddress account;
  final JettonPreview jetton;
  final BigInt quantity;

  const ValueFlowJettonsItem(
      {required this.account, required this.jetton, required this.quantity});

  factory ValueFlowJettonsItem.fromJson(Map<String, dynamic> json) {
    return ValueFlowJettonsItem(
        account: AccountAddress.fromJson(json['account']),
        jetton: JettonPreview.fromJson(json['jetton']),
        quantity: BigintUtils.parse(json['quantity']));
  }

@override
  Map<String, dynamic> toJson() => {
        'account': account.toJson(),
        'jetton': jetton.toJson(),
        'quantity': quantity.toString()
      };
}