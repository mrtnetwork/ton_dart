import 'package:ton_dart/src/serialization/serialization.dart';
import 'tvm_stack_record_type.dart';

class TvmStackRecord  with JsonSerialization {
  final TvmStackRecordType type;
  final String? cell;
  final String? slice;
  final String? num;
  final List<TvmStackRecord> tuple;

  const TvmStackRecord(
      {required this.type,
      this.cell,
      this.slice,
      this.num,
      required this.tuple});

  factory TvmStackRecord.fromJson(Map<String, dynamic> json) {
    return TvmStackRecord(
        type: TvmStackRecordType.fromName(json['type']),
        cell: json['cell'],
        slice: json['slice'],
        num: json['num'],
        tuple: List<TvmStackRecord>.from(
            (json['tuple'] as List).map((x) => TvmStackRecord.fromJson(x))));
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'type': type.value,
      'cell': cell,
      'slice': slice,
      'num': num,
      'tuple': tuple.map((x) => x.toJson()).toList(),
    };
  }
}