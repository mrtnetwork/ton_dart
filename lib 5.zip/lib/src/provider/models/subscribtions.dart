import 'package:ton_dart/src/serialization/serialization.dart';
import 'subscribtion.dart';

class Subscriptions with JsonSerialization {
  final List<Subscription> subscriptions;

  const Subscriptions({required this.subscriptions});

  factory Subscriptions.fromJson(Map<String, dynamic> json) {
    return Subscriptions(
        subscriptions: (json['subscriptions'] as List)
            .map((subscriptionJson) => Subscription.fromJson(subscriptionJson))
            .toList());
  }

  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {
      'subscriptions':
          subscriptions.map((subscription) => subscription.toJson()).toList()
    };
  }
}
