import 'package:ton_dart/src/serialization/serialization.dart';
import 'transaction.dart';

class Transactions  with JsonSerialization {
  final List<Transaction> transactions;

  const Transactions({required this.transactions});

  factory Transactions.fromJson(Map<String, dynamic> json) {
    return Transactions(
        transactions: List<Transaction>.from((json['transactions'] as List)
            .map((transaction) => Transaction.fromJson(transaction))));
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'transactions':
          transactions.map((transaction) => transaction.toJson()).toList()
    };
  }
}