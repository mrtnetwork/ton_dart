import 'package:ton_dart/src/serialization/serialization.dart';
class ContractDeployAction  with JsonSerialization {
  final String address;
  final List<String> interfaces;

  const ContractDeployAction({
    required this.address,
    required this.interfaces,
  });

  factory ContractDeployAction.fromJson(Map<String, dynamic> json) {
    return ContractDeployAction(
      address: json['address'],
      interfaces: List<String>.from(json['interfaces']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {'address': address, 'interfaces': interfaces};
  }
}