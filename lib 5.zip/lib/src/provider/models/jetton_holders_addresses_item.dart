import 'package:ton_dart/src/serialization/serialization.dart';
import 'account_address.dart';

class JettonHoldersAddressesItem  with JsonSerialization {
  final String address;
  final AccountAddress owner;
  final String balance;

  const JettonHoldersAddressesItem({
    required this.address,
    required this.owner,
    required this.balance,
  });

  factory JettonHoldersAddressesItem.fromJson(Map<String, dynamic> json) {
    return JettonHoldersAddressesItem(
      address: json['address'],
      owner: AccountAddress.fromJson(json['owner']),
      balance: json['balance'],
    );
  }

@override
  Map<String, dynamic> toJson() =>
      {'address': address, 'owner': owner.toJson(), 'balance': balance};
}