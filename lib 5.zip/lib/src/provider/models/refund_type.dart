class RefundType {
  final String _value;

  const RefundType._(this._value);

  static const RefundType dnsTon = RefundType._("DNS.ton");
  static const RefundType dnsTG = RefundType._("DNS.tg");
  static const RefundType getGems = RefundType._("GetGems");

  static const List<RefundType> values = [
    dnsTon,
    dnsTG,
    getGems,
  ];

  String get value => _value;

  static RefundType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () =>
          throw Exception("No RefundType found with the provided name: $name"),
    );
  }
}
