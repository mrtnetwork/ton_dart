import 'package:ton_dart/src/serialization/serialization.dart';
class FoundAccountsAddressesItem  with JsonSerialization {
  final String address;
  final String name;
  final String preview;

  const FoundAccountsAddressesItem(
      {required this.address, required this.name, required this.preview});

  factory FoundAccountsAddressesItem.fromJson(Map<String, dynamic> json) {
    return FoundAccountsAddressesItem(
        address: json['address'], name: json['name'], preview: json['preview']);
  }

@override
  Map<String, dynamic> toJson() =>
      {'address': address, 'name': name, 'preview': preview};
}