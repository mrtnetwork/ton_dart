import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'image_preview.dart';
import 'nft_approved_by_item.dart';

class NftCollection  with JsonSerialization {
  final String address;
  final BigInt nextItemIndex;
  final AccountAddress? owner;
  final String rawCollectionContent;
  final Map<String, String>? metadata;
  final List<ImagePreview> previews;
  final List<NftApprovedByItem> approvedBy;

  const NftCollection({
    required this.address,
    required this.nextItemIndex,
    required this.owner,
    required this.rawCollectionContent,
    required this.metadata,
    required this.previews,
    required this.approvedBy,
  });

  factory NftCollection.fromJson(Map<String, dynamic> json) {
    return NftCollection(
      address: json['address'],
      nextItemIndex: BigintUtils.parse(json['next_item_index']),
      owner:
          json['owner'] != null ? AccountAddress.fromJson(json['owner']) : null,
      rawCollectionContent: json['raw_collection_content'],
      metadata:
          json['metadata'] != null ? (json['metadata'] as Map).cast() : null,
      previews: List<ImagePreview>.from(
          (json['previews'] as List).map((x) => ImagePreview.fromJson(x))),
      approvedBy: List<NftApprovedByItem>.from(
          (json['approved_by'] as List).map((x) => x)),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'next_item_index': nextItemIndex,
      'owner': owner?.toJson(),
      'raw_collection_content': rawCollectionContent,
      'metadata': metadata,
      'previews': previews.map((x) => x.toJson()).toList(),
      'approved_by': approvedBy.map((x) => x).toList(),
    };
  }
}