import 'package:ton_dart/src/serialization/serialization.dart';

import 'market_ton_rates.dart';

class Markets with JsonSerialization {
  final List<MarketTonRates> nftItems;

  const Markets({required this.nftItems});

  factory Markets.fromJson(Map<String, dynamic> json) {
    return Markets(
        nftItems: (json['markets'] as List)
            .map((item) => MarketTonRates.fromJson(item))
            .toList());
  }

  @override
  @override
  @override
  @override
  Map<String, dynamic> toJson() {
    return {'markets': nftItems.map((item) => item.toJson()).toList()};
  }
}
