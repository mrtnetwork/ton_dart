import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';
import 'account_status.dart';
import 'account_storage_info.dart';
import 'blockchain_raw_account_libraries_item.dart';

class BlockchainRawAccount  with JsonSerialization {
  final String address;
  final BigInt balance;
  final Map<String, String>? extraBalance;
  final String? code;
  final String? data;
  final BigInt lastTransactionLt;
  final String? lastTransactionHash;
  final String? frozenHash;
  final AccountStatus status;
  final AccountStorageInfo storage;
  final List<BlockchainRawAccountLibrariesItem> libraries;

  const BlockchainRawAccount({
    required this.address,
    required this.balance,
    this.extraBalance,
    this.code,
    this.data,
    required this.lastTransactionLt,
    this.lastTransactionHash,
    this.frozenHash,
    required this.status,
    required this.storage,
    required this.libraries,
  });

  factory BlockchainRawAccount.fromJson(Map<String, dynamic> json) {
    return BlockchainRawAccount(
      address: json['address'],
      balance: BigintUtils.parse(json['balance']),
      extraBalance: json['extra_balance'] != null
          ? (json['extra_balance'] as Map).cast()
          : null,
      code: json['code'],
      data: json['data'],
      lastTransactionLt: BigintUtils.parse(json['last_transaction_lt']),
      lastTransactionHash: json['last_transaction_hash'],
      frozenHash: json['frozen_hash'],
      status: AccountStatus.fromName(json['status']),
      storage: AccountStorageInfo.fromJson(json['storage']),
      libraries: List<BlockchainRawAccountLibrariesItem>.from(json['libraries']
          .map((x) => BlockchainRawAccountLibrariesItem.fromJson(x))),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'balance': balance.toString(),
      'extra_balance': extraBalance,
      'code': code,
      'data': data,
      'last_transaction_lt': lastTransactionLt.toString(),
      'last_transaction_hash': lastTransactionHash,
      'frozen_hash': frozenHash,
      'status': status.value,
      'storage': storage.toJson(),
      'libraries': libraries.map((x) => x.toJson()).toList(),
    };
  }
}