import 'package:ton_dart/src/serialization/serialization.dart';
import 'dns_expiring_items_item.dart';

class DnsExpiring  with JsonSerialization {
  final List<DnsExpiringItemsItem> items;

  const DnsExpiring({required this.items});

  factory DnsExpiring.fromJson(Map<String, dynamic> json) {
    return DnsExpiring(
      items: List<DnsExpiringItemsItem>.from(
          json['items'].map((x) => DnsExpiringItemsItem.fromJson(x))),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {'items': items.map((x) => x.toJson()).toList()};
  }
}