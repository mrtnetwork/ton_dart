import 'package:ton_dart/src/serialization/serialization.dart';
import 'package:blockchain_utils/numbers/numbers.dart';

class TraceID  with JsonSerialization {
  final String id;
  final BigInt utime;

  const TraceID({required this.id, required this.utime});

  factory TraceID.fromJson(Map<String, dynamic> json) {
    return TraceID(
        id: json['id'] as String, utime: BigintUtils.parse(json['utime']));
  }

@override
  Map<String, dynamic> toJson() {
    return {'id': id, 'utime': utime.toString()};
  }
}