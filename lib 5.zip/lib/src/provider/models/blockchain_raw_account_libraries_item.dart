import 'package:ton_dart/src/serialization/serialization.dart';
class BlockchainRawAccountLibrariesItem  with JsonSerialization {
  final bool isPublic;
  final String root;

  const BlockchainRawAccountLibrariesItem(
      {required this.isPublic, required this.root});

  factory BlockchainRawAccountLibrariesItem.fromJson(
      Map<String, dynamic> json) {
    return BlockchainRawAccountLibrariesItem(
        isPublic: json['public'], root: json['root']);
  }

@override
  Map<String, dynamic> toJson() {
    return {'public': isPublic, 'root': root};
  }
}