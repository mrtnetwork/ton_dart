import 'package:ton_dart/src/serialization/serialization.dart';
import 'transaction.dart';

class Trace  with JsonSerialization {
  final Transaction transaction;
  final List<String> interfaces;
  final List<Trace> children;
  final bool? emulated;

  const Trace(
      {required this.transaction,
      required this.interfaces,
      required this.children,
      this.emulated});

  factory Trace.fromJson(Map<String, dynamic> json) {
    return Trace(
      transaction: Transaction.fromJson(json['transaction']),
      interfaces: List<String>.from(json['interfaces']),
      children: List<Trace>.from(
          (json['children'] as List).map((x) => Trace.fromJson(x))),
      emulated: json['emulated'],
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'transaction': transaction.toJson(),
      'interfaces': interfaces,
      'children': children.map((x) => x.toJson()).toList(),
      'emulated': emulated,
    };
  }
}