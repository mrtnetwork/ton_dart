import 'package:ton_dart/src/serialization/serialization.dart';
import 'jetton_verification_type.dart';

class JettonPreview  with JsonSerialization {
  final String address;
  final String name;
  final String symbol;
  final int decimals;
  final String image;
  final JettonVerificationType verification;

  const JettonPreview({
    required this.address,
    required this.name,
    required this.symbol,
    required this.decimals,
    required this.image,
    required this.verification,
  });

  factory JettonPreview.fromJson(Map<String, dynamic> json) {
    return JettonPreview(
      address: json['address'],
      name: json['name'],
      symbol: json['symbol'],
      decimals: json['decimals'],
      image: json['image'],
      verification: JettonVerificationType.fromName(json['verification']),
    );
  }

@override
  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'name': name,
      'symbol': symbol,
      'decimals': decimals,
      'image': image,
      'verification': verification.value,
    };
  }
}