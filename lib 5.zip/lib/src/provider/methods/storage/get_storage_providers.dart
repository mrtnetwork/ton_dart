import 'package:ton_dart/src/models/storage_provider.dart';
import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';

/// GetStorageProviders invokes getStorageProviders operation.
///
/// Get TON storage providers deployed to the blockchain.
///
class TonApiGetStorageProviders
    extends TonApiRequestParam<List<StorageProvider>, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.getstorageproviders.url;

  @override
  List<StorageProvider> onResonse(Map<String, dynamic> json) {
    return (json["providers"] as List)
        .map((e) => StorageProvider.fromJson(e))
        .toList();
  }
}
