import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/markets.dart';

/// GetMarketsRates invokes getMarketsRates operation.
///
/// Get the TON price from markets.
///
class TonApiGetMarketsRates
    extends TonApiRequestParam<Markets, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.getmarketsrates.url;

  @override
  Markets onResonse(Map<String, dynamic> json) {
    return Markets.fromJson(json);
  }
}
