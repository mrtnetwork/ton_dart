import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/account_event.dart';

/// EmulateMessageToAccountEvent invokes emulateMessageToAccountEvent operation.
///
/// Emulate sending message to blockchain.
///
class TonApiEmulateMessageToAccountEvent
    extends TonApiPostRequestParam<AccountEvent, Map<String, dynamic>> {
  final String? appLanguage;
  final String accountId;
  final bool ignoreSignatureCheck;
  final String boc;
  TonApiEmulateMessageToAccountEvent(
      {required this.accountId,
      required this.ignoreSignatureCheck,
      required this.boc,
      this.appLanguage});
  @override
  Object get body => {"boc": boc};

  @override
  String get method => TonApiMethods.emulatemessagetoaccountevent.url;

  @override
  List<String> get pathParameters => [accountId];

  @override
  Map<String, dynamic> get queryParameters =>
      {"ignore_signature_check": ignoreSignatureCheck.toString()};

  @override
  Map<String, String?> get header => {"Accept-Language": appLanguage};

  @override
  AccountEvent onResonse(Map<String, dynamic> json) {
    return AccountEvent.fromJson(json);
  }
}
