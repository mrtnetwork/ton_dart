import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/accounts.dart';

/// GetWalletsByPublicKey invokes getWalletsByPublicKey operation.
///
/// Get wallets by public key.
///
class TonApiGetWalletsByPublicKey
    extends TonApiRequestParam<Accounts, Map<String, dynamic>> {
  final String publicKey;
  TonApiGetWalletsByPublicKey(this.publicKey);
  @override
  String get method => TonApiMethods.getwalletsbypublickey.url;

  @override
  List<String> get pathParameters => [publicKey];

  @override
  Accounts onResonse(Map<String, dynamic> json) {
    return Accounts.fromJson(json);
  }
}
