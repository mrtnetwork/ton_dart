import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/service_status.dart';

/// Status invokes status operation.
///
/// Status.
///
class TonApiStatus
    extends TonApiRequestParam<ServiceStatus, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.status.url;

  @override
  ServiceStatus onResonse(Map<String, dynamic> json) {
    // TODO: implement onResonse
    return ServiceStatus.fromJson(json);
  }
}
