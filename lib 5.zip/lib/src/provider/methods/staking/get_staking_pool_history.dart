import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/apy_history.dart';

/// GetStakingPoolHistory invokes getStakingPoolHistory operation.
///
/// Pool history.
///
class TonApiGetStakingPoolHistory
    extends TonApiRequestParam<List<ApyHistory>, Map<String, dynamic>> {
  final String accountId;
  TonApiGetStakingPoolHistory(this.accountId);
  @override
  String get method => TonApiMethods.getstakingpoolhistory.url;

  @override
  List<String> get pathParameters => [accountId];
  @override
  List<ApyHistory> onResonse(Map<String, dynamic> json) {
    return (json["apy"] as List).map((e) => ApyHistory.fromJson(e)).toList();
  }
}
