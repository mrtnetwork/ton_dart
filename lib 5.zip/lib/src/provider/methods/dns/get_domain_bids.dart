import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/domain_bids.dart';

/// GetDomainBids invokes getDomainBids operation.
///
/// Get domain bids.
///
class TonApiGetDomainBids
    extends TonApiRequestParam<DomainBids, Map<String, dynamic>> {
  /// domain name with .ton or .t.me
  final String domainName;
  TonApiGetDomainBids(this.domainName);

  @override
  String get method => TonApiMethods.getdomainbids.url;

  @override
  List<String> get pathParameters => [domainName];

  @override
  DomainBids onResonse(Map<String, dynamic> json) {
    return DomainBids.fromJson(json);
  }
}
