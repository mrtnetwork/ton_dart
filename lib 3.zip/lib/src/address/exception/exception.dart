import 'package:ton_dart/src/exception/exception.dart';

class TonAddressException extends TonDartPluginException {
  TonAddressException(this.message, {this.details});
  @override
  final String message;
  final Map<String, dynamic>? details;
  @override
  String toString() {
    return "TonAddressException($message)";
  }
}
