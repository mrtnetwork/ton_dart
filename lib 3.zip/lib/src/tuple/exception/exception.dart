import 'package:ton_dart/src/exception/exception.dart';

class TupleException extends TonDartPluginException {
  TupleException(this.message, {this.details});
  @override
  final String message;
  final Map<String, dynamic>? details;
  @override
  String toString() {
    return "TupleException($message)";
  }
}
