import 'pool_impiementation.dart';
import 'pool_info.dart';

class StakingPoolResponse {
  final PoolInfo pool;
  final PoolImplementation implementation;

  const StakingPoolResponse({
    required this.pool,
    required this.implementation,
  });

  factory StakingPoolResponse.fromJson(Map<String, dynamic> json) {
    return StakingPoolResponse(
      pool: PoolInfo.fromJson(json["pool"]),
      implementation: PoolImplementation.fromJson(json["implementation"]),
    );
  }

  Map<String, dynamic> toJson() => {
        'pool': pool.toJson(),
        'implementation': implementation.toJson(),
      };
}
