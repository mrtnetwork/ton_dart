import 'account_address.dart';

class ActionSimplePreview {
  final String name;
  final String description;
  final String? actionImage;
  final String? value;
  final String? valueImage;
  final List<AccountAddress> accounts;

  const ActionSimplePreview({
    required this.name,
    required this.description,
    this.actionImage,
    this.value,
    this.valueImage,
    required this.accounts,
  });

  factory ActionSimplePreview.fromJson(Map<String, dynamic> json) {
    return ActionSimplePreview(
      name: json['name'] as String,
      description: json['description'] as String,
      actionImage: json['action_image'],
      value: json['value'],
      valueImage: json['value_image'],
      accounts: (json['accounts'] as List)
          .map((e) => AccountAddress.fromJson(e))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'accounts': accounts.map((e) => e.toJson()).toList(),
      'action_image': actionImage,
      'value': value,
      'value_image': valueImage
    };
  }
}
