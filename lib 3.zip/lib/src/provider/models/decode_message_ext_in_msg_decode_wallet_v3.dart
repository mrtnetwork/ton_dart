import 'package:blockchain_utils/numbers/numbers.dart';

import 'decoded_raw_message.dart';

class DecodedMessageExtInMsgDecodedWalletV3 {
  final BigInt subwalletId;
  final BigInt validUntil;
  final BigInt seqno;
  final List<DecodedRawMessage> rawMessages;

  const DecodedMessageExtInMsgDecodedWalletV3(
      {required this.subwalletId,
      required this.validUntil,
      required this.seqno,
      required this.rawMessages});

  factory DecodedMessageExtInMsgDecodedWalletV3.fromJson(
      Map<String, dynamic> json) {
    return DecodedMessageExtInMsgDecodedWalletV3(
      subwalletId: BigintUtils.parse(json['subwallet_id']),
      validUntil: BigintUtils.parse(json['valid_until']),
      seqno: BigintUtils.parse(json['seqno']),
      rawMessages: (json['raw_messages'] as List<dynamic>)
          .map((item) => DecodedRawMessage.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'subwallet_id': subwalletId.toString(),
      'valid_until': validUntil.toString(),
      'seqno': seqno.toString(),
      'raw_messages': rawMessages.map((item) => item.toJson()).toList(),
    };
  }
}
