import 'package:blockchain_utils/blockchain_utils.dart';

import 'account_address.dart';
import 'jetton_preview.dart';
import 'jetton_swap_action_dex.dart';

class JettonSwapAction {
  final JettonSwapActionDex dex;
  final String amountIn;
  final String amountOut;
  final BigInt? tonIn;
  final BigInt? tonOut;
  final AccountAddress userWallet;
  final AccountAddress router;
  final JettonPreview? jettonMasterIn;
  final JettonPreview? jettonMasterOut;

  const JettonSwapAction({
    required this.dex,
    required this.amountIn,
    required this.amountOut,
    required this.userWallet,
    required this.router,
    this.tonIn,
    this.tonOut,
    this.jettonMasterIn,
    this.jettonMasterOut,
  });

  factory JettonSwapAction.fromJson(Map<String, dynamic> json) {
    return JettonSwapAction(
      dex: JettonSwapActionDex.fromName(json['dex']),
      amountIn: json['amount_in'] as String,
      amountOut: json['amount_out'] as String,
      tonIn: BigintUtils.tryParse(json['ton_in']),
      tonOut: BigintUtils.tryParse(json['ton_out']),
      userWallet: AccountAddress.fromJson(json['user_wallet']),
      router: AccountAddress.fromJson(json['router']),
      jettonMasterIn: json['jetton_master_in'] == null
          ? null
          : JettonPreview.fromJson(json['jetton_master_in']),
      jettonMasterOut: json['jetton_master_out'] == null
          ? null
          : JettonPreview.fromJson(json['jetton_master_out']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'dex': dex.value,
      'amount_in': amountIn,
      'amount_out': amountOut,
      'user_wallet': userWallet.toJson(),
      'router': router.toJson(),
      'ton_in': tonIn?.toString(),
      'ton_out': tonOut?.toString(),
      'jetton_master_in': jettonMasterIn?.toJson(),
      'jetton_master_out': jettonMasterOut?.toJson()
    };
  }
}
