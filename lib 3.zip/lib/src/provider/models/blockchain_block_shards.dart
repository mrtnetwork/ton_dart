import 'blockchain_shards_shards_item.dart';

class BlockchainBlockShards {
  final List<BlockchainBlockShardsShardsItem> shards;

  const BlockchainBlockShards({required this.shards});

  factory BlockchainBlockShards.fromJson(Map<String, dynamic> json) {
    return BlockchainBlockShards(
      shards: (json['shards'] as List<dynamic>)
          .map((item) => BlockchainBlockShardsShardsItem.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'shards': shards.map((shard) => shard.toJson()).toList(),
    };
  }
}
