import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'value_flow_jettons_item.dart';

class ValueFlow {
  final AccountAddress account;
  final BigInt ton;
  final BigInt fees;
  final List<ValueFlowJettonsItem> jettons;

  const ValueFlow({
    required this.account,
    required this.ton,
    required this.fees,
    required this.jettons,
  });

  factory ValueFlow.fromJson(Map<String, dynamic> json) {
    return ValueFlow(
      account: AccountAddress.fromJson(json['account']),
      ton: BigintUtils.parse(json['ton']),
      fees: BigintUtils.parse(json['fees']),
      jettons: (json['jettons'] as List<dynamic>)
          .map((item) => ValueFlowJettonsItem.fromJson(item))
          .toList(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'account': account.toJson(),
      'ton': ton.toString(),
      'fees': fees.toString(),
      'jettons': jettons.map((item) => item.toJson()).toList()
    };
  }
}
