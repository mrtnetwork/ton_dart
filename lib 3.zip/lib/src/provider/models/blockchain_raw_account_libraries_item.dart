class BlockchainRawAccountLibrariesItem {
  final bool isPublic;
  final String root;

  const BlockchainRawAccountLibrariesItem(
      {required this.isPublic, required this.root});

  factory BlockchainRawAccountLibrariesItem.fromJson(
      Map<String, dynamic> json) {
    return BlockchainRawAccountLibrariesItem(
        isPublic: json['public'], root: json['root']);
  }

  Map<String, dynamic> toJson() {
    return {'public': isPublic, 'root': root};
  }
}
