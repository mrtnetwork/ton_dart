class PoolImplementation {
  final String name;
  final String description;
  final String url;
  final List<String> socials;

  const PoolImplementation({
    required this.name,
    required this.description,
    required this.url,
    required this.socials,
  });

  factory PoolImplementation.fromJson(Map<String, dynamic> json) {
    return PoolImplementation(
      name: json['name'],
      description: json['description'],
      url: json['url'],
      socials: List<String>.from(json['socials']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'description': description,
      'url': url,
      'socials': socials,
    };
  }
}
