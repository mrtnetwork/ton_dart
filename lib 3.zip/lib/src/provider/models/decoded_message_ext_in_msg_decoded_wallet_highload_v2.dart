import 'package:blockchain_utils/numbers/numbers.dart';

import 'decoded_raw_message.dart';

class DecodedMessageExtInMsgDecodedWalletHighloadV2 {
  final BigInt subwalletID;
  final String boundedQueryID;
  final List<DecodedRawMessage> rawMessages;

  const DecodedMessageExtInMsgDecodedWalletHighloadV2({
    required this.subwalletID,
    required this.boundedQueryID,
    required this.rawMessages,
  });

  factory DecodedMessageExtInMsgDecodedWalletHighloadV2.fromJson(
      Map<String, dynamic> json) {
    return DecodedMessageExtInMsgDecodedWalletHighloadV2(
      subwalletID: BigintUtils.parse(json['subwallet_id']),
      boundedQueryID: json['bounded_query_id'],
      rawMessages: List<DecodedRawMessage>.from(
          json['raw_messages'].map((x) => DecodedRawMessage.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() => {
        'subwallet_id': subwalletID.toString(),
        'bounded_query_id': boundedQueryID,
        'raw_messages': List<dynamic>.from(rawMessages.map((x) => x.toJson())),
      };
}
