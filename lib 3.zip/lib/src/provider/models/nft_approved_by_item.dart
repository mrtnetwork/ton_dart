class NftApprovedByItem {
  final String _value;

  const NftApprovedByItem._(this._value);

  static const NftApprovedByItem getgems = NftApprovedByItem._("getgems");
  static const NftApprovedByItem tonkeeper = NftApprovedByItem._("tonkeeper");
  static const NftApprovedByItem tonDiamonds =
      NftApprovedByItem._("ton.diamonds");

  static const List<NftApprovedByItem> values = [
    getgems,
    tonkeeper,
    tonDiamonds
  ];

  String get value => _value;

  static NftApprovedByItem fromName(String? name) {
    return values.firstWhere((element) => element.value == name,
        orElse: () => throw Exception(
            "No NftApprovedByItem found with the provided name: $name"));
  }
}
