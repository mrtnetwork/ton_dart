import 'account_address.dart';
import 'price.dart';

class Sale {
  final String address;
  final AccountAddress market;
  final AccountAddress? owner;
  final Price price;

  const Sale(
      {required this.address,
      required this.market,
      this.owner,
      required this.price});

  factory Sale.fromJson(Map<String, dynamic> json) {
    return Sale(
      address: json['address'],
      market: AccountAddress.fromJson(json['market']),
      owner:
          json['owner'] != null ? AccountAddress.fromJson(json['owner']) : null,
      price: Price.fromJson(json['price']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'address': address,
      'market': market.toJson(),
      'price': price.toJson(),
      'owner': owner?.toJson()
    };
  }
}
