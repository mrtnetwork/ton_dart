class NftItemCollection {
  final String address;
  final String name;
  final String description;

  const NftItemCollection({
    required this.address,
    required this.name,
    required this.description,
  });

  factory NftItemCollection.fromJson(Map<String, dynamic> json) {
    return NftItemCollection(
        address: json['address'],
        name: json['name'],
        description: json['description']);
  }

  Map<String, dynamic> toJson() =>
      {'address': address, 'name': name, 'description': description};
}
