import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';

class SubscriptionAction {
  final AccountAddress subscriber;
  final String subscription;
  final AccountAddress beneficiary;
  final BigInt amount;
  final bool initial;

  const SubscriptionAction({
    required this.subscriber,
    required this.subscription,
    required this.beneficiary,
    required this.amount,
    required this.initial,
  });

  factory SubscriptionAction.fromJson(Map<String, dynamic> json) {
    return SubscriptionAction(
      subscriber: AccountAddress.fromJson(json['subscriber']),
      subscription: json['subscription'],
      beneficiary: AccountAddress.fromJson(json['beneficiary']),
      amount: BigintUtils.parse(json['amount']),
      initial: json['initial'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'subscriber': subscriber.toJson(),
      'subscription': subscription,
      'beneficiary': beneficiary.toJson(),
      'amount': amount.toString(),
      'initial': initial,
    };
  }
}
