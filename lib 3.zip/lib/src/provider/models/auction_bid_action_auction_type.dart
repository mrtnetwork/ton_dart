class AuctionBidActionAuctionType {
  final String _value;

  const AuctionBidActionAuctionType._(this._value);

  static const AuctionBidActionAuctionType dnsTon =
      AuctionBidActionAuctionType._("DNS.ton");
  static const AuctionBidActionAuctionType dnsTg =
      AuctionBidActionAuctionType._("DNS.tg");
  static const AuctionBidActionAuctionType numberTg =
      AuctionBidActionAuctionType._("NUMBER.tg");
  static const AuctionBidActionAuctionType getgems =
      AuctionBidActionAuctionType._("getgems");

  static const List<AuctionBidActionAuctionType> values = [
    dnsTon,
    dnsTg,
    numberTg,
    getgems,
  ];

  String get value => _value;

  static AuctionBidActionAuctionType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw Exception(
          "No AuctionBidActionAuctionType found with the provided name: $name"),
    );
  }
}
