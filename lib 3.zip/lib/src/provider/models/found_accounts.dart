import 'found_accounts_addresses_item.dart';

class FoundAccounts {
  final List<FoundAccountsAddressesItem> addresses;

  const FoundAccounts({required this.addresses});

  factory FoundAccounts.fromJson(Map<String, dynamic> json) {
    return FoundAccounts(
        addresses: List<FoundAccountsAddressesItem>.from(
            (json['addresses'] as List)
                .map((x) => FoundAccountsAddressesItem.fromJson(x))));
  }

  Map<String, dynamic> toJson() {
    return {'addresses': addresses.map((x) => x.toJson()).toList()};
  }
}
