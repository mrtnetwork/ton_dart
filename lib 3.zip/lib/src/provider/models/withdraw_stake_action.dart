import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';
import 'pool_implementation_type.dart';

class WithdrawStakeAction {
  final BigInt amount;
  final AccountAddress staker;
  final AccountAddress pool;
  final PoolImplementationType implementation;

  const WithdrawStakeAction(
      {required this.amount,
      required this.staker,
      required this.pool,
      required this.implementation});

  factory WithdrawStakeAction.fromJson(Map<String, dynamic> json) {
    return WithdrawStakeAction(
        amount: BigintUtils.parse(json['amount']),
        staker: AccountAddress.fromJson(json['staker']),
        pool: AccountAddress.fromJson(json['pool']),
        implementation:
            PoolImplementationType.fromName(json['implementation']));
  }

  Map<String, dynamic> toJson() {
    return {
      'amount': amount.toString(),
      'staker': staker.toJson(),
      'pool': pool.toJson(),
      'implementation': implementation.value
    };
  }
}
