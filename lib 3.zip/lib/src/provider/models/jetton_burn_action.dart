import 'account_address.dart';
import 'jetton_preview.dart';

class JettonBurnAction {
  final AccountAddress sender;
  final String sendersWallet;
  final String amount;
  final JettonPreview jetton;

  const JettonBurnAction({
    required this.sender,
    required this.sendersWallet,
    required this.amount,
    required this.jetton,
  });

  factory JettonBurnAction.fromJson(Map<String, dynamic> json) {
    return JettonBurnAction(
      sender: AccountAddress.fromJson(json['sender']),
      sendersWallet: json['senders_wallet'],
      amount: json['amount'],
      jetton: JettonPreview.fromJson(json['jetton']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'sender': sender.toJson(),
      'senders_wallet': sendersWallet,
      'amount': amount,
      'jetton': jetton.toJson(),
    };
  }
}
