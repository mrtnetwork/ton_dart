class ServiceStatus {
  final bool restOnline;
  final int indexingLatency;

  const ServiceStatus(
      {required this.restOnline, required this.indexingLatency});

  factory ServiceStatus.fromJson(Map<String, dynamic> json) {
    return ServiceStatus(
      restOnline: json['rest_online'],
      indexingLatency: json['indexing_latency'],
    );
  }

  Map<String, dynamic> toJson() {
    return {'rest_online': restOnline, 'indexing_latency': indexingLatency};
  }
}
