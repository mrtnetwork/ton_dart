import 'blockchain_block.dart';

class BlockchainBlockShardsShardsItem {
  final String lastKnownBlockId;
  final BlockchainBlock lastKnownBlock;

  const BlockchainBlockShardsShardsItem(
      {required this.lastKnownBlockId, required this.lastKnownBlock});

  factory BlockchainBlockShardsShardsItem.fromJson(Map<String, dynamic> json) {
    return BlockchainBlockShardsShardsItem(
      lastKnownBlockId: json['last_known_block_id'],
      lastKnownBlock: BlockchainBlock.fromJson(json['last_known_block']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'last_known_block_id': lastKnownBlockId,
      'last_known_block': lastKnownBlock.toJson()
    };
  }
}
