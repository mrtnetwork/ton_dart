class TrustType {
  final String _value;

  const TrustType._(this._value);

  static const TrustType whitelist = TrustType._("whitelist");
  static const TrustType graylist = TrustType._("graylist");
  static const TrustType blacklist = TrustType._("blacklist");
  static const TrustType none = TrustType._("none");

  static const List<TrustType> values = [
    whitelist,
    graylist,
    blacklist,
    none,
  ];

  String get value => _value;

  static TrustType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () =>
          throw Exception("No TrustType found with the provided name: $name"),
    );
  }
}
