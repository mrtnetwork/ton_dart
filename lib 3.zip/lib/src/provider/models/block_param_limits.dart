import 'package:blockchain_utils/blockchain_utils.dart';

class BlockParamLimits {
  final BigInt underload;
  final BigInt softLimit;
  final BigInt hardLimit;

  const BlockParamLimits(
      {required this.underload,
      required this.softLimit,
      required this.hardLimit});

  factory BlockParamLimits.fromJson(Map<String, dynamic> json) {
    return BlockParamLimits(
      underload: BigintUtils.parse(json['underload']),
      softLimit: BigintUtils.parse(json['soft_limit']),
      hardLimit: BigintUtils.parse(json['hard_limit']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'underload': underload.toString(),
      'soft_limit': softLimit.toString(),
      'hard_limit': hardLimit.toString(),
    };
  }
}
