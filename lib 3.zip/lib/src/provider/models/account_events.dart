import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_event.dart';

class AccountEvents {
  final List<AccountEvent> events;
  final BigInt nextFrom;

  AccountEvents({
    required this.events,
    required this.nextFrom,
  });

  factory AccountEvents.fromJson(Map<String, dynamic> json) {
    return AccountEvents(
      events: (json['events'] as List<dynamic>)
          .map((e) => AccountEvent.fromJson(e))
          .toList(),
      nextFrom: BigintUtils.parse(json['next_from']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'next_from': nextFrom.toString(),
      'events': events.map((e) => e.toJson()).toList()
    };
  }
}
