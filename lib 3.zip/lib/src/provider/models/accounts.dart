import 'account.dart';

class Accounts {
  final List<Account> accounts;

  const Accounts({required this.accounts});

  factory Accounts.fromJson(Map<String, dynamic> json) {
    return Accounts(
        accounts: List<Account>.from((json['accounts'] as List)
            .map((account) => Account.fromJson(account))));
  }

  Map<String, dynamic> toJson() =>
      {'accounts': accounts.map((account) => account.toJson()).toList()};
}
