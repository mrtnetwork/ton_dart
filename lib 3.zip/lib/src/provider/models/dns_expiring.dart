import 'dns_expiring_items_item.dart';

class DnsExpiring {
  final List<DnsExpiringItemsItem> items;

  const DnsExpiring({required this.items});

  factory DnsExpiring.fromJson(Map<String, dynamic> json) {
    return DnsExpiring(
      items: List<DnsExpiringItemsItem>.from(
          json['items'].map((x) => DnsExpiringItemsItem.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() {
    return {'items': items.map((x) => x.toJson()).toList()};
  }
}
