class AccStatusChange {
  final String _value;

  const AccStatusChange._(this._value);

  static const AccStatusChange acstUnchanged =
      AccStatusChange._("acst_unchanged");
  static const AccStatusChange acstFrozen = AccStatusChange._("acst_frozen");
  static const AccStatusChange acstDeleted = AccStatusChange._("acst_deleted");

  static const List<AccStatusChange> values = [
    acstUnchanged,
    acstFrozen,
    acstDeleted,
  ];

  String get value => _value;

  static AccStatusChange fromName(String? name) {
    return values.firstWhere(
      (element) => element._value == name,
      orElse: () => throw Exception(
          "No AccStatusChange found with the provided name: $name"),
    );
  }
}
