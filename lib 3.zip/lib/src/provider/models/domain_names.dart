import 'package:ton_dart/src/serialization/serialization.dart';

class DomainNames with JsonSerialization {
  final List<String> domains;

  const DomainNames({required this.domains});

  factory DomainNames.fromJson(Map<String, dynamic> json) {
    return DomainNames(domains: List<String>.from(json['domains']));
  }

  @override
  Map<String, dynamic> toJson() {
    return {'domains': domains};
  }
}
