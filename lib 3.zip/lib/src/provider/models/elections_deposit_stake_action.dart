import 'package:blockchain_utils/numbers/numbers.dart';

import 'account_address.dart';

class ElectionsDepositStakeAction {
  final BigInt amount;
  final AccountAddress staker;

  const ElectionsDepositStakeAction(
      {required this.amount, required this.staker});

  factory ElectionsDepositStakeAction.fromJson(Map<String, dynamic> json) {
    return ElectionsDepositStakeAction(
      amount: BigintUtils.parse(json['amount']),
      staker: AccountAddress.fromJson(json['staker']),
    );
  }

  Map<String, dynamic> toJson() {
    return {'amount': amount.toString(), 'staker': staker.toJson()};
  }
}
