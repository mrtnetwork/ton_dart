import 'package:blockchain_utils/numbers/numbers.dart';

import 'validator.dart';

class Validators {
  final BigInt electAt;
  final BigInt electClose;
  final BigInt minStake;
  final BigInt totalStake;
  final List<Validator> validators;

  const Validators({
    required this.electAt,
    required this.electClose,
    required this.minStake,
    required this.totalStake,
    required this.validators,
  });

  factory Validators.fromJson(Map<String, dynamic> json) {
    return Validators(
      electAt: BigintUtils.parse(json['elect_at']),
      electClose: BigintUtils.parse(json['elect_close']),
      minStake: BigintUtils.parse(json['min_stake']),
      totalStake: BigintUtils.parse(json['total_stake']),
      validators: List<Validator>.from(
          (json['validators'] as List).map((x) => Validator.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'elect_at': electAt.toString(),
      'elect_close': electClose.toString(),
      'min_stake': minStake.toString(),
      'total_stake': totalStake.toString(),
      'validators': List<dynamic>.from(validators.map((x) => x.toJson())),
    };
  }
}
