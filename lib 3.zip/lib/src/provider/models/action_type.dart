class ActionType {
  final String _value;

  const ActionType._(this._value);

  static const ActionType tonTransfer = ActionType._("TonTransfer");
  static const ActionType jettonTransfer = ActionType._("JettonTransfer");
  static const ActionType jettonBurn = ActionType._("JettonBurn");
  static const ActionType jettonMint = ActionType._("JettonMint");
  static const ActionType nftItemTransfer = ActionType._("NftItemTransfer");
  static const ActionType contractDeploy = ActionType._("ContractDeploy");
  static const ActionType subscribe = ActionType._("Subscribe");
  static const ActionType unSubscribe = ActionType._("UnSubscribe");
  static const ActionType auctionBid = ActionType._("AuctionBid");
  static const ActionType nftPurchase = ActionType._("NftPurchase");
  static const ActionType depositStake = ActionType._("DepositStake");
  static const ActionType withdrawStake = ActionType._("WithdrawStake");
  static const ActionType withdrawStakeRequest =
      ActionType._("WithdrawStakeRequest");
  static const ActionType jettonSwap = ActionType._("JettonSwap");
  static const ActionType smartContractExec = ActionType._("SmartContractExec");
  static const ActionType electionsRecoverStake =
      ActionType._("ElectionsRecoverStake");
  static const ActionType electionsDepositStake =
      ActionType._("ElectionsDepositStake");
  static const ActionType domainRenew = ActionType._("DomainRenew");
  static const ActionType inscriptionTransfer =
      ActionType._("InscriptionTransfer");
  static const ActionType inscriptionMint = ActionType._("InscriptionMint");
  static const ActionType unknown = ActionType._("Unknown");

  static const List<ActionType> values = [
    tonTransfer,
    jettonTransfer,
    jettonBurn,
    jettonMint,
    nftItemTransfer,
    contractDeploy,
    subscribe,
    unSubscribe,
    auctionBid,
    nftPurchase,
    depositStake,
    withdrawStake,
    withdrawStakeRequest,
    jettonSwap,
    smartContractExec,
    electionsRecoverStake,
    electionsDepositStake,
    domainRenew,
    inscriptionTransfer,
    inscriptionMint,
    unknown,
  ];

  String get value => _value;

  static ActionType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () =>
          throw Exception("No ActionType found with the provided name: $name"),
    );
  }
}
