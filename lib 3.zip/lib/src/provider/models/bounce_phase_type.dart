import 'package:blockchain_utils/exception/exception.dart';

class BouncePhaseType {
  final String _value;

  const BouncePhaseType._(this._value);

  static const BouncePhaseType trPhaseBounceNegfunds =
      BouncePhaseType._("TrPhaseBounceNegfunds");
  static const BouncePhaseType trPhaseBounceNofunds =
      BouncePhaseType._("TrPhaseBounceNofunds");
  static const BouncePhaseType trPhaseBounceOk =
      BouncePhaseType._("TrPhaseBounceOk");

  static const List<BouncePhaseType> values = [
    trPhaseBounceNegfunds,
    trPhaseBounceNofunds,
    trPhaseBounceOk,
  ];

  String get value => _value;
  static BouncePhaseType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw MessageException(
          "No BouncePhaseType find with provided name.",
          details: {"name": name}),
    );
  }
}
