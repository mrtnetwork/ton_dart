class ApyHistory {
  final double apy;
  final int time;

  ApyHistory({
    required this.apy,
    required this.time,
  });

  factory ApyHistory.fromJson(Map<String, dynamic> json) {
    return ApyHistory(
      apy: json['apy'],
      time: json['time'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'apy': apy,
      'time': time,
    };
  }
}
