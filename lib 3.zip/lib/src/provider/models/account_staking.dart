import 'account_staking_info.dart';

class AccountStaking {
  final List<AccountStakingInfo> pools;

  AccountStaking({
    required this.pools,
  });

  factory AccountStaking.fromJson(Map<String, dynamic> json) {
    return AccountStaking(
      pools: List<AccountStakingInfo>.from(
          json['pools'].map((x) => AccountStakingInfo.fromJson(x))),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'pools': pools.map((x) => x.toJson()).toList(),
    };
  }
}
