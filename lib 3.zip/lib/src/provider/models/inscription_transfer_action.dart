import 'account_address.dart';
import 'incription_balance_type.dart';

class InscriptionTransferAction {
  final AccountAddress sender;
  final AccountAddress recipient;
  final String amount;
  final String? comment;
  final InscriptionType type;
  final String ticker;
  final int decimals;

  const InscriptionTransferAction({
    required this.sender,
    required this.recipient,
    required this.amount,
    this.comment,
    required this.type,
    required this.ticker,
    required this.decimals,
  });

  factory InscriptionTransferAction.fromJson(Map<String, dynamic> json) {
    return InscriptionTransferAction(
        sender: AccountAddress.fromJson(json['sender']),
        recipient: AccountAddress.fromJson(json['recipient']),
        amount: json['amount'],
        comment: json['comment'],
        type: InscriptionType.fromName(json['type']),
        ticker: json['ticker'],
        decimals: json['decimals']);
  }

  Map<String, dynamic> toJson() {
    return {
      'sender': sender.toJson(),
      'recipient': recipient.toJson(),
      'amount': amount,
      'comment': comment,
      'type': type.value,
      'ticker': ticker,
      'decimals': decimals,
    };
  }
}
