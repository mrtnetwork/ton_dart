import 'package:blockchain_utils/numbers/numbers.dart';

import 'auction.dart';

class Auctions {
  final List<Auction> data;
  final BigInt total;

  const Auctions({required this.data, required this.total});

  factory Auctions.fromJson(Map<String, dynamic> json) {
    return Auctions(
        data: List<Auction>.from(json['data'].map((x) => Auction.fromJson(x))),
        total: BigintUtils.parse(json['total']));
  }

  Map<String, dynamic> toJson() {
    return {
      'data': this.data.map((auction) => auction.toJson()).toList(),
      'total': total.toString(),
    };
  }
}
