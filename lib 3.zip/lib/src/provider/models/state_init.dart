class StateInit {
  final String boc;

  const StateInit({required this.boc});

  factory StateInit.fromJson(Map<String, dynamic> json) {
    return StateInit(boc: json['boc']);
  }

  Map<String, dynamic> toJson() {
    return {'boc': boc};
  }
}
