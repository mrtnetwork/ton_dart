class JettonVerificationType {
  final String _value;

  const JettonVerificationType._(this._value);

  static const JettonVerificationType whitelist =
      JettonVerificationType._("whitelist");
  static const JettonVerificationType blacklist =
      JettonVerificationType._("blacklist");
  static const JettonVerificationType none = JettonVerificationType._("none");

  static const List<JettonVerificationType> values = [
    whitelist,
    blacklist,
    none
  ];

  String get value => _value;

  static JettonVerificationType fromName(String? name) {
    return values.firstWhere(
      (element) => element._value == name,
      orElse: () => throw Exception(
          "No JettonVerificationType found with the provided name: $name"),
    );
  }
}
