import 'package:blockchain_utils/numbers/numbers.dart';

import 'acc_status_change.dart';

class StoragePhase {
  final BigInt feesCollected;
  final BigInt? feesDue;
  final AccStatusChange statusChange;

  const StoragePhase({
    required this.feesCollected,
    this.feesDue,
    required this.statusChange,
  });

  factory StoragePhase.fromJson(Map<String, dynamic> json) {
    return StoragePhase(
      feesCollected: BigintUtils.parse(json['fees_collected']),
      feesDue: BigintUtils.tryParse(json['fees_due']),
      statusChange: AccStatusChange.fromName(json['status_change']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'fees_collected': feesCollected.toString(),
      'fees_due': feesDue?.toString(),
      'status_change': statusChange.value,
    };
  }
}
