import 'inscription_balance.dart';

class InscriptionBalances {
  final List<InscriptionBalance> inscriptions;

  const InscriptionBalances({required this.inscriptions});

  factory InscriptionBalances.fromJson(Map<String, dynamic> json) {
    return InscriptionBalances(
        inscriptions: List<InscriptionBalance>.from(
            (json['inscriptions'] as List)
                .map((x) => InscriptionBalance.fromJson(x))));
  }

  Map<String, dynamic> toJson() {
    return {
      'inscriptions':
          inscriptions.map((inscription) => inscription.toJson()).toList(),
    };
  }
}
