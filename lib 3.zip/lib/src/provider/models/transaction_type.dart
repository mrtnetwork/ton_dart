import 'package:blockchain_utils/blockchain_utils.dart';

class TransactionType {
  final String _value;

  const TransactionType._(this._value);

  static const TransactionType transOrd = TransactionType._("TransOrd");
  static const TransactionType transTickTock =
      TransactionType._("TransTickTock");
  static const TransactionType transSplitPrepare =
      TransactionType._("TransSplitPrepare");
  static const TransactionType transSplitInstall =
      TransactionType._("TransSplitInstall");
  static const TransactionType transMergePrepare =
      TransactionType._("TransMergePrepare");
  static const TransactionType transMergeInstall =
      TransactionType._("TransMergeInstall");
  static const TransactionType transStorage = TransactionType._("TransStorage");

  static const List<TransactionType> values = [
    transOrd,
    transTickTock,
    transSplitPrepare,
    transSplitInstall,
    transMergePrepare,
    transMergeInstall,
    transStorage,
  ];

  String get value => _value;

  static TransactionType fromName(String? name) {
    return values.firstWhere(
      (element) => element.value == name,
      orElse: () => throw MessageException(
          "No TransactionType find with provided name.",
          details: {"name": name}),
    );
  }
}
