import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/account_events.dart';

/// GetAccountInscriptionsHistoryByTicker invokes getAccountInscriptionsHistoryByTicker operation.
///
/// Get the transfer inscriptions history for account. It's experimental API and can be dropped in the
/// future.
///
class TonApiGetAccountInscriptionsHistoryByTicker
    extends TonApiRequestParam<AccountEvents, Map<String, dynamic>> {
  final String accountId;
  final String ticker;
  final String? acceptLanguage;

  /// omit this parameter to get last events
  final BigInt? beforeLt;

  /// default: 100
  final int? limit;

  TonApiGetAccountInscriptionsHistoryByTicker(
      {required this.accountId,
      required this.ticker,
      this.acceptLanguage,
      this.beforeLt,
      this.limit});

  @override
  String get method => TonApiMethods.getaccountinscriptionshistorybyticker.url;

  @override
  List<String> get pathParameters => [accountId, ticker];

  @override
  Map<String, dynamic> get queryParameters =>
      {"limit": limit, "before_lt": beforeLt};

  @override
  Map<String, String?> get header => {"Accept-Language": acceptLanguage};

  @override
  AccountEvents onResonse(Map<String, dynamic> json) {
    return AccountEvents.fromJson(json);
  }
}
