import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/nft_collection.dart';

/// GetNftCollection invokes getNftCollection operation.
///
/// Get NFT collection by collection address.
///
class TonApiGetNftCollection
    extends TonApiRequestParam<NftCollection, Map<String, dynamic>> {
  final String accountId;
  TonApiGetNftCollection(this.accountId);
  @override
  String get method => TonApiMethods.getnftcollection.url;

  @override
  List<String> get pathParameters => [accountId];

  @override
  NftCollection onResonse(Map<String, dynamic> json) {
    return NftCollection.fromJson(json);
  }
}
