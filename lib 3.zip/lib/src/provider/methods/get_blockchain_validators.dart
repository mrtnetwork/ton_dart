import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/validators.dart';

/// GetBlockchainValidators invokes getBlockchainValidators operation.
///
/// Get blockchain validators.
///
class TonApiGetBlockchainValidators
    extends TonApiRequestParam<Validators, Map<String, dynamic>> {
  @override
  String get method => TonApiMethods.getblockchainvalidators.url;

  @override
  Validators onResonse(Map<String, dynamic> json) {
    return Validators.fromJson(json);
  }
}
