import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/blockchain_account_inspect.dart';

/// BlockchainAccountInspect invokes blockchainAccountInspect operation.
///
/// Blockchain account inspect.
///
class TonApiBlockchainAccountInspect
    extends TonApiRequestParam<BlockchainAccountInspect, Map<String, dynamic>> {
  final String accountId;
  TonApiBlockchainAccountInspect(this.accountId);
  @override
  String get method => TonApiMethods.blockchainaccountinspect.url;

  @override
  List<String> get pathParameters => [accountId];

  @override
  BlockchainAccountInspect onResonse(Map<String, dynamic> json) {
    return BlockchainAccountInspect.fromJson(json);
  }
}
