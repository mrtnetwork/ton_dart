import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/found_accounts.dart';

/// SearchAccounts invokes searchAccounts operation.
///
/// Search by account domain name.
///
class TonApiSearchAccounts
    extends TonApiRequestParam<FoundAccounts, Map<String, dynamic>> {
  final String name;
  TonApiSearchAccounts(this.name);

  @override
  String get method => TonApiMethods.searchaccounts.url;

  @override
  List<String> get pathParameters => [];

  @override
  Map<String, dynamic> get queryParameters => {"name": name};

  @override
  FoundAccounts onResonse(Map<String, dynamic> json) {
    return FoundAccounts.fromJson(json);
  }
}
