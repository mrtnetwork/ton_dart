import 'package:ton_dart/src/provider/core/core.dart';
import 'package:ton_dart/src/provider/core/methods.dart';
import 'package:ton_dart/src/provider/models/nft_item.dart';

/// GetNftItemByAddress invokes getNftItemByAddress operation.
///
/// Get NFT item by its address.
///
class TonApiGetNftItemByAddress
    extends TonApiRequestParam<NftItem, Map<String, dynamic>> {
  final String accountId;
  TonApiGetNftItemByAddress(this.accountId);
  @override
  String get method => TonApiMethods.getnftitembyaddress.url;

  @override
  List<String> get pathParameters => [accountId];

  @override
  NftItem onResonse(Map<String, dynamic> json) {
    return NftItem.fromJson(json);
  }
}
