import 'package:blockchain_utils/exception/exceptions.dart';

class BocException extends BlockchainUtilsException {
  BocException(this.message, {this.details});
  @override
  final String message;
  final Map<String, dynamic>? details;
  @override
  String toString() {
    return "BocException($message)";
  }
}
