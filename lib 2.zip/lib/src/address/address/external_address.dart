import 'package:ton_dart/src/address/core/ton_address.dart';

class ExternalAddress implements TonBaseAddress {
  final BigInt value;
  final int bits;

  ExternalAddress(this.value, this.bits);

  @override
  String toString() {
    return 'External<$bits:$value>';
  }
}
