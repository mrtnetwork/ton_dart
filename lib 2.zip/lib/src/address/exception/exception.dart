import 'package:blockchain_utils/exception/exception.dart';

class TonAddressException extends BlockchainUtilsException {
  TonAddressException(this.message, {this.details});
  @override
  final String message;
  final Map<String, dynamic>? details;
  @override
  String toString() {
    return "TonAddressException($message)";
  }
}
