import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/cell_type.dart';
import 'package:ton_dart/src/boc/utils/utils.dart';

int getRefsDescriptor(List<Cell> refs, int levelMask, CellType type) {
  return refs.length + (type != CellType.ordinary ? 1 : 0) * 8 + levelMask * 32;
}

int getBitsDescriptor(BitString bits) {
  var len = bits.length;
  return ((len / 8).ceil() + (len / 8).floor()).toInt();
}

List<int> getRepr(BitString originalBits, BitString bits, List<Cell> refs,
    int level, int levelMask, CellType type) {
  // Allocate
  var bitsLen = (bits.length / 8).ceil();
  var repr = List<int>.filled(2 + bitsLen + (2 + 32) * refs.length, 0);

  // Write descriptors
  var reprCursor = 0;
  repr[reprCursor++] = getRefsDescriptor(refs, levelMask, type);
  repr[reprCursor++] = getBitsDescriptor(originalBits);

  // Write bits
  final buff =
      BocUtils.bitsToPaddedBuffer(bits).buffer(); //.copy(repr, reprCursor);
  for (var i = 0; i < buff.length; i++) {
    repr[reprCursor + i] = buff[i];
  }
  reprCursor += bitsLen;

  // Write refs
  for (var c in refs) {
    int childDepth;
    if (type == CellType.merkleProof || type == CellType.merkleUpdate) {
      childDepth = c.depth(level: level + 1);
    } else {
      childDepth = c.depth(level: level);
    }
    repr[reprCursor++] = (childDepth / 256).floor();
    repr[reprCursor++] = childDepth % 256;
  }
  for (var c in refs) {
    List<int> childHash;
    if (type == CellType.merkleProof || type == CellType.merkleUpdate) {
      childHash = c.hash(level: level + 1);
    } else {
      childHash = c.hash(level: level);
    }
    repr.setRange(reprCursor, reprCursor + 32, childHash);
    reprCursor += 32;
  }

  // Result
  return repr;
}
