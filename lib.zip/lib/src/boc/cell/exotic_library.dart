import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';

Map<String, dynamic> exoticLibrary(BitString bits, List<Cell> refs) {
  var reader = BitReader(bits);

  // type + hash
  var size = 8 + 256;

  if (bits.length != size) {
    throw Exception(
        'Library cell must have exactly (8 + 256) bits, got "${bits.length}"');
  }

  var type = reader.loadUint(8);
  if (type != 2) {
    throw Exception('Library cell must have type 2, got "$type"');
  }

  return {};
}
