import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';

import 'level_mask.dart';

class ExoticPruned {
  final int mask;
  final List<Map<String, dynamic>> pruned;

  ExoticPruned({required this.mask, required this.pruned});
}

ExoticPruned exoticPruned(BitString bits, List<Cell> refs) {
  var reader = BitReader(bits);

  final int type = reader.loadUint(8);
  if (type != 1) {
    throw Exception('Pruned branch cell must have type 1, got "$type"');
  }

  if (refs.isNotEmpty) {
    throw Exception(
        'Pruned Branch cell can\'t have refs, got "${refs.length}"');
  }

  LevelMask mask;
  if (bits.length == 280) {
    mask = LevelMask(mask: 1);
  } else {
    final read8 = reader.loadUint(8);
    mask = LevelMask(mask: read8);

    if (mask.level < 1 || mask.level > 3) {
      throw Exception(
          'Pruned Branch cell level must be >= 1 and <= 3, got "${mask.level}/${mask.value}"');
    }

    var size = 8 + 8 + (mask.apply(mask.level - 1).hashCount * (256 + 16));
    if (bits.length != size) {
      throw Exception(
          'Pruned branch cell must have exactly $size bits, got "${bits.length}"');
    }
  }

  var pruned = <Map<String, dynamic>>[];
  final List<List<int>> hashes = [];
  final List<int> depths = [];
  for (var i = 0; i < mask.level; i++) {
    hashes.add(reader.loadBuffer(32));
  }
  for (var i = 0; i < mask.level; i++) {
    depths.add(reader.loadUint(16));
  }
  for (var i = 0; i < mask.level; i++) {
    pruned.add({
      'depth': depths[i],
      'hash': hashes[i],
    });
  }

  return ExoticPruned(mask: mask.value, pruned: pruned);
}
