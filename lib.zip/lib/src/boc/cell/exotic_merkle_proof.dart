import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';

Map<String, dynamic> exoticMerkleProof(BitString bits, List<Cell> refs) {
  var reader = BitReader(bits);

  // type + hash + depth
  var size = 8 + 256 + 16;

  if (bits.length != size) {
    throw Exception(
        'Merkle Proof cell must have exactly (8 + 256 + 16) bits, got "${bits.length}"');
  }

  if (refs.length != 1) {
    throw Exception(
        'Merkle Proof cell must have exactly 1 ref, got "${refs.length}"');
  }

  var type = reader.loadUint(8);
  if (type != 3) {
    throw Exception('Merkle Proof cell must have type 3, got "$type"');
  }

  var proofHash = reader.loadBuffer(32);
  var proofDepth = reader.loadUint(16);
  var refHash = refs[0].hash(level: 0);
  var refDepth = refs[0].depth(level: 0);
  if (proofDepth != refDepth || !bytesEqual(proofHash, refHash)) {
    throw Exception('Mismatch in reference');
  }

  return {
    'proofDepth': proofDepth,
    'proofHash': proofHash,
  };
}

Cell convertToMerkleProof(Cell c) {
  return beginCell()
      .storeUint(3, 8)
      .storeBuffer(c.hash(level: 0))
      .storeUint(c.depth(level: 0), 16)
      .storeRef(c)
      .endCell(exotic: true);
}
