import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/cell/exotic_library.dart';
import 'package:ton_dart/src/boc/cell/exotic_merkle_proof.dart';
import 'package:ton_dart/src/boc/cell/exotic_merkle_update.dart';
import 'package:ton_dart/src/boc/cell/exotic_pruned.dart';
import 'package:ton_dart/src/boc/cell/level_mask.dart';
import 'package:ton_dart/src/boc/cell_type.dart';

Map<String, dynamic> resolvePruned(BitString bits, List<Cell> refs) {
  var pruned = exoticPruned(bits, refs);
  var depths = <int>[];
  final List<List<int>> hashes = [];
  var mask = LevelMask(mask: pruned.mask);
  for (var prunedEntry in pruned.pruned) {
    depths.add(prunedEntry['depth']);
    hashes.add(prunedEntry['hash']);
  }
  return {
    'type': CellType.prunedBranch,
    'depths': depths,
    'hashes': hashes,
    'mask': mask,
  };
}

Map<String, dynamic> resolveLibrary(BitString bits, List<Cell> refs) {
  exoticLibrary(bits, refs);
  var depths = <int>[];
  final List<List<int>> hashes = [];
  var mask = LevelMask();
  return {
    'type': CellType.library,
    'depths': depths,
    'hashes': hashes,
    'mask': mask,
  };
}

Map<String, dynamic> resolveMerkleProof(BitString bits, List<Cell> refs) {
  exoticMerkleProof(bits, refs);
  var depths = <int>[];
  final List<List<int>> hashes = [];
  var mask = LevelMask(mask: refs[0].level >> 1);
  return {
    'type': CellType.merkleProof,
    'depths': depths,
    'hashes': hashes,
    'mask': mask,
  };
}

Map<String, dynamic> resolveMerkleUpdate(BitString bits, List<Cell> refs) {
  exoticMerkleUpdate(bits, refs);
  var depths = <int>[];
  final List<List<int>> hashes = [];
  var mask = LevelMask(mask: (refs[0].level | refs[1].level) >> 1);
  return {
    'type': CellType.merkleUpdate,
    'depths': depths,
    'hashes': hashes,
    'mask': mask,
  };
}

Map<String, dynamic> resolveExotic(BitString bits, List<Cell> refs) {
  final BitReader reader = BitReader(bits);
  final int type = reader.preloadUint(8);

  if (type == 1) {
    return resolvePruned(bits, refs);
  }

  if (type == 2) {
    return resolveLibrary(bits, refs);
  }

  if (type == 3) {
    return resolveMerkleProof(bits, refs);
  }

  if (type == 4) {
    return resolveMerkleUpdate(bits, refs);
  }

  throw Exception('Invalid exotic cell type: $type');
}
