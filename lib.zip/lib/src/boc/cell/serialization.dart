import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/bit_builder.dart';
import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/cell/descriptor.dart';
import 'package:ton_dart/src/boc/cell/utils/utils.dart';
import 'package:ton_dart/src/boc/utils/utils.dart';
import 'package:ton_dart/src/utils/utils.dart';

int getHashesCount(int levelMask) {
  return getHashesCountFromMask(levelMask & 7);
}

int getHashesCountFromMask(int mask) {
  var n = 0;
  for (var i = 0; i < 3; i++) {
    n += (mask & 1);
    mask = mask >> 1;
  }
  return n + 1; // 1 repr + up to 3 higher hashes
}

Map<String, dynamic> parseBoc(List<int> src) {
  var reader = BitReader(BitString(src, 0, src.length * 8));
  var magic = reader.loadUint(32);

  if (magic == 0x68ff65f3) {
    var size = reader.loadUint(8);
    var offBytes = reader.loadUint(8);
    var cells = reader.loadUint(size * 8);
    var roots = reader.loadUint(size * 8); // Must be 1
    var absent = reader.loadUint(size * 8);
    var totalCellSize = reader.loadUint(offBytes * 8);
    var index = reader.loadBuffer(cells * offBytes);
    var cellData = reader.loadBuffer(totalCellSize);
    return {
      'size': size,
      'offBytes': offBytes,
      'cells': cells,
      'roots': roots,
      'absent': absent,
      'totalCellSize': totalCellSize,
      'index': index,
      'cellData': cellData,
      'root': [0]
    };
  } else if (magic == 0xacc3a728) {
    var size = reader.loadUint(8);
    var offBytes = reader.loadUint(8);
    var cells = reader.loadUint(size * 8);
    var roots = reader.loadUint(size * 8); // Must be 1
    var absent = reader.loadUint(size * 8);
    var totalCellSize = reader.loadUint(offBytes * 8);
    var index = reader.loadBuffer(cells * offBytes);
    var cellData = reader.loadBuffer(totalCellSize);
    var crc32 = reader.loadBuffer(4);
    if (!bytesEqual(TonUtils.crc32c(src.sublist(0, src.length - 4)), crc32)) {
      throw StateError('Invalid CRC32C');
    }
    return {
      'size': size,
      'offBytes': offBytes,
      'cells': cells,
      'roots': roots,
      'absent': absent,
      'totalCellSize': totalCellSize,
      'index': index,
      'cellData': cellData,
      'root': [0]
    };
  } else if (magic == 0xb5ee9c72) {
    int hasIdx = reader.loadUint(1);
    int hasCrc32c = reader.loadUint(1);
    reader.loadUint(1);
    reader.loadUint(2); // Must be 0
    int size = reader.loadUint(3);
    int offBytes = reader.loadUint(8);
    int cells = reader.loadUint(size * 8);
    int roots = reader.loadUint(size * 8);
    int absent = reader.loadUint(size * 8);
    int totalCellSize = reader.loadUint(offBytes * 8);

    ///     console.log("here yes ?!",hasIdx,hasCrc32c,hasCacheBits,flags,size,offBytes,cells,roots,absent);
    var root = <int>[];
    for (var i = 0; i < roots; i++) {
      root.add(reader.loadUint(size * 8));
    }
    List<int>? index;
    if (hasIdx == 1) {
      index = reader.loadBuffer(cells * offBytes);
    }
    var cellData = reader.loadBuffer(totalCellSize);
    if (hasCrc32c == 1) {
      var crc32 = reader.loadBuffer(4);
      if (!bytesEqual(TonUtils.crc32c(src.sublist(0, src.length - 4)), crc32)) {
        throw StateError('Invalid CRC32C');
      }
    }
    return {
      'size': size,
      'offBytes': offBytes,
      'cells': cells,
      'roots': roots,
      'absent': absent,
      'totalCellSize': totalCellSize,
      'index': index,
      'cellData': cellData,
      'root': root
    };
  } else {
    throw StateError('Invalid magic');
  }
}

int calcCellSize(Cell cell, int sizeBytes) {
  return 2 + // D1+D2
      ((cell.bits.length + 7) ~/ 8) + // Bits length divided by 8 (rounded up)
      cell.refs.length * sizeBytes;
}

void writeCellToBuilder(
    Cell cell, List<int> refs, int sizeBytes, BitBuilder to) {
  int d1 = getRefsDescriptor(cell.refs, cell.mask.value, cell.type);
  int d2 = getBitsDescriptor(cell.bits);
  to.writeUint(d1, 8);
  to.writeUint(d2, 8);
  to.writeBuffer(BocUtils.bitsToPaddedBuffer(cell.bits).buffer());
  for (int r in refs) {
    to.writeUint(r, sizeBytes * 8);
  }
}

List<int> serializeBoc(Cell root, {required bool idx, required bool crc32}) {
  // Sort cells
  var allCells = CellUtils.topologicalSort(root);

  // Calculate parameters
  var cellsNum = allCells.length;
  var hasIdx = idx;
  var hasCrc32c = crc32;
  var hasCacheBits = false;
  var flags = 0;
  int sizeBytes =
      (cellsNum.toRadixString(2).length / 8).ceil().clamp(1, 3).toInt();
  var totalCellSize = 0;
  var index = <int>[];
  for (var c in allCells) {
    var sz = calcCellSize(c["cell"], sizeBytes);
    totalCellSize += sz;
    index.add(totalCellSize);
  }
  var offsetBytes =
      (totalCellSize.toRadixString(2).length / 8).ceil().clamp(1, 3).toInt();
  var totalSize = (4 + // magic
          1 + // flags and s_bytes
          1 + // offset_bytes
          3 * sizeBytes + // cells_num, roots, complete
          offsetBytes + // full_size
          1 * sizeBytes + // root_idx
          (hasIdx ? cellsNum * offsetBytes : 0) +
          totalCellSize +
          (hasCrc32c ? 4 : 0)) *
      8;

  // Serialize
  var builder = BitBuilder(totalSize);
  builder.writeUint(0xb5ee9c72, 32); // Magic
  builder.writeBit(hasIdx); // Has index
  builder.writeBit(hasCrc32c); // Has crc32c
  builder.writeBit(hasCacheBits); // Has cache bits
  builder.writeUint(flags, 2); // Flags
  builder.writeUint(sizeBytes, 3); // Size bytes
  builder.writeUint(offsetBytes, 8); // Offset bytes
  builder.writeUint(cellsNum, sizeBytes * 8); // Cells num
  builder.writeUint(1, sizeBytes * 8); // Roots num
  builder.writeUint(0, sizeBytes * 8); // Absent num
  builder.writeUint(totalCellSize, offsetBytes * 8); // Total cell size
  builder.writeUint(0, sizeBytes * 8); // Root id == 0
  if (hasIdx) {
    // Index
    for (var i = 0; i < cellsNum; i++) {
      builder.writeUint(index[i], offsetBytes * 8);
    }
  }
  for (var i = 0; i < cellsNum; i++) {
    // Cells
    writeCellToBuilder(
        allCells[i]["cell"], allCells[i]["refs"], sizeBytes, builder);
  }
  if (hasCrc32c) {
    var crc32 = TonUtils.crc32c(builder
        .buffer()); // builder.buffer() is fast since it doesn't allocate new memory
    builder.writeBuffer(crc32);
  }

  // Sanity Check
  var res = builder.buffer();
  if (res.length != totalSize / 8) {
    throw StateError('Internal error');
  }
  return res;
}

// boc:  {

//     cellData: <Buffer 00 84 ff 00 20 dd a4 f2 60 81 02 00 d7 18 20 d7 0b 1f ed 44 d0 d3 1f d3 ff d1 51 12 ba f2 a1 22 f9 01 54 10 44 f9 10 f2 a2 f8 00 01 d3 1f 31 20 d7 4a ... 18 more bytes>,
//     root: [ 0 ]
//   }
List<Cell> deserializeBoc(List<int> src) {
  //
  // Parse BOC
  //

  final Map<String, dynamic> boc = parseBoc(src);
  BitReader reader = BitReader(
      BitString(boc["cellData"], 0, (boc["cellData"] as List).length * 8));

  //
  // Load cells
  //

  List<Map<String, dynamic>> cells = [];
  for (var i = 0; i < boc["cells"]; i++) {
    var cll = readCell(reader, boc["size"]);
    cll["result"] = null;
    cells.add(cll);
  }

  //
  // Build cells
  //
  for (int i = cells.length - 1; i >= 0; i--) {
    if (cells[i]["result"] != null) {
      throw Exception('Impossible');
    }
    List<Cell> refs = [];
    for (int r in cells[i]["refs"]) {
      if (cells[r]["result"] == null) {
        throw Exception('Invalid BOC file');
      }
      refs.add(cells[r]["result"]);
    }
    cells[i]["result"] =
        Cell(bits: cells[i]["bits"], refs: refs, exotic: cells[i]["exotic"]);
  }
  // for (int i = cells.length - 1; i >= 0; i--) {
  //   if (cells[i]["result"] != null) {
  //     throw Exception('Impossible');
  //   }
  //   var refs = <Cell>[];
  //   for (int b = 0; b < cells[i]["refs"].length; i++) {
  //     final r = cells[i]["refs"][b];
  //     if (r["result"] == null) {
  //       throw Exception('Invalid BOC file');
  //     }
  //     refs.add(r["result"]);
  //   }
  //   cells[i]["result"] =
  //       Cell(bits: cells[i]["bits"], refs: refs, exotic: cells[i]["exotic"]);
  // }

  //
  // Load roots
  //

  var roots = <Cell>[];
  for (var i = 0; i < boc["root"].length; i++) {
    roots.add(cells.elementAt(boc["root"][i])["result"]!);
  }

  //
  // Return
  //

  return roots;
}

Map<String, dynamic> readCell(BitReader reader, int sizeBytes) {
  // D1
  final d1 = reader.loadUint(8);
  final refsCount = d1 % 8;
  final exotic = (d1 & 8) != 0;

  // D2
  final d2 = reader.loadUint(8);
  final dataBytesize = (d2 / 2).ceil();
  final paddingAdded = (d2 % 2) != 0;

  final levelMask = d1 >> 5;
  final hasHashes = (d1 & 16) != 0;
  const hashBytes = 32;

  final hashesSize = hasHashes ? getHashesCount(levelMask) * hashBytes : 0;
  final depthSize = hasHashes ? getHashesCount(levelMask) * 2 : 0;

  reader.skip(hashesSize * 8);
  reader.skip(depthSize * 8);

  // Bits
  var bits = BitString.empty;
  if (dataBytesize > 0) {
    bits = paddingAdded
        ? reader.loadPaddedBits(dataBytesize * 8)
        : reader.loadBits(dataBytesize * 8);
  }

  // Refs
  final refsList = <int>[];
  for (var i = 0; i < refsCount; i++) {
    refsList.add(reader.loadUint(sizeBytes * 8));
  }
  return {"bits": bits, "refs": refsList, "exotic": exotic};

  // Result
  // return Cell(bits: bits, refs: refsList, exotic: exotic);
}
