import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/bit_reader.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';

/// type + hash + hash + depth + depth
const int _bitLengthSize = 8 + (2 * (256 + 16));

Map<String, dynamic> exoticMerkleUpdate(BitString bits, List<Cell> refs) {
  final BitReader reader = BitReader(bits);

  // // type + hash + hash + depth + depth
  // const size = 8 + (2 * (256 + 16));

  if (bits.length != _bitLengthSize) {
    throw Exception(
        'Merkle Update cell must have exactly $_bitLengthSize bits, got "${bits.length}"');
  }

  if (refs.length != 2) {
    throw Exception(
        'Merkle Update cell must have exactly 2 refs, got "${refs.length}"');
  }

  final int type = reader.loadUint(8);
  if (type != 4) {
    throw Exception('Merkle Update cell type must be exactly 4, got "$type"');
  }

  final List<int> proofHash1 = reader.loadBuffer(32);
  final List<int> proofHash2 = reader.loadBuffer(32);
  final int proofDepth1 = reader.loadUint(16);
  final int proofDepth2 = reader.loadUint(16);

  if (proofDepth1 != refs[0].depth(level: 0)) {
    throw Exception('Mismatch in reference 1');
  }
  if (!bytesEqual(proofHash1, refs[0].hash(level: 0))) {
    throw Exception("Merkle Update cell ref hash must be exactly");
  }

  if (proofDepth2 != refs[1].depth(level: 0)) {
    throw Exception('Mismatch in reference 2');
  }
  if (!bytesEqual(proofHash2, refs[1].hash(level: 0))) {
    throw Exception("Merkle Update cell ref hash must be exactly");
  }

  return {
    'proofDepth1': proofDepth1,
    'proofDepth2': proofDepth2,
    'proofHash1': proofHash1,
    'proofHash2': proofHash2,
  };
}
