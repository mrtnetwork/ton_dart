import 'package:blockchain_utils/binary/utils.dart';
import 'package:ton_dart/src/boc/cell.dart';

class CellUtils {
  static List<Map<String, dynamic>> topologicalSort(Cell src) {
    var pending = [src];
    var allCells = <String, Map<String, dynamic>>{};
    final notPermCells = <String>{};
    var sorted = <String>[];
    while (pending.isNotEmpty) {
      var cells = List<Cell>.from(pending);
      pending = [];
      for (var cell in cells) {
        final String hash = BytesUtils.toHexString(cell.hash());
        if (allCells.containsKey(hash)) {
          continue;
        }
        notPermCells.add(hash);
        allCells[hash] = {
          'cell': cell,
          'refs':
              cell.refs.map((v) => BytesUtils.toHexString(v.hash())).toList()
        };
        for (var r in cell.refs) {
          pending.add(r);
        }
      }
    }
    var tempMark = <String>{};

    void visit(String hash) {
      if (!notPermCells.contains(hash)) {
        return;
      }
      if (tempMark.contains(hash)) {
        throw StateError('Not a DAG');
      }
      tempMark.add(hash);

      var refs = List<String>.from(allCells[hash]!['refs']);
      for (var ci = refs.length - 1; ci >= 0; ci--) {
        visit(refs[ci]);
      }
      sorted.add(hash);
      tempMark.remove(hash);
      notPermCells.remove(hash);
    }

    while (notPermCells.isNotEmpty) {
      var id = notPermCells.first;
      visit(id);
    }

    var indexes = <String, int>{};
    for (var i = 0; i < sorted.length; i++) {
      indexes[sorted[sorted.length - i - 1]] = i;
    }

    var result = <Map<String, dynamic>>[];
    for (var i = sorted.length - 1; i >= 0; i--) {
      var ent = sorted[i];
      var rrr = allCells[ent]!;
      result.add({
        'cell': rrr['cell'],
        'refs': (rrr['refs'] as List).map((v) => indexes[v]!).toList()
      });
    }

    return result;
  }
}
