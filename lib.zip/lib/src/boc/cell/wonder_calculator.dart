import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/cell/descriptor.dart';
import 'package:ton_dart/src/boc/cell/exotic_library.dart';
import 'package:ton_dart/src/boc/cell/exotic_merkle_proof.dart';
import 'package:ton_dart/src/boc/cell/exotic_merkle_update.dart';
import 'package:ton_dart/src/boc/cell/exotic_pruned.dart';
import 'package:ton_dart/src/boc/cell/level_mask.dart';
import 'package:ton_dart/src/boc/cell_type.dart';
import 'dart:math' as math;

Map<String, dynamic> wonderCalculator(
    CellType type, BitString bits, List<Cell> refs) {
  //
  // Resolving level mask
  //

  LevelMask levelMask;
  ExoticPruned? pruned;
  if (type == CellType.ordinary) {
    var mask = 0;
    for (var r in refs) {
      mask |= r.mask.value;
    }
    levelMask = LevelMask(mask: mask);
  } else if (type == CellType.prunedBranch) {
    pruned = exoticPruned(bits, refs);
    levelMask = LevelMask(mask: pruned.mask);
  } else if (type == CellType.merkleProof) {
    exoticMerkleProof(bits, refs);
    levelMask = LevelMask(mask: refs[0].mask.value >> 1);
  } else if (type == CellType.merkleUpdate) {
    exoticMerkleUpdate(bits, refs);
    levelMask = LevelMask(mask: (refs[0].mask.value | refs[1].mask.value) >> 1);
  } else if (type == CellType.library) {
    exoticLibrary(bits, refs);
    levelMask = LevelMask();
  } else {
    throw ArgumentError("Unsupported exotic type");
  }

  //
  // Calculate hashes and depths
  //

  List<int> depths = [];
  List<List<int>> hashes = [];

  int hashCount = type == CellType.prunedBranch ? 1 : levelMask.hashCount;
  int totalHashCount = levelMask.hashCount;
  int hashIOffset = totalHashCount - hashCount;
  for (int levelI = 0, hashI = 0; levelI <= levelMask.level; levelI++) {
    if (!levelMask.isSignificant(levelI)) {
      continue;
    }

    if (hashI < hashIOffset) {
      hashI++;
      continue;
    }

    BitString currentBits;
    if (hashI == hashIOffset) {
      if (!(levelI == 0 || type == CellType.prunedBranch)) {
        throw ArgumentError('Invalid');
      }
      currentBits = bits;
    } else {
      if (!(levelI != 0 && type != CellType.prunedBranch)) {
        throw ArgumentError('Invalid: $levelI, $type');
      }
      currentBits = BitString(hashes[hashI - hashIOffset - 1], 0, 256);
    }

    int currentDepth = 0;
    for (var c in refs) {
      int childDepth;
      if (type == CellType.merkleProof || type == CellType.merkleUpdate) {
        childDepth = c.depth(level: levelI + 1);
      } else {
        childDepth = c.depth(level: levelI);
      }
      currentDepth = math.max(currentDepth, childDepth);
    }
    if (refs.isNotEmpty) {
      currentDepth++;
    }

    List<int> repr = getRepr(
        bits, currentBits, refs, levelI, levelMask.apply(levelI).value, type);
    List<int> hash = QuickCrypto.sha256Hash(repr);

    int destI = hashI - hashIOffset;
    depths.insert(destI, currentDepth);
    hashes.insert(destI, hash);

    hashI++;
  }

  //
  // Calculate hash and depth for all levels
  //

  final List<List<int>> resolvedHashes = [];
  final List<int> resolvedDepths = [];
  if (pruned != null) {
    for (var i = 0; i < 4; i++) {
      var hashIndex = levelMask.apply(i).hashIndex;
      var thisHashIndex = levelMask.hashIndex;
      if (hashIndex != thisHashIndex) {
        resolvedHashes.add(pruned.pruned[hashIndex]["hash"]);
        resolvedDepths.add(pruned.pruned[hashIndex]["depth"]);
      } else {
        resolvedHashes.add(hashes[0]);
        resolvedDepths.add(depths[0]);
      }
    }
  } else {
    for (var i = 0; i < 4; i++) {
      resolvedHashes.add(hashes[levelMask.apply(i).hashIndex]);
      resolvedDepths.add(depths[levelMask.apply(i).hashIndex]);
    }
  }

  //
  // Result
  //

  return {
    'mask': levelMask,
    'hashes': resolvedHashes,
    'depths': resolvedDepths,
  };
}
