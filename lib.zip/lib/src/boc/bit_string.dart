import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/utils/utils.dart';

class BitString {
  static final BitString empty = BitString(const <int>[], 0, 0);

  final int _offset;
  final int _length;
  final List<int> _data;

  BitString(this._data, this._offset, this._length) {
    if (_length < 0) {
      throw ArgumentError('Length $_length is out of bounds');
    }
  }

  static bool isBitString(dynamic src) {
    return src is BitString;
  }

  int get length => _length;

  bool at(int index) {
    if (index >= _length) {
      throw RangeError('Index $index > $_length is out of bounds');
    }
    if (index < 0) {
      throw RangeError('Index $index < 0 is out of bounds');
    }

    int byteIndex = (_offset + index) >> 3;
    int bitIndex = 7 - ((_offset + index) % 8);

    return (_data[byteIndex] & (1 << bitIndex)) != 0;
  }

  BitString substring(int offset, int length) {
    if (offset > _length) {
      throw RangeError('Offset($offset) > $_length is out of bounds');
    }
    if (offset < 0) {
      throw RangeError('Offset($offset) < 0 is out of bounds');
    }

    if (length == 0) {
      return BitString.empty;
    }

    if (offset + length > _length) {
      throw RangeError(
          'Offset $offset + Length $length > $_length is out of bounds');
    }

    return BitString(_data, _offset + offset, length);
  }

  List<int>? subbuffer(int offset, int length) {
    if (offset > _length) {
      throw RangeError('Offset $offset is out of bounds');
    }
    if (offset < 0) {
      throw RangeError('Offset $offset is out of bounds');
    }
    if (offset + length > _length) {
      throw RangeError('Offset + Length = ${offset + length} is out of bounds');
    }

    if (length % 8 != 0) {
      return null;
    }
    if ((_offset + offset) % 8 != 0) {
      return null;
    }

    int start = ((_offset + offset) >> 3);
    int end = start + (length >> 3);
    return _data.sublist(start, end);
  }

  // bool equals(BitString b) {
  //   if (_length != b._length) {
  //     return false;
  //   }
  //   for (int i = 0; i < _length; i++) {
  //     if (at(i) != b.at(i)) {
  //       return false;
  //     }
  //   }
  //   return true;
  // }

  @override
  operator ==(other) {
    if (other is! BitString) return false;
    if (other.length != _length) return false;
    for (int i = 0; i < _length; i++) {
      if (at(i) != other.at(i)) return false;
    }
    return true;
  }

  @override
  String toString() {
    final padded = BocUtils.bitsToPaddedBuffer(this).buffer();

    if (_length % 4 == 0) {
      final s = BytesUtils.toHexString(padded.sublist(0, (_length / 8).ceil()),
          lowerCase: false);
      if (_length % 8 == 0) {
        return s;
      } else {
        return s.substring(0, s.length - 1);
      }
    } else {
      final hex = BytesUtils.toHexString(padded, lowerCase: false);
      if (_length % 8 <= 4) {
        return '${hex.substring(0, hex.length - 1)}_';
      } else {
        return '${hex}_';
      }
    }
  }

  @override
  int get hashCode => Object.hash(_data, _length);
}
