import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/utils/utils.dart';
import 'package:ton_dart/src/dictionary/dictionary.dart';

import 'bit_builder.dart'; // Assuming BitBuilder is defined somewhere
import 'cell.dart'; // Assuming Cell is defined somewhere
import 'slice.dart'; // Assuming Slice is defined somewhere

abstract class Writable {
  void writeTo(Builder builder);
}

Builder beginCell() {
  return Builder();
}

class Builder {
  final BitBuilder _bits;
  final List<Cell> _refs;

  Builder()
      : _bits = BitBuilder(),
        _refs = [];

  int get bits => _bits.length;

  int get refs => _refs.length;

  int get availableBits => 1023 - bits;

  int get availableRefs => 4 - refs;

  Builder storeBit(dynamic value) {
    _bits.writeBit(value);
    return this;
  }

  Builder storeBits(BitString src) {
    _bits.writeBits(src);
    return this;
  }

  Builder storeBuffer(List<int> src, [int? bytes]) {
    if (bytes != null) {
      if (src.length != bytes) {
        throw Exception('Buffer length ${src.length} is not equal to $bytes');
      }
    }
    _bits.writeBuffer(src);
    return this;
  }

  Builder storeMaybeBuffer(List<int>? src, [int? bytes]) {
    if (src != null) {
      storeBit(1);
      storeBuffer(src, bytes);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeUint(dynamic value, int bits) {
    _bits.writeUint(value, bits);
    return this;
  }

  Builder storeMaybeUint(dynamic value, int bits) {
    if (value != null) {
      storeBit(1);
      storeUint(value, bits);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeInt(dynamic value, int bits) {
    _bits.writeInt(value, bits);
    return this;
  }

  Builder storeMaybeInt(dynamic value, int bits) {
    if (value != null) {
      storeBit(1);
      storeInt(value, bits);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeVarUint(dynamic value, int bits) {
    _bits.writeVarUint(value, bits);
    return this;
  }

  Builder storeMaybeVarUint(dynamic value, int bits) {
    if (value != null) {
      storeBit(1);
      storeVarUint(value, bits);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeVarInt(dynamic value, int bits) {
    _bits.writeVarInt(value, bits);
    return this;
  }

  Builder storeMaybeVarInt(dynamic value, int bits) {
    if (value != null) {
      storeBit(1);
      storeVarInt(value, bits);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeCoins(dynamic amount) {
    _bits.writeCoins(amount);
    return this;
  }

  Builder storeMaybeCoins(dynamic amount) {
    if (amount != null) {
      storeBit(1);
      storeCoins(amount);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeAddress(dynamic address) {
    _bits.writeAddress(address);
    return this;
  }

  Builder storeRef(dynamic cell) {
    if (_refs.length >= 4) {
      throw Exception('Too many references');
    }
    if (cell is Cell) {
      _refs.add(cell);
    } else if (cell is Builder) {
      _refs.add(cell.endCell());
    } else {
      throw Exception('Invalid argument');
    }
    return this;
  }

  Builder storeMaybeRef([dynamic cell]) {
    if (cell != null) {
      storeBit(1);
      storeRef(cell);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeSlice(Slice src) {
    final c = src.clone();
    if (c.remainingBits > 0) {
      storeBits(c.loadBits(c.remainingBits));
    }
    while (c.remainingRefs > 0) {
      storeRef(c.loadRef());
    }
    return this;
  }

  Builder storeMaybeSlice([Slice? src]) {
    if (src != null) {
      storeBit(1);
      storeSlice(src);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeBuilder(Builder src) {
    return storeSlice(src.endCell().beginParse());
  }

  Builder storeMaybeBuilder([Builder? src]) {
    if (src != null) {
      storeBit(1);
      storeBuilder(src);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeWritable(dynamic writer) {
    if (writer is Writable) {
      writer.writeTo(this);
    } else if (writer is Function) {
      writer(this);
    }
    return this;
  }

  Builder storeMaybeWritable([dynamic writer]) {
    if (writer != null) {
      storeBit(1);
      storeWritable(writer);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder store(dynamic writer) {
    return storeWritable(writer);
  }

  Builder storeStringTail(String src) {
    BocUtils.writeString(src, this);
    return this;
  }

  Builder storeMaybeStringTail([String? src]) {
    if (src != null) {
      storeBit(1);
      storeStringTail(src);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeStringRefTail(String src) {
    storeRef(beginCell().storeStringTail(src));
    return this;
  }

  Builder storeMaybeStringRefTail([String? src]) {
    if (src != null) {
      storeBit(1);
      storeStringRefTail(src);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeDict<K extends DictionaryKeyTypes, V>(
      [Dictionary<K, V>? dict,
      DictionaryKey<K>? key,
      DictionaryValue<V>? value]) {
    if (dict != null) {
      dict.store(this, key: key, value: value);
    } else {
      storeBit(0);
    }
    return this;
  }

  Builder storeDictDirect<K extends DictionaryKeyTypes, V>(
      Dictionary<K, V> dict,
      {DictionaryKey<K>? key,
      DictionaryValue<V>? value}) {
    dict.storeDirect(this, key: key, value: value);
    return this;
  }

  Cell endCell({bool? exotic}) {
    return Cell(
      bits: _bits.build(),
      refs: _refs,
      exotic: exotic ?? false,
    );
  }

  Cell asCell() {
    return endCell();
  }

  Slice asSlice() {
    return endCell().beginParse();
  }
}
