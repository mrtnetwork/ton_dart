class CellType {
  final String name;
  final int tag;

  const CellType._(this.tag, this.name);
  static const CellType ordinary = CellType._(-1, "Ordinary");
  static const CellType prunedBranch = CellType._(1, "PrunedBranch");
  static const CellType library = CellType._(2, "Library");
  static const CellType merkleProof = CellType._(3, "MerkleProof");
  static const CellType merkleUpdate = CellType._(4, "MerkleUpdate");
}
