import 'package:blockchain_utils/string/string.dart';
import 'package:ton_dart/src/boc/bit_builder.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'dart:math' as math;

import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';

class BocUtils {
  static BitBuilder bitsToPaddedBuffer(BitString bits) {
    // Create builder
    var builder = BitBuilder(((bits.length / 8).ceil()) * 8);
    builder.writeBits(bits);

    // Apply padding
    var padding = ((bits.length / 8).ceil()) * 8 - bits.length;
    for (var i = 0; i < padding; i++) {
      if (i == 0) {
        builder.writeBit(1);
      } else {
        builder.writeBit(0);
      }
    }

    return builder;
  }

  static BitString paddedBufferToBits(List<int> buff) {
    var bitLen = 0;
    // Finding rightmost non-zero byte in the buffer
    for (var i = buff.length - 1; i >= 0; i--) {
      if (buff[i] != 0) {
        var testByte = buff[i];
        // Looking for a rightmost set padding bit
        var bitPos = testByte & -testByte;
        if ((bitPos & 1) == 0) {
          // It's power of 2 (only one bit set)
          bitPos = (math.log(bitPos) ~/ math.ln2) + 1;
        }
        if (i > 0) {
          // If we are dealing with more than 1 byte buffer
          bitLen = i << 3; // Number of full bytes * 8
        }
        bitLen += 8 - bitPos;
        break;
      }
    }
    return BitString(buff, 0, bitLen);
  }

  static List<int> readBuffer(Slice slice) {
    // Check consistency
    if (slice.remainingBits % 8 != 0) {
      throw FormatException('Invalid string length: ${slice.remainingBits}');
    }
    if (slice.remainingRefs != 0 && slice.remainingRefs != 1) {
      throw FormatException('Invalid number of refs: ${slice.remainingRefs}');
    }

    // Read string
    List<int> res;
    if (slice.remainingBits == 0) {
      res = [];
    } else {
      res = slice.loadBuffer(slice.remainingBits ~/ 8);
    }

    // Read tail
    if (slice.remainingRefs == 1) {
      res = [...res, ...readBuffer(slice.loadRef().beginParse())];
    }

    return res;
  }

  static String readString(Slice slice) {
    return StringUtils.decode(readBuffer(slice));
  }

  static void writeBuffer(List<int> src, Builder builder) {
    if (src.isNotEmpty) {
      final bytes = builder.availableBits ~/ 8;
      if (src.length > bytes) {
        final a = src.sublist(0, bytes);
        final t = src.sublist(bytes);
        builder = builder.storeBuffer(a);
        final bb = beginCell();
        writeBuffer(t, bb);
        builder = builder.storeRef(bb.endCell());
      } else {
        builder = builder.storeBuffer(src);
      }
    }
  }

  static Cell stringToCell(String src) {
    final builder = beginCell();
    writeBuffer(StringUtils.encode(src), builder);
    return builder.endCell();
  }

  static void writeString(String src, Builder builder) {
    writeBuffer(StringUtils.encode(src), builder);
  }
}
