import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell/level_mask.dart';
import 'package:ton_dart/src/boc/cell/serialization.dart';
import 'package:ton_dart/src/boc/cell/wonder_calculator.dart';
import 'package:ton_dart/src/boc/slice.dart';

import 'bit_reader.dart';
import 'bit_string.dart';
import 'cell/resolve_exotic.dart';
import 'cell_type.dart';

class Cell {
  static final Cell empty = Cell();

  static List<Cell> fromBoc(List<int> src) {
    return deserializeBoc(src);
  }

  static Cell fromBase64(String src) {
    final parsed = Cell.fromBoc(StringUtils.encode(src, StringEncoding.base64));
    if (parsed.length != 1) {
      throw Exception("Deserialized more than one cell");
    }
    return parsed[0];
  }

  final CellType type;
  final BitString bits;
  final List<Cell> refs;
  final LevelMask mask;

  final List<List<int>> _hashes;
  final List<int> _depths;
  Cell._(
      {required this.type,
      required this.bits,
      required this.refs,
      required this.mask,
      required List<List<int>> hashes,
      required List<int> depths})
      : _hashes = hashes,
        _depths = depths;

  factory Cell({bool exotic = false, BitString? bits, List<Cell>? refs}) {
    bits ??= BitString.empty;
    refs ??= [];
    List<List<int>> hashes = [];
    List<int> depths = [];
    LevelMask mask;
    CellType type = CellType.ordinary;
    if (exotic) {
      // Resolve exotic cell
      final resolved = resolveExotic(bits, refs);
      type = resolved["type"];
      // Perform wonders
      final wonders = wonderCalculator(type, bits, refs);
      // Copy results
      mask = wonders["mask"];
      depths = wonders["depths"];
      hashes = wonders["hashes"];
    } else {
      // Check correctness
      if (refs.length > 4) {
        throw Exception("Invalid number of references");
      }
      if (bits.length > 1023) {
        throw Exception("Bits overflow: ${bits.length} > 1023");
      }

      final wonders = wonderCalculator(type, bits, refs);

      mask = wonders["mask"];
      depths = wonders["depths"];
      hashes = wonders["hashes"];
    }
    return Cell._(
        type: type,
        bits: bits,
        refs: refs,
        mask: mask,
        hashes: hashes,
        depths: depths);
  }

  bool get isExotic => type != CellType.ordinary;

  Slice beginParse([bool allowExotic = false]) {
    if (isExotic && !allowExotic) {
      throw Exception("Exotic cells cannot be parsed");
    }
    return Slice(BitReader(bits), refs);
  }

  List<int> hash({int level = 3}) {
    return _hashes[min(_hashes.length - 1, level)];
  }

  int depth({int level = 3}) {
    return _depths[min(_depths.length - 1, level)];
  }

  int get level => mask.level;

  List<int> toBoc({bool idx = false, bool crc32 = true}) {
    return serializeBoc(this, idx: idx, crc32: crc32);
  }

  @override
  String toString({String indent = ""}) {
    String id = indent;
    String t = "x";
    if (isExotic) {
      if (type == CellType.merkleProof) {
        t = "p";
      } else if (type == CellType.merkleUpdate) {
        t = "u";
      } else if (type == CellType.prunedBranch) {
        t = "p";
      }
    }
    String s = '$id$t{$bits}';
    for (Cell i in refs) {
      s += "\n" + i.toString(indent: "$id ");
    }
    return s;
  }

  Slice asSlice() {
    return beginParse();
  }

  Builder asBuilder() {
    return beginCell()
        .storeSlice(asSlice()); // Replace this with actual implementation
  }

  @override
  operator ==(other) {
    if (other is! Cell) return false;
    if (other._hashes.length != _hashes.length) return false;
    for (int i = 0; i < _hashes.length; i++) {
      if (!bytesEqual(other._hashes[i], _hashes[i])) return false;
    }
    return true;
  }

  @override
  int get hashCode => Object.hashAll(_hashes);

  //  (level: number = 3): Buffer => {
  //       return this._hashes[Math.min(this._hashes.length - 1, level)];
  //   }
}

const inspectSymbol = 'inspectSymbol';

int min(int a, int b) => a < b ? a : b;
