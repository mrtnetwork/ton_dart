import 'dart:math';

import 'package:blockchain_utils/tuple/tuple.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/dictionary/utils/utils.dart';

String pad(String src, int size) {
  while (src.length < size) {
    src = '0$src';
  }
  return src;
}

class Node<T> {
  late Edge<T> left;
  late Edge<T> right;

  Node.fork(this.left, this.right) : isLeaf = false;
  Node.leaf(this.value) : isLeaf = true;
  bool isLeaf;
  late final T value;
}

class Edge<T> {
  final String label;
  final Node<T> node;

  Edge(this.label, this.node);
}

Map<String, T> removePrefixMap<T>(Map<String, T> src, int length) {
  if (length == 0) {
    return src;
  } else {
    final res = <String, T>{};
    for (final k in src.keys) {
      final d = src[k] as T;
      res[k.substring(length)] = d;
    }
    return res;
  }
}

Tuple<Map<String, T>, Map<String, T>> forkMap<T>(
    Map<String, T> src, int prefixLen) {
  if (src.isEmpty) {
    throw Exception('Internal inconsistency');
  }
  final left = <String, T>{};
  final right = <String, T>{};
  for (final entry in src.entries) {
    final k = entry.key;
    final d = entry.value;
    if (k[prefixLen] == '0') {
      left[k] = d;
    } else {
      right[k] = d;
    }
  }
  if (left.isEmpty) {
    throw Exception('Internal inconsistency. Left emtpy.');
  }
  if (right.isEmpty) {
    throw Exception('Internal inconsistency. Right emtpy.');
  }
  return Tuple(left, right);
}

Node<T> buildNode<T>(Map<String, T> src, int prefixLen) {
  if (src.isEmpty) {
    throw Exception('Internal inconsistency');
  }
  if (src.length == 1) {
    return Node.leaf(src.values.first);
  }
  final fork = forkMap(src, prefixLen);
  final left = buildEdge<T>(fork.item1, prefixLen + 1);
  final right = buildEdge<T>(fork.item2, prefixLen + 1);
  return Node.fork(left, right);
}

Edge<T> buildEdge<T>(Map<String, T> src, [int prefixLen = 0]) {
  if (src.isEmpty) {
    throw Exception('Internal inconsistency');
  }
  final label = DicionaryUtils.findCommonPrefix(src.keys.toList(), prefixLen);
  final node = buildNode<T>(src, label.length + prefixLen);
  return Edge(label, node);
}

Edge<T> buildTree<T>(Map<BigInt, T> src, int keyLength) {
  final converted = <String, T>{};
  src.forEach((k, v) {
    final padded = pad(k.toRadixString(2), keyLength);
    converted[padded] = v;
  });
  return buildEdge(converted);
}

String writeLabelShort(String src, Builder to) {
  // Header
  to.storeBit(0);

  // Unary length
  for (int i = 0; i < src.length; i++) {
    to.storeBit(1);
  }
  to.storeBit(0);

  // Value
  if (src.isNotEmpty) {
    to.storeUint(BigInt.parse(src, radix: 2), src.length);
  }
  return src;
}

int labelShortLength(String src) {
  return 1 + src.length + 1 + src.length;
}

String writeLabelLong(String src, int keyLength, Builder to) {
  // Header
  to.storeBit(1);
  to.storeBit(0);

  // Length
  final length = (log(keyLength + 1) / log(2)).ceil();
  to.storeUint(src.length, length);

  // Value
  if (src.isNotEmpty) {
    to.storeUint(BigInt.parse(src, radix: 2), src.length);
  }
  return src;
}

int labelLongLength(String src, int keyLength) {
  return 1 + 1 + ((log(keyLength + 1) / log(2))).ceil() + src.length;
}

void writeLabelSame(bool value, int length, int keyLength, Builder to) {
  // Header
  to.storeBit(1);
  to.storeBit(1);

  // Value
  to.storeBit(value ? 1 : 0);

  // Length
  final lenLen = (log(keyLength + 1) / log(2)).ceil();
  to.storeUint(length, lenLen);
}

int labelSameLength(int keyLength) {
  return 1 + 1 + 1 + (log(keyLength + 1) / log(2)).ceil();
}

bool isSame(String src) {
  if (src.isEmpty || src.length == 1) {
    return true;
  }
  for (int i = 1; i < src.length; i++) {
    if (src[i] != src[0]) {
      return false;
    }
  }
  return true;
}

String detectLabelType(String src, int keyLength) {
  var kind = 'short';
  var kindLength = labelShortLength(src);

  final longLength = labelLongLength(src, keyLength);
  if (longLength < kindLength) {
    kindLength = longLength;
    kind = 'long';
  }

  if (isSame(src)) {
    final sameLength = labelSameLength(keyLength);
    if (sameLength < kindLength) {
      kindLength = sameLength;
      kind = 'same';
    }
  }

  return kind;
}

void writeLabel(String src, int keyLength, Builder to) {
  final type = detectLabelType(src, keyLength);
  if (type == 'short') {
    writeLabelShort(src, to);
  } else if (type == 'long') {
    writeLabelLong(src, keyLength, to);
  } else if (type == 'same') {
    writeLabelSame(src[0] == '1', src.length, keyLength, to);
  }
}

void writeNode<T>(Node<T> src, int keyLength,
    void Function(T, Builder) serializer, Builder to) {
  if (src.isLeaf) {
    serializer(src.value, to);
  }
  if (!src.isLeaf) {
    final leftCell = beginCell();
    final rightCell = beginCell();
    writeEdge(src.left, keyLength - 1, serializer, leftCell);
    writeEdge(src.right, keyLength - 1, serializer, rightCell);
    to.storeRef(leftCell);
    to.storeRef(rightCell);
  }
}

void writeEdge<T>(Edge<T> src, int keyLength,
    void Function(T, Builder) serializer, Builder to) {
  writeLabel(src.label, keyLength, to);
  writeNode(src.node, keyLength - src.label.length, serializer, to);
}

void serializeDict<T>(Map<BigInt, T> src, int keyLength,
    void Function(T, Builder) serializer, Builder to) {
  final tree = buildTree<T>(src, keyLength);
  writeEdge(tree, keyLength, serializer, to);
}
