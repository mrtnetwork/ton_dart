import 'package:ton_dart/src/address/address/address.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';
import 'package:ton_dart/src/dictionary/generate_merkle_proof.dart';
import 'package:ton_dart/src/dictionary/pars_dict.dart';
import 'package:ton_dart/src/dictionary/utils/utils.dart';

import 'generate_merkle_update.dart';
import 'serialize_dict.dart';

typedef DictionaryKeyTypes
    = dynamic; // Dart doesn't support unions in type definitions

class DictionaryKey<K extends DictionaryKeyTypes> {
  final int bits;
  final BigInt Function(K) serialize;
  final K Function(BigInt) parse;

  DictionaryKey(
      {required this.bits, required this.serialize, required this.parse});
}

class DictionaryValue<V> {
  final void Function(V, Builder) serialize;
  final V Function(Slice) parse;

  DictionaryValue({required this.serialize, required this.parse});
}

class Dictionary<K extends DictionaryKeyTypes, V> {
  static final Map<String, Function> emptyKeys = {
    'Address': () => createAddressKey(),
    'BigInt': (int bits) => createBigIntKey(bits),
    'Int': (int bits) => createIntKey(bits),
    'BigUint': (int bits) => createBigUintKey(bits),
    'Uint': (int bits) => createUintKey(bits),
    'Buffer': (int bytes) => createBufferKey(bytes),
    'BitString': (int bits) => createBitStringKey(bits),
  };

  static final Map<String, Function> emptyValues = {
    'BigInt': (int bits) => createBigIntValue(bits),
    'Int': (int bits) => createIntValue(bits),
    'BigVarInt': (int bits) => createBigVarIntValue(bits),
    'BigUint': (int bits) => createBigUintValue(bits),
    'Uint': (int bits) => createUintValue(bits),
    'BigVarUint': (int bits) => createBigVarUintValue(bits),
    'Bool': () => createBooleanValue(),
    'Address': () => createAddressValue(),
    'Cell': () => createCellValue(),
    'Buffer': (int bytes) => createBufferValue(bytes),
    'BitString': (int bits) => createBitStringValue(bits),
    'Dictionary': <K extends DictionaryKeyTypes, V>(DictionaryKey<K> key,
            DictionaryValue<V> value) =>
        createDictionaryValue(key, value),
  };

  static Dictionary<K, V> empty<K extends DictionaryKeyTypes, V>(
      {DictionaryKey<K>? key, DictionaryValue<V>? value}) {
    if (key != null && value != null) {
      return Dictionary<K, V>(<String, V>{}, key, value);
    } else {
      return Dictionary<K, V>(<String, V>{}, null, null);
    }
  }

  static Dictionary<K, V> load<K extends DictionaryKeyTypes, V>(
      DictionaryKey<K> key, DictionaryValue<V> value, dynamic sc) {
    Slice? slice;
    if (sc is Cell) {
      if (sc.isExotic) {
        return empty<K, V>(key: key, value: value);
      }
      slice = sc.beginParse();
    } else {
      slice = sc;
    }
    final cell = slice!.loadMaybeRef();
    if (cell != null && !cell.isExotic) {
      return loadDirect<K, V>(key, value, cell.beginParse());
    } else {
      return empty<K, V>(key: key, value: value);
    }
  }

  static Dictionary<K, V> loadDirect<K extends DictionaryKeyTypes, V>(
      DictionaryKey<K> key, DictionaryValue<V> value, dynamic sc) {
    if (sc == null) {
      return empty<K, V>(key: key, value: value);
    }
    Slice? slice;
    if (sc is Cell) {
      slice = sc.beginParse();
    } else {
      slice = sc;
    }
    final values = parseDict(slice!, key.bits, value.parse);

    final Map<String, V> prepared = {};
    for (final i in values.entries) {
      prepared[DicionaryUtils.serializeInternalKey(key.parse(i.key))] = i.value;
    }

    return Dictionary<K, V>(prepared, key, value);
  }

  final DictionaryKey<K>? _key;
  final DictionaryValue<V>? _value;
  final Map<String, V> _map;

  Dictionary(this._map, this._key, this._value);

  int get size => _map.length;

  V? operator [](K key) => _map[DicionaryUtils.serializeInternalKey(key)];

  bool containsKey(K key) =>
      _map.containsKey(DicionaryUtils.serializeInternalKey(key));

  void operator []=(K key, V value) {
    _map[DicionaryUtils.serializeInternalKey(key)] = value;
  }

  bool remove(K key) =>
      _map.remove(DicionaryUtils.serializeInternalKey(key)) != null;

  void clear() => _map.clear();

  Iterable<MapEntry<K, V>> get entries sync* {
    for (final entry in _map.entries) {
      yield MapEntry(
          DicionaryUtils.deserializeInternalKey(entry.key) as K, entry.value);
    }
  }

  Iterable<K> get keys sync* {
    for (final key in _map.keys) {
      yield DicionaryUtils.deserializeInternalKey(key) as K;
    }
  }

  Iterable<V> get values => _map.values;

  void store(Builder builder,
      {DictionaryKey<K>? key, DictionaryValue<V>? value}) {
    if (_map.isEmpty) {
      builder.storeBit(0);
    } else {
      final resolvedKey = key ?? _key;
      final resolvedValue = value ?? _value;
      if (resolvedKey == null) {
        throw StateError('Key serializer is not defined');
      }
      if (resolvedValue == null) {
        throw StateError('Value serializer is not defined');
      }

      final prepared = Map<BigInt, V>.fromEntries(_map.entries.map((entry) =>
          MapEntry(
              resolvedKey.serialize(
                  DicionaryUtils.deserializeInternalKey(entry.key) as K),
              entry.value)));

      builder.storeBit(1);
      final dd = beginCell();
      serializeDict(prepared, resolvedKey.bits, resolvedValue.serialize, dd);
      builder.storeRef(dd.endCell());
    }
  }

  void storeDirect(Builder builder,
      {DictionaryKey<K>? key, DictionaryValue<V>? value}) {
    if (_map.isEmpty) {
      throw StateError('Cannot store empty dictionary directly');
    }

    final resolvedKey = key ?? _key;
    final resolvedValue = value ?? _value;
    if (resolvedKey == null) {
      throw StateError('Key serializer is not defined');
    }
    if (resolvedValue == null) {
      throw StateError('Value serializer is not defined');
    }
    final prepared = Map<BigInt, V>.fromEntries(_map.entries.map((entry) =>
        MapEntry(
            resolvedKey.serialize(
                DicionaryUtils.deserializeInternalKey(entry.key) as K),
            entry.value)));

    serializeDict(prepared, resolvedKey.bits, resolvedValue.serialize, builder);
  }

  Cell generateMerkleProof2(K key) => generateMerkleProof(this, key, _key!);

  Cell generateMerkleUpdate2(K key, V newValue) =>
      generateMerkleUpdate<K, V>(this, key, _key!, newValue);
}

DictionaryKey<Address> createAddressKey() {
  return DictionaryKey<Address>(
    bits: 267,
    serialize: (src) {
      return beginCell()
          .storeAddress(src)
          .endCell()
          .beginParse()
          .preloadUintBig(267);
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, 267)
          .endCell()
          .beginParse()
          .loadAddress();
    },
  );
}

DictionaryKey<BigInt> createBigIntKey(int bits) {
  return DictionaryKey<BigInt>(
    bits: bits,
    serialize: (src) {
      // if (!(src is BigInt)) {
      //   throw Error('Key is not a bigint');
      // }
      return beginCell()
          .storeInt(src, bits)
          .endCell()
          .beginParse()
          .loadUintBig(bits);
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadIntBig(bits);
    },
  );
}

DictionaryKey<int> createIntKey(int bits) {
  return DictionaryKey<int>(
    bits: bits,
    serialize: (src) {
      // if (!(src is int)) {
      //   throw Error('Key is not a number');
      // }
      if (!src.isFinite) {
        throw Exception('Key is not a safe integer: $src');
      }
      return beginCell()
          .storeInt(src, bits)
          .endCell()
          .beginParse()
          .loadUintBig(bits);
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadInt(bits);
    },
  );
}

DictionaryKey<BigInt> createBigUintKey(int bits) {
  return DictionaryKey<BigInt>(
    bits: bits,
    serialize: (src) {
      if (src < BigInt.zero) {
        throw Exception('Key is negative: $src');
      }
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadUintBig(bits);
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadUintBig(bits);
    },
  );
}

DictionaryKey<int> createUintKey(int bits) {
  return DictionaryKey<int>(
    bits: bits,
    serialize: (src) {
      if (!src.isFinite) {
        throw Exception('Key is not a safe integer: $src');
      }
      if (src < 0) {
        throw Exception('Key is negative: $src');
      }
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadUintBig(bits);
    },
    parse: (src) {
      return int.parse(beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadUint(bits)
          .toString());
    },
  );
}

DictionaryKey<List<int>> createBufferKey(int bytes) {
  return DictionaryKey<List<int>>(
    bits: bytes * 8,
    serialize: (src) {
      return beginCell()
          .storeBuffer(src)
          .endCell()
          .beginParse()
          .loadUintBig(bytes * 8);
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, bytes * 8)
          .endCell()
          .beginParse()
          .loadBuffer(bytes);
    },
  );
}

DictionaryKey<BitString> createBitStringKey(int bits) {
  return DictionaryKey<BitString>(
    bits: bits,
    serialize: (src) {
      if (!BitString.isBitString(src)) {
        throw Exception('Key is not a BitString');
      }
      final res =
          beginCell().storeBits(src).endCell().beginParse().loadUintBig(bits);
      return res;
    },
    parse: (src) {
      return beginCell()
          .storeUint(src, bits)
          .endCell()
          .beginParse()
          .loadBits(bits);
    },
  );
}

DictionaryValue<int> createIntValue(int bits) {
  return DictionaryValue<int>(
    serialize: (src, builder) {
      builder.storeInt(src, bits);
    },
    parse: (src) {
      return src.loadInt(bits);
    },
  );
}

DictionaryValue<BigInt> createBigIntValue(int bits) {
  return DictionaryValue<BigInt>(
    serialize: (src, builder) {
      builder.storeInt(src, bits);
    },
    parse: (src) {
      return src.loadIntBig(bits);
    },
  );
}

DictionaryValue<BigInt> createBigVarIntValue(int bits) {
  return DictionaryValue<BigInt>(
    serialize: (src, builder) {
      builder.storeVarInt(src, bits);
    },
    parse: (src) {
      return src.loadVarIntBig(bits);
    },
  );
}

DictionaryValue<BigInt> createBigVarUintValue(int bits) {
  return DictionaryValue<BigInt>(
    serialize: (src, builder) {
      builder.storeVarUint(src, bits);
    },
    parse: (src) {
      return src.loadVarUintBig(bits);
    },
  );
}

DictionaryValue<int> createUintValue(int bits) {
  return DictionaryValue<int>(
    serialize: (src, builder) {
      builder.storeUint(src, bits);
    },
    parse: (src) {
      return src.loadUint(bits);
    },
  );
}

DictionaryValue<BigInt> createBigUintValue(int bits) {
  return DictionaryValue<BigInt>(
    serialize: (src, builder) {
      builder.storeUint(src, bits);
    },
    parse: (src) {
      return src.loadUintBig(bits);
    },
  );
}

DictionaryValue<bool> createBooleanValue() {
  return DictionaryValue<bool>(
    serialize: (src, builder) {
      builder.storeBit(src);
    },
    parse: (src) {
      return src.loadBit();
    },
  );
}

DictionaryValue<Address> createAddressValue() {
  return DictionaryValue<Address>(
    serialize: (src, builder) {
      builder.storeAddress(src);
    },
    parse: (src) {
      return src.loadAddress();
    },
  );
}

DictionaryValue<Cell> createCellValue() {
  return DictionaryValue<Cell>(
    serialize: (src, builder) {
      builder.storeRef(src);
    },
    parse: (src) {
      return src.loadRef();
    },
  );
}

DictionaryValue<Dictionary<K, V>>
    createDictionaryValue<K extends DictionaryKeyTypes, V>(
        DictionaryKey<K> key, DictionaryValue<V> value) {
  return DictionaryValue<Dictionary<K, V>>(
    serialize: (src, builder) {
      src.store(builder);
    },
    parse: (src) {
      return Dictionary.load(key, value, src);
    },
  );
}

DictionaryValue<List<int>> createBufferValue(int size) {
  return DictionaryValue<List<int>>(
    serialize: (src, builder) {
      if (src.length != size) {
        throw Exception('Invalid buffer size');
      }
      builder.storeBuffer(src);
    },
    parse: (src) {
      return src.loadBuffer(size);
    },
  );
}

DictionaryValue<BitString> createBitStringValue(int bits) {
  return DictionaryValue<BitString>(
    serialize: (src, builder) {
      if (src.length != bits) {
        throw Exception('Invalid BitString size');
      }
      builder.storeBits(src);
    },
    parse: (src) {
      return src.loadBits(bits);
    },
  );
}
