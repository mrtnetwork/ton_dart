import 'package:blockchain_utils/binary/utils.dart';
import 'package:ton_dart/src/address/address/address.dart';
import 'package:ton_dart/src/boc/bit_string.dart';
import 'package:ton_dart/src/boc/slice.dart';
import 'package:ton_dart/src/boc/utils/utils.dart';

class DicionaryUtils {
  static String findCommonPrefix(List<String> src, [int startPos = 0]) {
    // Corner cases
    if (src.isEmpty) {
      return '';
    }

    String r = src[0].substring(startPos);

    for (int i = 1; i < src.length; i++) {
      final s = src[i];
      while (!s.startsWith(r, startPos)) {
        r = r.substring(0, r.length - 1);

        if (r.isEmpty) {
          return r;
        }
      }
    }

    return r;
  }

  static String serializeInternalKey(dynamic value) {
    if (value is int) {
      if (!value.isFinite) {
        throw ArgumentError('Invalid key type: not a safe integer: $value');
      }
      return 'n:${value.toString()}';
    } else if (value is BigInt) {
      return 'b:${value.toString()}';
    } else if (value is Address) {
      return 'a:${value.toString()}';
    } else if (value is List<int>) {
      return 'f:${BytesUtils.toHexString(value)}';
    } else if (BitString.isBitString(value)) {
      return 'B:${value.toString()}';
    } else {
      throw ArgumentError('Invalid key type');
    }
  }

  static dynamic deserializeInternalKey(String value) {
    final k = value.substring(0, 2);
    final v = value.substring(2);
    if (k == 'n:') {
      return int.parse(v);
    } else if (k == 'b:') {
      return BigInt.parse(v);
    } else if (k == 'a:') {
      return Address(v);
    } else if (k == 'f:') {
      return BytesUtils.fromHexString(v);
    } else if (k == 'B:') {
      final lastDash = v.endsWith('_');
      final isPadded = lastDash || v.length % 2 != 0;
      if (isPadded) {
        final charLen = lastDash ? v.length - 1 : v.length;
        String padded = '${v.substring(0, charLen)}0'; // Padding
        if (!lastDash && (charLen & 1) != 0) {
          // Four bit nibmle without padding
          return BitString(BytesUtils.fromHexString(padded), 0, charLen << 2);
        } else {
          if (padded.length.isOdd) {
            padded = padded.substring(0, padded.length - 1);
          }
          return BocUtils.paddedBufferToBits(BytesUtils.fromHexString(padded));
        }
      } else {
        return BitString(BytesUtils.fromHexString(v), 0, v.length << 2);
      }
    }
    throw ArgumentError('Invalid key type: $k');
  }

  static int readUnaryLength(Slice slice) {
    int res = 0;
    while (slice.loadBit()) {
      res++;
    }
    return res;
  }
}
