import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';

import 'dictionary.dart';
import 'generate_merkle_proof.dart';

Cell convertToMerkleUpdate(Cell c1, Cell c2) {
  return beginCell()
      .storeUint(4, 8)
      .storeBuffer(c1.hash(level: 0))
      .storeBuffer(c2.hash(level: 0))
      .storeUint(c1.depth(level: 0), 16)
      .storeUint(c2.depth(level: 0), 16)
      .storeRef(c1)
      .storeRef(c2)
      .endCell(exotic: true);
}

Cell generateMerkleUpdate<K extends DictionaryKeyTypes, V>(
  Dictionary<K, V> dict,
  K key,
  DictionaryKey<K> keyObject,
  V newValue,
) {
  final oldProof = generateMerkleProof<K, V>(dict, key, keyObject).refs[0];
  dict[key] = newValue;
  final newProof = generateMerkleProof<K, V>(dict, key, keyObject).refs[0];
  return convertToMerkleUpdate(oldProof, newProof);
}
