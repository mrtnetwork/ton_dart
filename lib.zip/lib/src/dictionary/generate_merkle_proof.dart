import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';
import 'dictionary.dart';
import "dart:math" as math;

int readUnaryLength(Slice slice) {
  int res = 0;
  while (slice.loadBit()) {
    res++;
  }
  return res;
}

int _log2(int n) {
  return (math.log(n + 1) / math.log(2)).ceil();
}

Cell convertToPrunedBranch(Cell c) {
  return beginCell()
      .storeUint(1, 8)
      .storeUint(1, 8)
      .storeBuffer(c.hash(level: 0))
      .storeUint(c.depth(level: 0), 16)
      .endCell(exotic: true);
}

Cell convertToMerkleProof(Cell c) {
  return beginCell()
      .storeUint(3, 8)
      .storeBuffer(c.hash(level: 0))
      .storeUint(c.depth(level: 0), 16)
      .storeRef(c)
      .endCell(exotic: true);
}

Cell doGenerateMerkleProof(String prefix, Slice slice, int n, String key) {
  // Reading label
  Cell originalCell = slice.asCell();

  final lb0 = slice.loadBit() ? 1 : 0;
  int prefixLength = 0;
  String pp = prefix;

  if (lb0 == 0) {
    // Short label detected

    // Read
    prefixLength = readUnaryLength(slice);

    // Read prefix
    for (int i = 0; i < prefixLength; i++) {
      pp += slice.loadBit() ? '1' : '0';
    }
  } else {
    final lb1 = slice.loadBit() ? 1 : 0;
    if (lb1 == 0) {
      // Long label detected
      prefixLength = slice.loadUint(_log2(n + 1));
      for (int i = 0; i < prefixLength; i++) {
        pp += slice.loadBit() ? '1' : '0';
      }
    } else {
      // Same label detected
      final bit = slice.loadBit() ? '1' : '0';
      prefixLength = slice.loadUint(_log2(n + 1));
      for (int i = 0; i < prefixLength; i++) {
        pp += bit;
      }
    }
  }

  if (n - prefixLength == 0) {
    return originalCell;
  } else {
    final sl = originalCell.beginParse();
    Cell left = sl.loadRef();
    Cell right = sl.loadRef();
    // NOTE: Left and right branches are implicitly contain prefixes '0' and '1'
    if (!left.isExotic) {
      if ('${pp}0' == key.substring(0, pp.length + 1)) {
        left = doGenerateMerkleProof(
            '${pp}0', left.beginParse(), n - prefixLength - 1, key);
      } else {
        left = convertToPrunedBranch(left);
      }
    }
    if (!right.isExotic) {
      if ('${pp}1' == key.substring(0, pp.length + 1)) {
        right = doGenerateMerkleProof(
            '${pp}1', right.beginParse(), n - prefixLength - 1, key);
      } else {
        right = convertToPrunedBranch(right);
      }
    }

    return beginCell().storeSlice(sl).storeRef(left).storeRef(right).endCell();
  }
}

Cell generateMerkleProof<K extends DictionaryKeyTypes, V>(
    Dictionary<K, V> dict, K key, DictionaryKey<K> keyObject) {
  final s = beginCell().storeDictDirect(dict).endCell().beginParse();
  return convertToMerkleProof(doGenerateMerkleProof('', s, keyObject.bits,
      keyObject.serialize(key).toRadixString(2).padLeft(keyObject.bits, '0')));
}
