import 'dart:math';

import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';

int readUnaryLength(Slice slice) {
  int res = 0;
  while (slice.loadBit()) {
    res++;
  }
  return res;
}

void doParse<V>(String prefix, Slice slice, int n, Map<BigInt, V> res,
    V Function(Slice) extractor) {
  // Reading label
  int lb0 = slice.loadBit() ? 1 : 0;
  int prefixLength = 0;
  String pp = prefix;

  if (lb0 == 0) {
    // Short label detected

    // Read
    prefixLength = readUnaryLength(slice);

    // Read prefix
    for (int i = 0; i < prefixLength; i++) {
      pp += slice.loadBit() ? '1' : '0';
    }
  } else {
    int lb1 = slice.loadBit() ? 1 : 0;
    if (lb1 == 0) {
      // Long label detected
      prefixLength = slice.loadUint((log(n + 1) / log(2)).ceil());
      for (int i = 0; i < prefixLength; i++) {
        pp += slice.loadBit() ? '1' : '0';
      }
    } else {
      // Same label detected
      String bit = slice.loadBit() ? '1' : '0';
      prefixLength = slice.loadUint((log(n + 1) / log(2)).ceil());
      for (int i = 0; i < prefixLength; i++) {
        pp += bit;
      }
    }
  }

  if (n - prefixLength == 0) {
    res[BigInt.parse(pp, radix: 2)] = extractor(slice);
  } else {
    Cell left = slice.loadRef();
    Cell right = slice.loadRef();
    // NOTE: Left and right branches are implicitly contain prefixes '0' and '1'
    if (!left.isExotic) {
      doParse(
          '${pp}0', left.beginParse(), n - prefixLength - 1, res, extractor);
    }
    if (!right.isExotic) {
      doParse(
          '${pp}1', right.beginParse(), n - prefixLength - 1, res, extractor);
    }
  }
}

Map<BigInt, V> parseDict<V>(
    Slice? sc, int keySize, V Function(Slice) extractor) {
  Map<BigInt, V> res = {};
  if (sc != null) {
    doParse('', sc, keySize, res, extractor);
  }
  return res;
}
