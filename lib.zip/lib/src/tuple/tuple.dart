import 'package:blockchain_utils/blockchain_utils.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';

final _int64Min = BigInt.parse('-9223372036854775808');
final _int64Max = BigInt.parse('9223372036854775807');

class TupleItemTypes {
  final String name;
  const TupleItemTypes._(this.name);
  static const TupleItemTypes tupleItem = TupleItemTypes._("tuple");
  static const TupleItemTypes nullItem = TupleItemTypes._("null");
  static const TupleItemTypes intItem = TupleItemTypes._("int");
  static const TupleItemTypes nanItem = TupleItemTypes._("nan");
  static const TupleItemTypes cellItem = TupleItemTypes._("cell");
  static const TupleItemTypes sliceItem = TupleItemTypes._("slice");
  static const TupleItemTypes builderItem = TupleItemTypes._("builder");
  static const List<TupleItemTypes> values = [
    tupleItem,
    nullItem,
    intItem,
    nanItem,
    cellItem,
    sliceItem,
    builderItem,
  ];

  static TupleItemTypes fromName(String? name, {TupleItemTypes? excepted}) {
    final type = values.firstWhere(
      (element) => element.name == name,
      orElse: () =>
          throw Exception("cannot find tuple type from provided value."),
    );
    if (excepted != null && excepted != type) {
      throw Exception("Incorrect tuple type excepted $excepted got $type");
    }
    return type;
  }

  @override
  String toString() {
    return name;
  }
}

abstract class TupleItem {
  abstract final TupleItemTypes type;
  const TupleItem();
  factory TupleItem.fromJson(Map<String, dynamic> json) {
    final type = TupleItemTypes.fromName(json["type"]);
    switch (type) {
      case TupleItemTypes.tupleItem:
        return Tuple.fromJson(json);
      case TupleItemTypes.nanItem:
        return const TupleItemNaN();
      case TupleItemTypes.nullItem:
        return const TupleItemNull();
      case TupleItemTypes.intItem:
        return TupleItemInt.fromJson(json);
      case TupleItemTypes.cellItem:
        return TupleItemCell.fromJson(json);
      case TupleItemTypes.sliceItem:
        return TupleItemSlice.fromJson(json);
      default:
        return TupleItemBuilder.fromJson(json);
    }
  }

  @override
  operator ==(other) {
    if (other is! TupleItem) return false;
    if (other.runtimeType != runtimeType) return false;
    if (other.type != type) return false;
    return true;
  }

  @override
  int get hashCode => type.hashCode;
}

class Tuple extends TupleItem {
  final List<TupleItem> items;
  const Tuple(this.items);
  factory Tuple.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.tupleItem);
    return Tuple(
        (json["items"] as List).map((e) => TupleItem.fromJson(e)).toList());
  }
  @override
  TupleItemTypes get type => TupleItemTypes.tupleItem;
  @override
  operator ==(other) {
    if (super == other) {
      other as Tuple;
      return iterableIsEqual(items, other.items);
    }
    return false;
  }

  @override
  int get hashCode => super.hashCode ^ Object.hashAll(items);
}

class TupleItemNull extends TupleItem {
  const TupleItemNull();
  factory TupleItemNull.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.nullItem);
    return const TupleItemNull();
  }
  @override
  TupleItemTypes get type => TupleItemTypes.nullItem;
}

class TupleItemInt extends TupleItem {
  final BigInt value;
  const TupleItemInt(this.value);
  factory TupleItemInt.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.intItem);
    return TupleItemInt(BigintUtils.parse(json["value"]));
  }
  @override
  TupleItemTypes get type => TupleItemTypes.intItem;
  @override
  operator ==(other) {
    if (super == other) {
      other as TupleItemInt;
      return other.value == value;
    }
    return false;
  }

  @override
  int get hashCode => super.hashCode ^ value.hashCode;

  @override
  String toString() {
    return "TupleItemInt($value)";
  }
}

class TupleItemNaN extends TupleItem {
  const TupleItemNaN();
  factory TupleItemNaN.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.nanItem);
    return const TupleItemNaN();
  }
  @override
  TupleItemTypes get type => TupleItemTypes.nanItem;
}

class TupleItemCell extends TupleItem {
  final Cell cell;
  const TupleItemCell(this.cell);
  factory TupleItemCell.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.cellItem);
    final decodeBytes =
        StringUtils.tryEncode(json["cell"], StringEncoding.base64) ??
            BytesUtils.tryFromHexString(json["cell"]);
    if (decodeBytes == null) {
      throw Exception("Invalid cell string hex or base64");
    }
    final cell = Cell.fromBoc(decodeBytes);
    if (cell.length != 1) {
      throw Exception("Invalid cell");
    }
    return TupleItemCell(cell[0]);
  }
  @override
  TupleItemTypes get type => TupleItemTypes.cellItem;

  @override
  operator ==(other) {
    if (super == other) {
      other as TupleItemCell;
      return other.cell == cell;
    }
    return false;
  }

  @override
  int get hashCode => super.hashCode ^ cell.hashCode;
}

class TupleItemSlice extends TupleItem {
  final Cell slice;
  const TupleItemSlice(this.slice);
  factory TupleItemSlice.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.sliceItem);
    final decodeBytes =
        StringUtils.tryEncode(json["slice"], StringEncoding.base64) ??
            BytesUtils.tryFromHexString(json["slice"]);
    if (decodeBytes == null) {
      throw Exception("Invalid cell string hex or base64");
    }
    final cell = Cell.fromBoc(decodeBytes);
    if (cell.length != 1) {
      throw Exception("Invalid slice");
    }
    return TupleItemSlice(cell[0]);
  }
  @override
  TupleItemTypes get type => TupleItemTypes.sliceItem;
  @override
  operator ==(other) {
    if (super == other) {
      other as TupleItemSlice;
      return other.slice == slice;
    }
    return false;
  }

  @override
  int get hashCode => super.hashCode ^ slice.hashCode;
}

class TupleItemBuilder extends TupleItem {
  final Cell builder;
  const TupleItemBuilder(this.builder);
  factory TupleItemBuilder.fromJson(Map<String, dynamic> json) {
    TupleItemTypes.fromName(json["type"], excepted: TupleItemTypes.builderItem);
    final decodeBytes =
        StringUtils.tryEncode(json["builder"], StringEncoding.base64) ??
            BytesUtils.tryFromHexString(json["builder"]);
    if (decodeBytes == null) {
      throw Exception("Invalid builder string hex or base64");
    }
    final cell = Cell.fromBoc(decodeBytes);
    if (cell.length != 1) {
      throw Exception("Invalid slice");
    }
    return TupleItemBuilder(cell[0]);
  }
  @override
  TupleItemTypes get type => TupleItemTypes.builderItem;
  @override
  operator ==(other) {
    if (super == other) {
      other as TupleItemBuilder;
      return other.builder == builder;
    }
    return false;
  }

  @override
  int get hashCode => super.hashCode ^ builder.hashCode;
}

// class TupleItem {
//   final String type;
//   final dynamic value;
//   final Cell? cell;
//   final List<TupleItem>? items;

//   TupleItem({required this.type, this.value, this.cell, this.items});
// }

void serializeTupleItem(TupleItem src, Builder builder) {
  if (src.type == TupleItemTypes.nullItem) {
    builder.storeUint(0x00, 8);
  } else if (src is TupleItemInt) {
    if (src.value <= _int64Max && src.value >= _int64Min) {
      builder.storeUint(0x01, 8);
      builder.storeInt(src.value, 64);
    } else {
      builder.storeUint(0x0100, 15);
      builder.storeInt(src.value, 257);
    }
  } else if (src is TupleItemNaN) {
    builder.storeInt(0x02ff, 16);
  } else if (src is TupleItemCell) {
    builder.storeUint(0x03, 8);
    builder.storeRef(src.cell);
  } else if (src is TupleItemSlice) {
    builder.storeUint(0x04, 8);
    builder.storeUint(0, 10);
    builder.storeUint(src.slice.bits.length, 10);
    builder.storeUint(0, 3);
    builder.storeUint(src.slice.refs.length, 3);
    builder.storeRef(src.slice);
  } else if (src is TupleItemBuilder) {
    builder.storeUint(0x05, 8);
    builder.storeRef(src.builder);
  } else if (src is Tuple) {
    Cell? head;
    Cell? tail;
    for (var i = 0; i < src.items.length; i++) {
      var s = head;
      head = tail;
      tail = s;

      if (i > 1) {
        head = beginCell().storeRef(tail!).storeRef(head!).endCell();
      }

      var bc = beginCell();
      serializeTupleItem(src.items[i], bc);
      tail = bc.endCell();
    }

    builder.storeUint(0x07, 8);
    builder.storeUint(src.items.length, 16);
    if (head != null) {
      builder.storeRef(head);
    }
    if (tail != null) {
      builder.storeRef(tail);
    }
  } else {
    throw Exception('Invalid value');
  }
}

TupleItem parseStackItem(Slice cs) {
  var kind = cs.loadUint(8);
  if (kind == 0) {
    return const TupleItemNull();
  } else if (kind == 1) {
    return TupleItemInt(cs.loadIntBig(64));
  } else if (kind == 2) {
    if (cs.loadUint(7) == 0) {
      return TupleItemInt(cs.loadIntBig(257));
    } else {
      cs.loadBit(); // must eq 1
      return const TupleItemNaN();
    }
  } else if (kind == 3) {
    return TupleItemCell(cs.loadRef());
  } else if (kind == 4) {
    var startBits = cs.loadUint(10);
    var endBits = cs.loadUint(10);
    var startRefs = cs.loadUint(3);
    var endRefs = cs.loadUint(3);

    // Copy to new cell
    var rs = cs.loadRef().beginParse();
    rs.skip(startBits);
    var dt = rs.loadBits(endBits - startBits);

    var builder = Builder().storeBits(dt);

    // Copy refs if exist
    if (startRefs < endRefs) {
      for (var i = 0; i < startRefs; i++) {
        rs.loadRef();
      }
      for (var i = 0; i < endRefs - startRefs; i++) {
        builder.storeRef(rs.loadRef());
      }
    }

    return TupleItemSlice(builder.endCell());
  } else if (kind == 5) {
    return TupleItemBuilder(cs.loadRef());
  } else if (kind == 7) {
    var length = cs.loadUint(16);
    var items = <TupleItem>[];
    if (length > 1) {
      var head = cs.loadRef().beginParse();
      var tail = cs.loadRef().beginParse();
      items.insert(0, parseStackItem(tail));
      for (var i = 0; i < length - 2; i++) {
        var ohead = head;
        head = ohead.loadRef().beginParse();
        tail = ohead.loadRef().beginParse();
        items.insert(0, parseStackItem(tail));
      }
      items.insert(0, parseStackItem(head));
    } else if (length == 1) {
      items.add(parseStackItem(cs.loadRef().beginParse()));
    }
    return Tuple(items);
  } else {
    throw Exception('Unsupported stack item');
  }
}

void serializeTupleTail(List<TupleItem> src, Builder builder) {
  if (src.isNotEmpty) {
    // rest:^(VmStackList n)
    var tail = Builder();
    serializeTupleTail(src.sublist(0, src.length - 1), tail);
    builder.storeRef(tail.endCell());

    // tos
    serializeTupleItem(src[src.length - 1], builder);
  }
}

Cell serializeTuple(List<TupleItem> src) {
  var builder = Builder();
  builder.storeUint(src.length, 24);
  var r = [...src];
  serializeTupleTail(r, builder);
  return builder.endCell();
}

List<TupleItem> parseTuple(Cell src) {
  var res = <TupleItem>[];
  var cs = src.beginParse();
  var size = cs.loadUint(24);
  for (var i = 0; i < size; i++) {
    var next = cs.loadRef();
    res.insert(0, parseStackItem(cs));
    cs = next.beginParse();
  }
  return res;
}
