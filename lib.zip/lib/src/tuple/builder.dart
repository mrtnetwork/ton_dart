import 'dart:typed_data';

import 'package:ton_dart/src/address/address/address.dart';
import 'package:ton_dart/src/boc/builder.dart';
import 'package:ton_dart/src/boc/cell.dart';
import 'package:ton_dart/src/boc/slice.dart';

import 'tuple.dart';

class TupleBuilder {
  final List<TupleItem> _tuple = [];

  void writeNumber(BigInt? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(TupleItemInt(v));
    }
  }

  void writeBoolean(bool? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(TupleItemInt(v ? -BigInt.one : BigInt.zero));
    }
  }

  void writeBuffer(Uint8List? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(TupleItemSlice(beginCell().storeBuffer(v).endCell()));
    }
  }

  void writeString(String? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(TupleItemSlice(beginCell().storeStringTail(v).endCell()));
    }
  }

  void writeCell(dynamic v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      if (v is Cell) {
        _tuple.add(TupleItemCell(v));
      } else if (v is Slice) {
        _tuple.add(TupleItemCell(v.asCell()));
      }
    }
  }

  void writeSlice(dynamic v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      if (v is Cell) {
        _tuple.add(TupleItemSlice(v));
      } else if (v is Slice) {
        _tuple.add(TupleItemSlice(v.asCell()));
      }
    }
  }

  void writeBuilder(dynamic v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      if (v is Cell) {
        _tuple.add(TupleItemBuilder(v));
      } else if (v is Slice) {
        _tuple.add(TupleItemBuilder(v.asCell()));
      }
    }
  }

  void writeTuple(List<TupleItem>? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(Tuple(v));
    }
  }

  void writeAddress(Address? v) {
    if (v == null) {
      _tuple.add(TupleItemNull());
    } else {
      _tuple.add(TupleItemSlice(beginCell().storeAddress(v).endCell()));
    }
  }

  List<TupleItem> build() {
    return List.from(_tuple);
  }
}
