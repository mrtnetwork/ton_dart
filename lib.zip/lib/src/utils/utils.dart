import 'dart:typed_data';

import 'package:blockchain_utils/blockchain_utils.dart';

class TonUtils {
  static int bitsForNumber(dynamic src, String mode) {
    BigInt v = BigInt.parse(src.toString());

    // Handle negative values
    if (mode == 'int') {
      // Corner case for zero or -1 value
      if (v == BigInt.zero || v == BigInt.from(-1)) {
        return 1;
      }

      BigInt v2 = v > BigInt.zero ? v : -v;
      return v2.toRadixString(2).length + 1; // Sign bit
    } else if (mode == 'uint') {
      if (v < BigInt.zero) {
        throw ArgumentError('value is negative. Got $src');
      }
      return v.toRadixString(2).length;
    } else {
      throw ArgumentError('invalid mode. Got $mode');
    }
  }

  static List<int> crc16(List<int> data) {
    const int poly = 0x1021;
    int reg = 0;
    List<int> message = List<int>.filled(data.length + 2, 0);
    message.setAll(0, data);

    for (int byte in message) {
      int mask = 0x80;
      while (mask > 0) {
        reg <<= 1;
        if (byte & mask != 0) {
          reg += 1;
        }
        mask >>= 1;
        if (reg > mask16) {
          reg &= mask16;
          reg ^= poly;
        }
      }
    }

    return List<int>.from([reg >> 8, reg & mask8]);
  }

  static const int _poly = 0x82f63b78;

  static List<int> crc32c(List<int> source) {
    var crc = 0xffffffff;
    for (var n = 0; n < source.length; n++) {
      crc ^= source[n];
      for (var i = 0; i < 8; i++) {
        if ((crc & 1) == 1) {
          crc = (crc >> 1) ^ _poly;
        } else {
          crc >>= 1;
        }
      }
    }
    crc ^= 0xffffffff;

    // Convert endianness
    var res = IntUtils.toBytes(crc, length: 4, byteOrder: Endian.little);

    return res;
  }

  static int clz32(int x) {
    if (x == 0) return 32;
    int n = 1;
    if ((x >> 16) == 0) {
      n += 16;
      x <<= 16;
    }
    if ((x >> 24) == 0) {
      n += 8;
      x <<= 8;
    }
    if ((x >> 28) == 0) {
      n += 4;
      x <<= 4;
    }
    if ((x >> 30) == 0) {
      n += 2;
      x <<= 2;
    }
    n -= x >> 31;
    return n;
  }

  static String encodeBase64(List<int> bytes, {bool urlSafe = false}) {
    final encode = StringUtils.decode(bytes, StringEncoding.base64);
    if (urlSafe) {
      return encode.replaceAll('+', '-').replaceAll('/', '_');
    }
    return encode;
  }

  static List<int> decodeBase64(String base64) {
    try {
      return StringUtils.encode(base64, StringEncoding.base64);
    } catch (e) {
      throw MessageException("Invalid base64 string.",
          details: {"value": base64});
    }
  }
}
