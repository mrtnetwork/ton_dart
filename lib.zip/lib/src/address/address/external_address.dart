class ExternalAddress {
  final BigInt value;
  final int bits;

  ExternalAddress(this.value, this.bits);

  @override
  String toString() {
    return 'External<$bits:$value>';
  }
}
